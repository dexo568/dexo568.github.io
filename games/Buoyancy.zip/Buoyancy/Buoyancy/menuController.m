//
//  menuController.m
//  Buoyancy
//
//  Created by Dex on 12/3/14.
//  Copyright (c) 2014 Dex. All rights reserved.
//

#import "menuController.h"

@implementation menuController
- (IBAction)unwindToMenu:(UIStoryboardSegue *)segue {
    //nothing goes here
}
@end
