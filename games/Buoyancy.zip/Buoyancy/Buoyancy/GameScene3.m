//
//  GameScene.m
//  Buoyancy
//
//  Created by Dex on 11/15/14.
//  Copyright (c) 2014 Dex. All rights reserved.
//

#import "GameScene3.h"
@import AVFoundation;
@interface GameScene3 ()

@property NSMutableArray *songArray;
@property NSMutableArray *greenSongArray;
@property (strong, nonatomic) AVAudioPlayer *songPlayer;
@property (strong, nonatomic) SKLabelNode *scoreLabel;
@property (strong, nonatomic) SKLabelNode *comboLabel;
@property (strong, nonatomic) SKLabelNode *chainLabel;
@property (strong,nonatomic) SKSpriteNode *rotater;
@property int spinDirection;
@property int combo;
@property int chain;
@end

@implementation GameScene3

-(void)didMoveToView:(SKView *)view {
    self.songArray = [[NSMutableArray alloc] initWithObjects:@"12013:7",@"12189:5",@"12538:7",@"12674:5",@"13010:7",@"14766:3",@"14975:0",@"15336:5",@"15473:7",@"15775:5",@"16477:2",@"17532:4",@"17704:2",@"18045:3",@"18177:2",@"18492:3",@"20287:7",@"20496:5",@"20828:2",@"20962:6",@"21293:0",@"21969:3",@"23034:1",@"23232:4",@"23563:0",@"23722:5",@"24048:0",@"25804:3",@"25998:7",@"26375:4",@"26510:2",@"26826:4",@"27498:1",@"28552:6",@"28767:1",@"29109:6",@"29247:2",@"29547:5",@"31364:2",@"31538:5",@"31889:2",@"32017:4",@"32346:1",@"32999:6",@"34344:1",@"34717:4",@"35263:1",@"35412:4",@"35760:2",@"37166:6",@"37530:2",@"38065:5",@"38218:2",@"38547:4",@"40549:1",@"43307:4",@"45414:7",@"45758:4",@"46287:7",@"46449:3",@"46819:0",@"48203:6",@"48529:7",@"49077:3",@"49222:7",@"49562:3",@"51512:1",@"54282:3",@"56141:0",@"56347:4",@"56674:7",@"56825:6",@"57167:0",@"58931:4",@"59129:7",@"59492:3",@"59617:1",@"59930:4",@"60636:7",@"61654:3",@"61866:0",@"62208:5",@"62332:2",@"62653:3",@"64408:1",@"64646:4",@"64965:7",@"65095:6",@"65427:7",@"66118:4",@"67150:1",@"67394:5",@"67731:2",@"67863:5",@"68180:0",@"69904:3",@"70156:2",@"70489:4",@"70621:2",@"70959:6",@"71646:7",@"72673:3",@"72890:7",@"73232:3",@"73363:2",@"73693:6",@"75452:0",@"75679:6",@"76030:1",@"76159:4",@"76478:2",@"77171:5",@"79240:2",@"79394:5",@"79775:1",@"81874:4",@"82135:7",@"82382:4",@"82511:2",@"82662:6",@"84738:0",@"84946:5",@"85298:0",@"87411:5",@"87665:2",@"87898:6",@"88023:0",@"88178:5",@"90315:1",@"90527:5",@"90840:1",@"92915:4",@"93165:0",@"93385:4",@"93517:1",@"93669:3",@"95821:2",@"96060:3",@"96366:7",@"98425:5",@"98659:0",@"98894:6",@"99022:0",@"99179:3",@"101341:1",@"101552:5",@"101849:0",@"103957:3",@"104188:7",@"104423:3",@"104547:1",@"104688:6",@"106903:1",@"107113:6",@"107404:2",@"109424:6",@"109669:0",@"109948:4",@"110084:0",@"110231:5",@"112016:2",@"112359:3",@"114052:1",@"114255:6",@"114619:0",@"114735:4",@"115073:1",@"115785:3",@"116941:0",@"117152:3",@"117401:0",@"117530:6",@"117852:0",@"119582:5",@"119802:0",@"120135:3",@"120266:1",@"120594:4",@"121287:2",@"122351:3",@"122562:0",@"122867:4",@"123012:2",@"123345:5",@"125109:0",@"125345:4",@"125687:7",@"125820:5",@"126135:1",@"126804:5",@"127839:1",@"128078:5",@"128408:2",@"128539:3",@"128853:2",@"130611:5",@"130840:1",@"131183:5",@"131324:7",@"131640:5",@"132314:2",@"134079:3",@"134573:0",@"134730:5",@"135102:0",@"136466:4",@"136806:1",@"137348:5",@"137496:2",@"137853:4",@"139815:2",@"142625:3",@"144706:2",@"145047:5",@"145617:2",@"145767:5",@"146124:1",@"147497:5",@"147833:2",@"148397:4",@"148564:0",@"148895:6",@"150905:7",@"153684:3", nil];
    
    
    self.greenSongArray=[[NSMutableArray alloc] initWithObjects:@"5774:1",@"6085:2",@"8526:1",@"8855:4",@"9800:1",@"9956:2",@"10574:1",@"11958:2",@"13327:0",@"14720:2",@"16056:5",@"17465:2",@"18844:1",@"20221:2",@"21580:5",@"22989:4",@"24357:0",@"25707:3",@"27095:0",@"28483:4",@"29889:5",@"31256:4",@"32620:5",@"34024:3",@"35376:5",@"36798:2",@"38152:1",@"39509:3",@"40892:1",@"42302:3",@"43648:5",@"45052:3",@"46400:5",@"47822:4",@"49159:0",@"50547:3",@"51901:0",@"53299:2",@"54649:1",@"56085:3",@"57456:5",@"58871:2",@"60204:5",@"61603:2",@"62979:5",@"64362:4",@"65722:1",@"67122:2",@"68480:5",@"69859:2",@"71240:5",@"72644:3",@"74015:5",@"75399:4",@"76762:5",@"77516:2",@"77717:5",@"78026:4",@"78181:1",@"78487:4",@"80225:0",@"80434:2",@"80804:0",@"80966:2",@"81231:5",@"82983:3",@"83200:0",@"83546:2",@"83710:1",@"83998:4",@"85725:0",@"85964:4",@"86312:0",@"86480:4",@"86766:5",@"88485:3",@"88724:0",@"89068:3",@"89233:0",@"89544:3",@"91233:5",@"91451:3",@"91841:1",@"92003:3",@"92281:5",@"93987:4",@"94257:5",@"94585:4",@"94744:5",@"95035:2",@"96741:0",@"96965:3",@"97358:1",@"97528:3",@"97808:5",@"99533:3",@"99768:5",@"100103:4",@"100259:0",@"100555:3",@"102289:5",@"102502:4",@"102872:0",@"103035:3",@"103321:1",@"105044:3",@"105253:1",@"105605:4",@"105769:5",@"106075:4",@"107791:5",@"108019:4",@"108394:0",@"108557:3",@"108841:1",@"111261:3",@"112647:0",@"114031:2",@"115368:5",@"116766:2",@"118123:5",@"119546:3",@"120901:0",@"122301:4",@"123661:5",@"125067:4",@"126364:1",@"127818:3",@"129186:0",@"130576:3",@"131936:0",@"133361:3",@"134708:0",@"136106:2",@"137483:0",@"138827:3",@"140212:5",@"141620:2",@"142969:5",@"144408:3",@"145694:0",@"147103:4",@"148479:0",@"149870:2",@"151201:1",@"152631:3",@"153972:5", nil];    /* Setup your scene here */
    self.combo=1;
    self.chain=0;
    SKSpriteNode *background = [SKSpriteNode spriteNodeWithImageNamed:@"fourthBack"];
    //background.xScale=1.16;
    //background.yScale=1.16;
    background.position = CGPointMake(CGRectGetMidX(self.frame),
                                      CGRectGetMidY(self.frame));
    background.name=@"bg";
    [self addChild:background];
    
    self.rotater = [SKSpriteNode spriteNodeWithImageNamed:@"fourthBackRotater"];
    self.rotater.position = CGPointMake(CGRectGetMidX(self.frame),
                                        CGRectGetMidY(self.frame));
    self.rotater.name=@"rotater";
    [self addChild:self.rotater];
    SKAction *rotation = [SKAction rotateByAngle: M_PI/4.0 duration:5];
    [self.rotater runAction: [SKAction repeatActionForever:rotation]];
    self.spinDirection=1;
    CGPoint center = CGPointMake(185.5,
                                 335);
    //int xRand = arc4random_uniform(40)-20;
    //int yRand = arc4random_uniform(40)-20;
    NSString *songPath = [[NSBundle mainBundle] pathForResource:@"rap" ofType:@"mp3"];
    NSURL *songURL = [NSURL fileURLWithPath:songPath];
    NSError *error;
    self.songPlayer = [[AVAudioPlayer alloc]
                       initWithContentsOfURL:songURL error:&error];
    [self.songPlayer prepareToPlay];
    [self.songPlayer play];
    
    self.scoreLabel = [SKLabelNode labelNodeWithFontNamed:@"DINCondensed-Bold"];
    self.scoreLabel.text = @"0";
    self.scoreLabel.fontSize = 30;
    self.scoreLabel.horizontalAlignmentMode=SKLabelHorizontalAlignmentModeRight;
    self.scoreLabel.position = CGPointMake(370,640);
    [self addChild:self.scoreLabel];
    
    self.comboLabel = [SKLabelNode labelNodeWithFontNamed:@"DINCondensed-Bold"];
    self.comboLabel.text = @"X1";
    self.comboLabel.fontSize = 30;
    self.comboLabel.horizontalAlignmentMode=SKLabelHorizontalAlignmentModeRight;
    self.comboLabel.position = CGPointMake(370,610);
    [self addChild:self.comboLabel];
    
    self.chainLabel = [SKLabelNode labelNodeWithFontNamed:@"DINCondensed-Bold"];
    self.chainLabel.text = @"0";
    self.chainLabel.fontSize = 30;
    self.chainLabel.horizontalAlignmentMode=SKLabelHorizontalAlignmentModeRight;
    self.chainLabel.position = CGPointMake(370,580);
    [self addChild:self.chainLabel];
    
    for(NSString *bubbleGen in self.songArray){
        NSArray *genArray = [bubbleGen componentsSeparatedByString:@":"];
        int timeCode = [[genArray objectAtIndex:0] intValue];
        double timeCodeSeconds = timeCode*.001;
        timeCodeSeconds=timeCodeSeconds-1.25;
        int angle = [[genArray objectAtIndex:1] intValue]*45;
        
        [self performSelector:@selector(generateBubble:) withObject:[NSNumber numberWithInt:angle] afterDelay:timeCodeSeconds];
    }
    for(NSString *bubbleGen in self.greenSongArray){
        NSArray *genArray = [bubbleGen componentsSeparatedByString:@":"];
        int timeCode = [[genArray objectAtIndex:0] intValue];
        double timeCodeSeconds = timeCode*.001;
        timeCodeSeconds=timeCodeSeconds-2.25;
        int angle=0;
        if([[genArray objectAtIndex:1] intValue]==0){
            angle=0;
        }else if ([[genArray objectAtIndex:1] intValue]==1){
            angle=30;
        }else if ([[genArray objectAtIndex:1] intValue]==2){
            angle=150;
        }else if ([[genArray objectAtIndex:1] intValue]==3){
            angle=180;
        }else if ([[genArray objectAtIndex:1] intValue]==4){
            angle=210;
        }else if ([[genArray objectAtIndex:1] intValue]==5){
            angle=330;
        }
        [self performSelector:@selector(generateGreenBubble:) withObject:[NSNumber numberWithInt:angle] afterDelay:timeCodeSeconds];
    }
    
    //   for(int i =0;i<375;i++){
    //        for(int j=0; j<667; j++){
    //            CGPoint currentPoint = CGPointMake(i, j);
    //            CGFloat distance = sqrtf((currentPoint.x-center.x)*(currentPoint.x-center.x)+(currentPoint.y-center.y)*(currentPoint.y-center.y));
    //            if (distance>=275&&distance<=295){
    //                SKSpriteNode *sprite = [SKSpriteNode spriteNodeWithImageNamed:@"Spaceship"];
    //                sprite.xScale = .05;
    //                sprite.yScale = .05;
    //                sprite.alpha=.01;
    //                sprite.position=currentPoint;
    //                [self addChild:sprite];
    //
    //                NSLog(@"Putting spaceship at %i.%i",i,j);
    //
    //            }
    //        }
    //    }
    
    
    
    
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    /* Called when a touch begins */
    
    for (UITouch *touch in touches) {
        //int angleRand = arc4random_uniform(360);
        //[self generateBubble:angleRand];
        //NSLog(@"Touched point is %f %f", [touch locationInView:self.view].x,[touch locationInView:self.view].y);
        CGPoint location = [touch locationInNode:self];
        
        CGPoint center = CGPointMake(185.5,
                                     335);
        CGFloat distance = sqrtf((location.x-center.x)*(location.x-center.x)+ (location.y-center.y)*(location.y-center.y));
        if (distance>=110&&distance<=170){
            //            SKSpriteNode *sprite = [SKSpriteNode spriteNodeWithImageNamed:@"greenring"];
            //            sprite.name = @"green";
            //            sprite.xScale = .5;
            //            sprite.yScale = .5;
            //            sprite.position = location;
            //            [self addChild: sprite];
            //NSLog(@"Touched red ring");
            //SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:location];
            //NSArray *touchedNodes = [self nodesAtPoint:location];
            //for(touchedNode in touchedNodes){
            //    NSLog(@"Touched %@",[touchedNode name]);
            //    if([touchedNode.name isEqual:@"red"]){
            //        [touchedNode removeFromParent];
            //    }
            //}
            NSLog(@"Touched red ring.");
            for(SKNode *childNode in self.children){
                if([childNode.name isEqual:@"red"]){
                    double distance = hypotf(childNode.position.x - location.x, childNode.position.y - location.y);
                    if (distance < 40){
                        [childNode removeAllActions];
                        [childNode removeFromParent];
                        self.scoreLabel.text=[NSString stringWithFormat:@"%i",[self.scoreLabel.text intValue]+100*self.combo];
                        self.chain=self.chain+1;
                        self.chainLabel.text=[NSString stringWithFormat:@"%i",self.chain];
                        if(self.combo!=0){
                            self.comboLabel.text=[NSString stringWithFormat:@"X%i",self.combo];
                        }
                    }
                }
            }
        }
        if (distance>=255&&distance<=315){
            NSLog(@"Touched green ring");
            //            SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:location];
            //            NSArray *touchedNodes = [self nodesAtPoint:location];
            //            for(touchedNode in touchedNodes){
            //                NSLog(@"Touched %@",[touchedNode name]);
            //                if([touchedNode.name isEqual:@"green"]){
            //                    [touchedNode removeFromParent];
            //                }
            //            }
            for(SKNode *childNode in self.children){
                if([childNode.name isEqual:@"green"]){
                    double distance = hypotf(childNode.position.x - location.x, childNode.position.y - location.y);
                    if (distance < 40){
                        [childNode removeAllActions];
                        [childNode removeFromParent];
                        self.scoreLabel.text=[NSString stringWithFormat:@"%i",[self.scoreLabel.text intValue]+100*self.combo];
                        self.chain=self.chain+1;
                        self.chainLabel.text=[NSString stringWithFormat:@"%i",self.chain];
                        if(self.combo!=0){
                            self.comboLabel.text=[NSString stringWithFormat:@"X%i",self.combo];
                        }
                    }
                }
            }
        }
        
        //NSLog(@"Distance is %f", distance);
    }
}


-(void)generateBubble:(NSNumber*)angleNum {
    int angle = [angleNum intValue];
    //int randColor = arc4random_uniform(100);
    CGPoint location = CGPointMake(CGRectGetMidX(self.frame),
                                   CGRectGetMidY(self.frame));
    SKSpriteNode *sprite = [SKSpriteNode spriteNodeWithImageNamed:@"redring"];
    sprite.name = @"red";
    //if(randColor<50){
    //    sprite = [SKSpriteNode spriteNodeWithImageNamed:@"greenring"];
    //    sprite.name = @"green";
    //}
    sprite.xScale = .5;
    sprite.yScale = .5;
    sprite.position = location;
    double dx = 0;
    double dy=0;
    NSLog(@"%i",angle);
    if(angle==0){
        dx=0;
        dy=141;
    }else if(angle==45){
        dx=99.7;
        dy=99.7;
    }else if(angle==90){
        dx=141;
        dy=0;
    }else if(angle==135){
        dx=99.7;
        dy=-99.7;
    }else if(angle==180){
        dx=0;
        dy=-180;
    }else if(angle==225){
        dx=-99.7;
        dy=-99.7;
    }else if(angle==270){
        dx=-141;
        dy=0;
    }else if(angle==315){
        dx=-99.7;
        dy=99.7;
    }
    SKAction *action = [SKAction moveByX:dx y:dy duration:1];
    [sprite runAction:[SKAction repeatActionForever:action]];
    SKAction *grow = [SKAction scaleTo:1.5 duration:1];
    [sprite runAction:grow];
    [self addChild:sprite];
    [self performSelector:@selector(changeRedSprite:) withObject:sprite afterDelay:.8];
    [self performSelector:@selector(missedRing:) withObject:sprite afterDelay:1.2];
}
-(void)generateGreenBubble:(NSNumber*)angleNum {
    //int randColor = arc4random_uniform(100);
    int angle = [angleNum intValue];
    CGPoint location = CGPointMake(CGRectGetMidX(self.frame),
                                   CGRectGetMidY(self.frame));
    SKSpriteNode *sprite = [SKSpriteNode spriteNodeWithImageNamed:@"greenring"];
    sprite.name = @"green";
    //if(randColor<50){
    //    sprite = [SKSpriteNode spriteNodeWithImageNamed:@"greenring"];
    //    sprite.name = @"green";
    //}
    sprite.xScale = .5;
    sprite.yScale = .5;
    sprite.position = location;
    double dx = 0;
    double dy=0;
    NSLog(@"%i",angle);
    if(angle==0){
        dx=0;
        dy=141;
    }else if(angle==30){
        dx=70.5;
        dy=122.1;
    }else if(angle==150){
        dx=70.5;
        dy=-122.1;
    }else if(angle==180){
        dx=0;
        dy=-141;
    }else if(angle==210){
        dx=-70.5;
        dy=-122.1;
    }else if(angle==330){
        dx=-70.5;
        dy=122.1;
    }
    SKAction *action = [SKAction moveByX:dx y:dy duration:1];
    [sprite runAction:[SKAction repeatActionForever:action]];
    SKAction *grow = [SKAction scaleTo:1.5 duration:2];
    [sprite runAction:grow];
    [self addChild:sprite];
    [self performSelector:@selector(changeGreenSprite:) withObject:sprite afterDelay:1.8];
    [self performSelector:@selector(missedRing:) withObject:sprite afterDelay:2.2];
}
-(void)changeRedSprite:(SKSpriteNode*)sprite{
    [sprite setTexture:[SKTexture textureWithImageNamed:@"redringflash"]];
    //[self.rotater removeAllActions];
    //self.spinDirection=-self.spinDirection;
    //SKAction *rotation = [SKAction rotateByAngle: (self.spinDirection)*(M_PI/4.0) duration:5];
    //[self.rotater runAction: [SKAction repeatActionForever:rotation]];
}
-(void)changeGreenSprite:(SKSpriteNode*)sprite{
    [sprite setTexture:[SKTexture textureWithImageNamed:@"greenringflash"]];
    //[self.rotater removeAllActions];
    //self.spinDirection=-self.spinDirection;
    //SKAction *rotation = [SKAction rotateByAngle: (self.spinDirection)*(M_PI/4.0) duration:5];
    //[self.rotater runAction: [SKAction repeatActionForever:rotation]];
}
-(void)missedRing:(SKSpriteNode*)sprite{
    if([sprite hasActions]){
        [sprite removeFromParent];
        self.combo=1;
        self.comboLabel.text=@"X1";
        self.chain=0;
        self.chainLabel.text=@"0";
    }
}
-(void)update:(CFTimeInterval)currentTime {
    /* Called before each frame is rendered */
}

@end
