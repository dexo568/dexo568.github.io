
//
//  GameScene.h
//  Buoyancy
//

//  Copyright (c) 2014 Dex. All rights reserved.
//
#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>
#import <SpriteKit/SpriteKit.h>

@interface GameScene3 : SKScene
@property (assign) SystemSoundID chemistrySet;
@end
