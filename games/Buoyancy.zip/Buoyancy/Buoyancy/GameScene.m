//
//  GameScene.m
//  Buoyancy
//
//  Created by Dex on 11/15/14.
//  Copyright (c) 2014 Dex. All rights reserved.
//

#import "GameScene.h"
@import AVFoundation;
@interface GameScene ()
@property NSMutableArray *songArray;
@property NSMutableArray *greenSongArray;
@property (strong, nonatomic) AVAudioPlayer *songPlayer;
@property (strong, nonatomic) SKLabelNode *scoreLabel;
@property (strong, nonatomic) SKLabelNode *comboLabel;
@property (strong, nonatomic) SKLabelNode *chainLabel;
@property (strong,nonatomic) SKSpriteNode *rotater;
@property int spinDirection;
@property int combo;
@property int chain;
@end

@implementation GameScene

-(void)didMoveToView:(SKView *)view {
    self.songArray = [[NSMutableArray alloc] initWithObjects:@"8991:1",@"9287:6",@"9571:2",@"9804:3",@"10255:0",@"10466:6",@"10675:2",@"11046:3",@"11367:2",@"11580:5",@"12023:7",@"12230:6",@"12446:7",@"12811:5",@"13097:2",@"13344:3",@"13769:2",@"13966:4",@"14195:1",@"14539:6",@"14876:1",@"15087:4",@"15523:1",@"15722:6",@"15960:0",@"16296:5",@"16593:7",@"16818:4",@"17267:2",@"17467:6",@"17707:7",@"18043:4",@"18362:7",@"18597:3",@"19028:7",@"19241:6",@"19466:7",@"19804:6",@"20099:0",@"20321:4",@"20775:0",@"20972:3",@"21221:7",@"21549:6",@"21854:0",@"22087:6",@"22533:0",@"22744:6",@"22970:2",@"23285:3",@"23575:2",@"23794:5",@"24243:0",@"24473:6",@"24711:1",@"25042:3",@"25363:0",@"25609:3",@"26046:1",@"26247:3",@"26480:0",@"26799:3",@"27106:2",@"27337:4",@"27786:7",@"27995:6",@"28202:2",@"28550:3",@"28863:0",@"29097:4",@"29535:7",@"29751:6",@"29980:1",@"30303:4",@"30616:2",@"30852:5",@"31273:2",@"31489:5",@"31728:7",@"32055:4",@"32372:7",@"32602:5",@"33043:7",@"33243:5",@"33478:0",@"33814:4",@"34134:1",@"34360:6",@"34795:1",@"35003:4",@"35232:1",@"35555:5",@"35871:2",@"36118:5",@"36553:7",@"36750:4",@"36986:2",@"37306:5",@"37628:0",@"37844:4",@"38294:0",@"38513:4",@"38723:1",@"39038:6",@"39390:7",@"39610:5",@"40070:2",@"40269:6",@"40486:2",@"40806:3",@"41131:1",@"41372:5",@"41791:0",@"42007:3",@"42225:1",@"42533:4",@"42858:7",@"43105:5",@"43528:0",@"43741:3",@"44009:0",@"44329:6",@"44621:2",@"44843:5",@"45281:0",@"45510:5",@"45739:1",@"46058:5",@"46384:1",@"46608:5",@"47050:2",@"47277:6",@"47494:2",@"47794:5",@"48154:2",@"48393:3",@"48801:0",@"49005:4",@"49248:0",@"49574:3",@"49875:0",@"50118:6",@"50561:7",@"50773:4",@"51014:7",@"51300:3",@"51645:0",@"51884:5",@"52294:1",@"52502:4",@"52761:7",@"53073:4",@"53400:1",@"53637:3",@"54083:7",@"54283:4",@"54499:7",@"54821:4",@"55127:1",@"55383:3",@"55825:7",@"56031:6",@"56271:1",@"56493:5",@"56705:0",@"56930:3",@"57154:1",@"57545:5",@"57761:0",@"57984:4",@"58223:7",@"58429:3",@"58637:7",@"58875:3",@"59306:1",@"59514:5",@"59748:7",@"59965:5",@"60196:2",@"60418:5",@"60645:2",@"61036:3",@"61262:7",@"61501:5",@"61725:2",@"61957:5",@"62182:7",@"62411:5",@"62827:7",@"63034:4",@"63265:0",@"63484:6",@"63704:0",@"63931:4",@"64147:0",@"64365:6",@"64583:7",@"64813:3",@"65025:0",@"65252:3",@"65463:2",@"65687:5",@"65913:1",@"66121:3",@"66348:0",@"66804:3",@"66996:7",@"67221:4",@"67438:1",@"67666:6",@"67875:7",@"68094:3",@"68312:2",@"68537:5",@"68765:0",@"68979:6",@"69195:2",@"69414:3",@"69630:7",@"69850:5",@"70283:0",@"70505:6",@"70728:2",@"70946:4",@"71152:7",@"71575:4",@"71798:7",@"72030:5",@"72260:0",@"72481:6",@"72709:7",@"72915:6",@"73322:2",@"73523:6",@"73760:7",@"73967:5",@"74191:0",@"74407:6",@"74633:7",@"75043:4",@"75263:7",@"75495:5",@"75730:2",@"75959:3",@"76171:0",@"76399:6",@"76828:2",@"77026:3",@"77261:2",@"77493:4",@"77716:1",@"77928:6",@"78163:2",@"78384:5",@"78598:0",@"78823:5",@"79038:1",@"79261:5",@"79471:2",@"79683:6",@"79919:0",@"80134:6",@"80362:2",@"80800:3",@"80998:2",@"81214:4",@"81433:7",@"81660:6",@"81868:7",@"82092:5",@"82302:1",@"82523:3",@"82747:0",@"82976:5",@"83199:1",@"83414:3",@"83634:0",@"83855:3",@"84273:7",@"84612:4",@"84928:0",@"85166:5",@"85571:1",@"85787:5",@"86016:2",@"86356:5",@"86663:7",@"86911:6",@"87331:1",@"87551:4",@"87784:1",@"88111:3",@"88416:7",@"88670:3",@"89095:7",@"89309:5",@"89539:1",@"89878:3",@"90192:0",@"90433:5",@"90856:1",@"91074:4",@"91291:0",@"91609:3",@"91969:7",@"92172:5",@"92626:1",@"92820:3",@"93033:1",@"93358:5",@"93667:0",@"93881:4",@"94326:0",@"94544:3",@"94788:2",@"95113:3",@"95415:2",@"95647:3",@"96095:7",@"96315:3",@"96536:1",@"96865:5",@"97202:7",@"97413:4",@"97833:7",@"98060:6",@"98272:1",@"98605:6",@"98897:0",@"99119:3",@"99579:7",@"99791:3",@"100016:0",@"100363:3",@"100659:7",@"100914:3",@"101336:2",@"101545:5",@"101790:2",@"102106:3",@"102430:7",@"102661:6",@"103101:1",@"103317:3",@"103537:0",@"103884:5",@"104160:7",@"104396:6",@"104853:0",@"105058:6",@"105286:2",@"105606:4",@"105943:7",@"106143:3",@"106590:2",@"106823:6",@"107055:0",@"107367:6",@"107674:1",@"107905:6",@"108371:1",@"108584:6",@"108812:7",@"109130:4",@"109435:1",@"109680:4",@"110134:0",@"110346:5",@"110576:7",@"110903:5",@"111209:0",@"111448:3",@"111863:1",@"112080:6",@"112297:7",@"112648:5",@"112935:2",@"113170:3",@"113606:7",@"113852:5",@"114075:1",@"114362:6",@"114663:1",@"114894:3",@"115367:0",@"115580:4",@"115804:7",@"116124:3",@"116439:1",@"116662:4",@"117111:2",@"117341:4",@"117568:2",@"117889:5",@"118227:7",@"118449:4",@"118889:0",@"119110:5",@"119339:1",@"119628:4",@"119941:7",@"120172:5",@"120625:0",@"120846:6",@"121074:1",@"121391:5",@"121735:2",@"121949:6",@"122399:7",@"122606:3",@"122821:7",@"123131:6",@"123456:7",@"123692:6",@"124129:0",@"124366:5",@"124582:0",@"124886:5",@"125205:1",@"125436:5",@"125917:0",@"126115:4",@"126333:2",@"126664:5",@"126963:0",@"127172:6",@"127615:2",@"127853:5",@"128097:7",@"128415:6",@"128718:7",@"128944:5",@"129373:0",@"129602:5",@"129838:2",@"130141:3",@"130471:0",@"130705:5",@"131131:7",@"131359:5",@"131587:0",@"131909:6",@"132227:0",@"132444:6",@"132882:1",@"133112:4",@"133345:7",@"133666:3",@"133958:7",@"134196:5",@"134645:0",@"134857:6",@"135093:2",@"135428:4",@"135722:1",@"135940:3",@"136385:1",@"136620:6",@"136844:1",@"137184:4",@"137452:1",@"137679:5",@"138154:2",@"138377:5",@"138610:1",@"138953:3",@"139281:1",@"139493:4",@"139947:7",@"140146:4",@"140365:1",@"140569:4",@"140800:0",@"141008:6",@"141228:2",@"141641:6",@"141846:2",@"142074:5",@"142309:2",@"142531:5",@"142760:1",@"142980:3",@"143398:1",@"143603:6",@"143825:0",@"144051:4",@"144282:0",@"144502:4",@"144721:1",@"145137:6",@"145372:2",@"145591:5",@"145832:7",@"146054:3",@"146279:0",@"146480:6",@"146907:1",@"147136:5",@"147341:1",@"147571:3",@"147807:2",@"148007:4",@"148227:1",@"148437:3",@"148661:0",@"148870:3",@"149089:1",@"149305:3",@"149530:0",@"149750:5",@"149987:2",@"150187:5",@"150419:1",@"150859:3",@"151057:0",@"151272:4",@"151484:7",@"151716:6",@"151935:2",@"152152:5",@"152376:2",@"152592:6",@"152809:1",@"153031:3",@"153246:2",@"153476:6",@"153697:2",@"153908:3",@"154354:2",@"154575:3",@"154789:7",@"155019:5",@"155238:7",@"155643:3",@"155875:7",@"156119:6",@"156345:2",@"156563:6",@"156793:1",@"157000:5",@"157398:2",@"157603:5",@"157837:1",@"158065:3",@"158303:1",@"158519:5",@"158733:1",@"159155:5",@"159370:0",@"159592:4",@"159827:2",@"160056:6",@"160275:1",@"160484:5",@"160914:2",@"161126:3",@"161347:2",@"161572:6",@"161793:0",@"162010:3",@"162234:2",@"162459:3",@"162671:2",@"162887:4",@"163122:2",@"163339:5",@"163557:0",@"163773:4",@"164006:1",@"164218:3",@"164428:2",@"164871:6",@"165067:1",@"165281:4",@"165486:1",@"165713:6",@"165930:2",@"166152:6",@"166368:2",@"166585:5",@"166811:7",@"167031:3",@"167247:0",@"167476:6",@"167690:1",@"167919:5",@"168382:2",@"168717:5",@"168966:1",@"169197:5",@"169646:7",@"169892:5",@"170130:7",@"170354:4",@"170566:7",@"170800:5",@"171012:2",@"171426:6",@"171643:2",@"171866:5",@"172092:1",@"172337:6",@"172557:1",@"172769:6",@"173156:1",@"173384:6",@"173616:0",@"173838:3",@"174059:2",@"174287:6",@"174495:2",@"174945:4",@"175163:7",@"175381:4",@"175623:2",@"175840:4",@"176050:7",@"176257:4",@"176487:7",@"176702:3",@"176917:1",@"177144:5",@"177360:1",@"177572:3",@"177792:2",@"178030:4",@"178239:2",@"178459:5",@"178898:2",@"179106:4",@"179324:2",@"179530:5",@"179754:7",@"179974:3",@"180186:7",@"180403:5",@"180630:7",@"180849:3",@"181067:2",@"181285:4",@"181518:2",@"181729:3",@"181951:7",@"182399:4",@"182711:1",@"182946:3",@"183194:7",@"183680:5",@"183915:7",@"184143:3",@"184365:7",@"184585:3",@"184805:0",@"185016:5",@"185442:7",@"185675:6",@"185893:2",@"186122:6",@"186357:2",@"186583:6",@"186784:0",@"187215:4",@"187431:1",@"187647:3",@"187867:7",@"188089:6",@"188306:1",@"188524:5",@"188949:0",@"189161:6",@"189387:0",@"189609:3",@"189841:1",@"190069:4",@"190277:0",@"190499:3",@"190717:0",@"190941:3",@"191166:1",@"191383:5",@"191601:2",@"191813:5",@"192026:0",@"192246:5",@"192457:2",@"192863:4",@"193085:2",@"193315:5",@"193529:1",@"193765:3",@"193992:7",@"194212:4",@"194445:2",@"194664:4",@"194877:1",@"195094:6",@"195323:2",@"195552:4",@"195770:0",@"195982:5",@"196398:0",@"196726:6",@"197026:1",@"197262:6",@"197706:2",@"197944:3",@"198150:0",@"198486:3",@"198803:0",@"199028:5",@"199464:7",@"199666:5",@"199887:7",@"200337:6",@"200766:7",@"201213:6",@"201629:0",@"202087:4",@"202526:0",@"202976:6",@"203361:7", nil];
    self.greenSongArray=[[NSMutableArray alloc] initWithObjects:@"27335:1",@"27780:3",@"27996:5",@"28238:4",@"28724:1",@"29552:4",@"30436:0",@"31269:2",@"32156:5",@"33041:2",@"33921:0",@"34807:2",@"35652:0",@"36547:2",@"37428:0",@"38322:2",@"39173:5",@"40045:2",@"40908:1",@"41819:4",@"42023:5",@"42684:2",@"43563:5",@"44437:2",@"45293:1",@"46188:2",@"47058:5",@"47947:2",@"48817:5",@"49027:2",@"49685:0",@"50545:3",@"51438:1",@"52302:4",@"53192:1",@"54042:3",@"54924:5",@"55824:4",@"56045:5",@"56706:4",@"57559:1",@"58430:3",@"59345:5",@"60203:3",@"61074:0",@"61955:4",@"62804:5",@"63708:4",@"64621:5",@"65444:2",@"66341:5",@"67204:3",@"68067:0",@"68967:3",@"69869:1",@"70061:3",@"70708:1",@"71557:4",@"72443:0",@"73337:4",@"74213:1",@"75102:4",@"75964:1",@"76855:4",@"77074:1",@"77728:2",@"78582:1",@"79458:2",@"80329:1",@"81207:4",@"82127:5",@"82974:3",@"83854:5",@"84055:4",@"90866:1",@"91355:4",@"91768:5",@"92610:2",@"92939:0",@"93491:3",@"93818:5",@"94356:4",@"94735:1",@"95244:3",@"95575:1",@"96106:3",@"96472:1",@"96986:3",@"97349:5",@"97890:3",@"97989:1",@"98688:3",@"99563:0",@"99939:2",@"100455:0",@"101326:3",@"101680:1",@"102233:4",@"103118:1",@"103309:4",@"103525:5",@"103878:3",@"104186:5",@"104395:4",@"104876:5",@"105063:4",@"105724:1",@"106611:3",@"107466:0",@"108364:3",@"108704:0",@"109085:2",@"109265:5",@"110108:3",@"111001:0",@"111892:2",@"112086:5",@"112765:2",@"113623:1",@"114523:3",@"115400:5",@"115595:3",@"116237:1",@"117106:3",@"117987:0",@"118480:4",@"118923:0",@"119046:2",@"121096:1",@"121524:2",@"122424:0",@"123258:4",@"124143:5",@"124331:2",@"124551:1",@"125004:2",@"125900:0",@"126105:3",@"126758:0",@"127655:2",@"128507:5",@"129379:2",@"130286:0",@"131151:3",@"132005:0",@"132931:4",@"133108:0",@"133752:2",@"134642:0",@"135497:3",@"136413:5",@"136612:4",@"137272:5",@"139701:4",@"139915:0",@"140134:3",@"140788:0",@"141651:3",@"142528:1",@"143403:2",@"143644:1",@"144300:3",@"145146:5",@"146036:2",@"146519:0",@"146711:2",@"146923:5",@"147114:4",@"147781:5",@"149106:3",@"149328:0",@"149539:3",@"150419:1",@"152193:3",@"152396:5",@"152613:4",@"153068:1",@"153922:3",@"154148:0",@"154795:3",@"155688:0",@"156532:2",@"157412:1",@"157647:2",@"158298:1",@"159195:4",@"160077:1",@"160935:3",@"161136:5",@"161797:4",@"162675:1",@"163555:3",@"164473:1",@"164665:3",@"165299:5",@"167949:4",@"168172:0",@"168793:4",@"169674:0",@"170572:2",@"171446:1",@"171668:4",@"172308:5",@"173192:3",@"174050:1",@"174266:4",@"174466:1",@"174956:4",@"175799:0",@"176690:3",@"177559:5",@"178474:4",@"178659:5",@"179335:2",@"180200:0",@"181072:4",@"181980:0",@"182166:3",@"182809:0",@"183709:4",@"184594:0",@"184781:2",@"184986:5",@"185479:3",@"185704:5",@"186344:4",@"187215:5",@"188068:3",@"188969:0",@"189792:3",@"190706:1",@"191573:2",@"192478:1",@"193353:2",@"194210:5",@"195059:3",@"196000:1",@"196166:4",@"197667:5", nil];
    /* Setup your scene here */
    self.combo=1;
    self.chain=0;
    SKSpriteNode *background = [SKSpriteNode spriteNodeWithImageNamed:@"fourthBack"];
    //background.xScale=1.16;
    //background.yScale=1.16;
    background.position = CGPointMake(CGRectGetMidX(self.frame),
                                      CGRectGetMidY(self.frame));
    background.name=@"bg";
    [self addChild:background];
    
    self.rotater = [SKSpriteNode spriteNodeWithImageNamed:@"fourthBackRotater"];
    self.rotater.position = CGPointMake(CGRectGetMidX(self.frame),
                                      CGRectGetMidY(self.frame));
    self.rotater.name=@"rotater";
    [self addChild:self.rotater];
    SKAction *rotation = [SKAction rotateByAngle: M_PI/4.0 duration:5];
    [self.rotater runAction: [SKAction repeatActionForever:rotation]];
    self.spinDirection=1;
    CGPoint center = CGPointMake(185.5,
                                 335);
    //int xRand = arc4random_uniform(40)-20;
    //int yRand = arc4random_uniform(40)-20;
    NSString *songPath = [[NSBundle mainBundle] pathForResource:@"kissmeandsmile" ofType:@"mp3"];
    NSURL *songURL = [NSURL fileURLWithPath:songPath];
    NSError *error;
    self.songPlayer = [[AVAudioPlayer alloc]
                       initWithContentsOfURL:songURL error:&error];
    [self.songPlayer prepareToPlay];
    [self.songPlayer play];
    
    self.scoreLabel = [SKLabelNode labelNodeWithFontNamed:@"DINCondensed-Bold"];
    self.scoreLabel.text = @"0";
    self.scoreLabel.fontSize = 30;
    self.scoreLabel.horizontalAlignmentMode=SKLabelHorizontalAlignmentModeRight;
    self.scoreLabel.position = CGPointMake(370,640);
    [self addChild:self.scoreLabel];
    
    self.comboLabel = [SKLabelNode labelNodeWithFontNamed:@"DINCondensed-Bold"];
    self.comboLabel.text = @"X1";
    self.comboLabel.fontSize = 30;
    self.comboLabel.horizontalAlignmentMode=SKLabelHorizontalAlignmentModeRight;
    self.comboLabel.position = CGPointMake(370,610);
    [self addChild:self.comboLabel];
    
    self.chainLabel = [SKLabelNode labelNodeWithFontNamed:@"DINCondensed-Bold"];
    self.chainLabel.text = @"0";
    self.chainLabel.fontSize = 30;
    self.chainLabel.horizontalAlignmentMode=SKLabelHorizontalAlignmentModeRight;
    self.chainLabel.position = CGPointMake(370,580);
    [self addChild:self.chainLabel];
    
    for(NSString *bubbleGen in self.songArray){
        NSArray *genArray = [bubbleGen componentsSeparatedByString:@":"];
        int timeCode = [[genArray objectAtIndex:0] intValue];
        double timeCodeSeconds = timeCode*.001;
        timeCodeSeconds=timeCodeSeconds-2.4;
        int angle = [[genArray objectAtIndex:1] intValue]*45;
        
        [self performSelector:@selector(generateBubble:) withObject:[NSNumber numberWithInt:angle] afterDelay:timeCodeSeconds];
    }
    for(NSString *bubbleGen in self.greenSongArray){
        NSArray *genArray = [bubbleGen componentsSeparatedByString:@":"];
        int timeCode = [[genArray objectAtIndex:0] intValue];
        double timeCodeSeconds = timeCode*.001;
        timeCodeSeconds=timeCodeSeconds-2.4;
        int angle=0;
        if([[genArray objectAtIndex:1] intValue]==0){
            angle=0;
        }else if ([[genArray objectAtIndex:1] intValue]==1){
            angle=30;
        }else if ([[genArray objectAtIndex:1] intValue]==2){
            angle=150;
        }else if ([[genArray objectAtIndex:1] intValue]==3){
            angle=180;
        }else if ([[genArray objectAtIndex:1] intValue]==4){
            angle=210;
        }else if ([[genArray objectAtIndex:1] intValue]==5){
            angle=330;
        }
        [self performSelector:@selector(generateGreenBubble:) withObject:[NSNumber numberWithInt:angle] afterDelay:timeCodeSeconds];
    }
    
//   for(int i =0;i<375;i++){
//        for(int j=0; j<667; j++){
//            CGPoint currentPoint = CGPointMake(i, j);
//            CGFloat distance = sqrtf((currentPoint.x-center.x)*(currentPoint.x-center.x)+(currentPoint.y-center.y)*(currentPoint.y-center.y));
//            if (distance>=275&&distance<=295){
//                SKSpriteNode *sprite = [SKSpriteNode spriteNodeWithImageNamed:@"Spaceship"];
//                sprite.xScale = .05;
//                sprite.yScale = .05;
//                sprite.alpha=.01;
//                sprite.position=currentPoint;
//                [self addChild:sprite];
//                
//                NSLog(@"Putting spaceship at %i.%i",i,j);
//
//            }
//        }
//    }
    
    
    

    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    /* Called when a touch begins */
    
    for (UITouch *touch in touches) {
        //int angleRand = arc4random_uniform(360);
        //[self generateBubble:angleRand];
        //NSLog(@"Touched point is %f %f", [touch locationInView:self.view].x,[touch locationInView:self.view].y);
        CGPoint location = [touch locationInNode:self];
        
        CGPoint center = CGPointMake(185.5,
                                    335);
        CGFloat distance = sqrtf((location.x-center.x)*(location.x-center.x)+ (location.y-center.y)*(location.y-center.y));
        if (distance>=110&&distance<=170){
//            SKSpriteNode *sprite = [SKSpriteNode spriteNodeWithImageNamed:@"greenring"];
//            sprite.name = @"green";
//            sprite.xScale = .5;
//            sprite.yScale = .5;
//            sprite.position = location;
//            [self addChild: sprite];
            //NSLog(@"Touched red ring");
            //SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:location];
            //NSArray *touchedNodes = [self nodesAtPoint:location];
            //for(touchedNode in touchedNodes){
            //    NSLog(@"Touched %@",[touchedNode name]);
            //    if([touchedNode.name isEqual:@"red"]){
            //        [touchedNode removeFromParent];
            //    }
            //}
            NSLog(@"Touched red ring.");
            for(SKNode *childNode in self.children){
                if([childNode.name isEqual:@"red"]){
                    double distance = hypotf(childNode.position.x - location.x, childNode.position.y - location.y);
                    if (distance < 40){
                        [childNode removeAllActions];
                        [childNode removeFromParent];
                        self.scoreLabel.text=[NSString stringWithFormat:@"%i",[self.scoreLabel.text intValue]+100*self.combo];
                        self.chain=self.chain+1;
                        self.chainLabel.text=[NSString stringWithFormat:@"%i",self.chain];
                        self.combo=floor(self.chain/10);
                        if(self.combo!=0){
                            self.comboLabel.text=[NSString stringWithFormat:@"X%i",self.combo];
                        }
                    }
                }
            }
            
        }
        if (distance>=255&&distance<=315){
            NSLog(@"Touched green ring");
//            SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:location];
//            NSArray *touchedNodes = [self nodesAtPoint:location];
//            for(touchedNode in touchedNodes){
//                NSLog(@"Touched %@",[touchedNode name]);
//                if([touchedNode.name isEqual:@"green"]){
//                    [touchedNode removeFromParent];
//                }
//            }
            for(SKNode *childNode in self.children){
                if([childNode.name isEqual:@"green"]){
                    double distance = hypotf(childNode.position.x - location.x, childNode.position.y - location.y);
                    if (distance < 40){
                        [childNode removeAllActions];
                        [childNode removeFromParent];
                        self.scoreLabel.text=[NSString stringWithFormat:@"%i",[self.scoreLabel.text intValue]+100*self.combo];
                        self.chain=self.chain+1;
                        self.chainLabel.text=[NSString stringWithFormat:@"%i",self.chain];
                        if(self.combo!=0){
                            self.comboLabel.text=[NSString stringWithFormat:@"X%i",self.combo];
                        }
                    }
                }
            }
        }
        //NSLog(@"Distance is %f", distance);
    }
}


-(void)generateBubble:(NSNumber*)angleNum {
    int angle = [angleNum intValue];
    //int randColor = arc4random_uniform(100);
    CGPoint location = CGPointMake(CGRectGetMidX(self.frame),
                                   CGRectGetMidY(self.frame));
    SKSpriteNode *sprite = [SKSpriteNode spriteNodeWithImageNamed:@"redring"];
    sprite.name = @"red";
    //if(randColor<50){
    //    sprite = [SKSpriteNode spriteNodeWithImageNamed:@"greenring"];
    //    sprite.name = @"green";
    //}
    sprite.xScale = .5;
    sprite.yScale = .5;
    sprite.position = location;
    double dx = 0;
    double dy=0;
    NSLog(@"%i",angle);
    if(angle==0){
        dx=0;
        dy=141;
    }else if(angle==45){
        dx=99.7;
        dy=99.7;
    }else if(angle==90){
        dx=141;
        dy=0;
    }else if(angle==135){
        dx=99.7;
        dy=-99.7;
    }else if(angle==180){
        dx=0;
        dy=-180;
    }else if(angle==225){
        dx=-99.7;
        dy=-99.7;
    }else if(angle==270){
        dx=-141;
        dy=0;
    }else if(angle==315){
        dx=-99.7;
        dy=99.7;
    }
    SKAction *action = [SKAction moveByX:dx y:dy duration:1];
    [sprite runAction:[SKAction repeatActionForever:action]];
    SKAction *grow = [SKAction scaleTo:1.5 duration:1];
    [sprite runAction:grow];
    [self addChild:sprite];
    [self performSelector:@selector(changeRedSprite:) withObject:sprite afterDelay:.8];
    [self performSelector:@selector(missedRing:) withObject:sprite afterDelay:1.2];
}
-(void)generateGreenBubble:(NSNumber*)angleNum {
    //int randColor = arc4random_uniform(100);
    int angle = [angleNum intValue];
    CGPoint location = CGPointMake(CGRectGetMidX(self.frame),
                                   CGRectGetMidY(self.frame));
    SKSpriteNode *sprite = [SKSpriteNode spriteNodeWithImageNamed:@"greenring"];
    sprite.name = @"green";
    //if(randColor<50){
    //    sprite = [SKSpriteNode spriteNodeWithImageNamed:@"greenring"];
    //    sprite.name = @"green";
    //}
    sprite.xScale = .5;
    sprite.yScale = .5;
    sprite.position = location;
    double dx = 0;
    double dy=0;
    NSLog(@"%i",angle);
    if(angle==0){
        dx=0;
        dy=141;
    }else if(angle==30){
        dx=70.5;
        dy=122.1;
    }else if(angle==150){
        dx=70.5;
        dy=-122.1;
    }else if(angle==180){
        dx=0;
        dy=-141;
    }else if(angle==210){
        dx=-70.5;
        dy=-122.1;
    }else if(angle==330){
        dx=-70.5;
        dy=122.1;
    }

    SKAction *action = [SKAction moveByX:dx y:dy duration:1];
    [sprite runAction:[SKAction repeatActionForever:action]];
    SKAction *grow = [SKAction scaleTo:1.5 duration:2];
    [sprite runAction:grow];
    [self addChild:sprite];
    [self performSelector:@selector(changeGreenSprite:) withObject:sprite afterDelay:1.8];
    [self performSelector:@selector(missedRing:) withObject:sprite afterDelay:2.2];
}

-(void)changeRedSprite:(SKSpriteNode*)sprite{
    [sprite setTexture:[SKTexture textureWithImageNamed:@"redringflash"]];
    //[self.rotater removeAllActions];
    //self.spinDirection=-self.spinDirection;
    //SKAction *rotation = [SKAction rotateByAngle: (self.spinDirection)*(M_PI/4.0) duration:5];
    //[self.rotater runAction: [SKAction repeatActionForever:rotation]];
}
-(void)changeGreenSprite:(SKSpriteNode*)sprite{
    [sprite setTexture:[SKTexture textureWithImageNamed:@"greenringflash"]];
    //[self.rotater removeAllActions];
    //self.spinDirection=-self.spinDirection;
    //SKAction *rotation = [SKAction rotateByAngle: (self.spinDirection)*(M_PI/4.0) duration:5];
    //[self.rotater runAction: [SKAction repeatActionForever:rotation]];
}
-(void)missedRing:(SKSpriteNode*)sprite{
    if([sprite hasActions]){
        [sprite removeFromParent];
        self.combo=1;
        self.comboLabel.text=@"X1";
        self.chain=0;
        self.chainLabel.text=@"0";
    }
}
-(void)update:(CFTimeInterval)currentTime {
    /* Called before each frame is rendered */
}

@end
