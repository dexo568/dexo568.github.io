//
//  GameScene.m
//  Buoyancy
//
//  Created by Dex on 11/15/14.
//  Copyright (c) 2014 Dex. All rights reserved.
//

#import "GameScene2.h"
@import AVFoundation;
@interface GameScene2 ()
@property NSMutableArray *songArray;
@property NSMutableArray *greenSongArray;
@property (strong, nonatomic) AVAudioPlayer *songPlayer;
@property (strong, nonatomic) SKLabelNode *scoreLabel;
@property (strong, nonatomic) SKLabelNode *comboLabel;
@property (strong, nonatomic) SKLabelNode *chainLabel;
@property (strong,nonatomic) SKSpriteNode *rotater;
@property int spinDirection;
@property int combo;
@property int chain;
@end

@implementation GameScene2

-(void)didMoveToView:(SKView *)view {
    self.songArray = [[NSMutableArray alloc] initWithObjects:@"22533:2",@"22895:6",@"23060:0",@"23410:5",@"23803:0",@"24126:4",@"24535:2",@"24900:3",@"28294:2",@"28680:3",@"28838:7",@"29167:3",@"29537:0",@"29913:5",@"30289:7",@"30668:5",@"33747:1",@"34076:4",@"34452:0",@"34774:3",@"34971:7",@"35376:4",@"35821:7",@"36051:6",@"36465:7",@"36937:3",@"37357:2",@"37526:3",@"37876:7",@"39493:3",@"39663:2",@"39845:5",@"40198:2",@"40709:4",@"41140:7",@"41290:5",@"41459:7",@"41636:4",@"41813:7",@"42358:4",@"42721:2",@"43098:5",@"43260:7",@"43636:3",@"45248:0",@"46356:4",@"48115:2",@"49286:6",@"50932:7",@"51934:5",@"52238:0",@"53808:6",@"54776:7",@"55075:3",@"56705:1",@"57937:4",@"59509:2",@"60753:4",@"62425:1",@"63276:6",@"63616:1",@"65250:4",@"66254:7",@"66581:6",@"79824:7",@"80194:5",@"80358:7",@"80706:5",@"81085:2",@"81426:4",@"81779:1",@"82159:5",@"85541:0",@"85916:5",@"86396:0",@"86776:3",@"87241:0",@"87542:4",@"87881:2",@"90951:4",@"91308:0",@"91675:6",@"91853:0",@"92203:3",@"92611:0",@"92779:5",@"93097:1",@"93298:3",@"93815:2",@"94163:4",@"94559:1",@"94739:4",@"95052:0",@"96319:5",@"96711:2",@"96866:6",@"97040:0",@"97380:4",@"97877:1",@"98256:4",@"98426:7",@"98602:3",@"98792:1",@"98955:3",@"99589:0",@"99849:6",@"100241:2",@"100419:6",@"100754:7",@"102379:4",@"103511:1",@"105276:6",@"106486:7",@"108079:4",@"109027:2",@"109374:6",@"110994:7",@"111916:5",@"112233:0",@"113838:6",@"115067:2",@"116700:5",@"117975:1",@"119591:6",@"120658:0",@"122442:4",@"123398:7",@"123693:6",@"125714:7",@"126428:6",@"126626:1",@"127174:3",@"127532:7",@"127909:4",@"128270:2",@"128644:6",@"129037:7",@"129240:3",@"129611:0",@"129996:4",@"130145:0",@"130515:3",@"130689:2",@"130880:5",@"131280:2",@"131657:5",@"132022:2",@"132208:6",@"132578:2",@"132977:5",@"133150:1",@"133530:5",@"133690:1",@"133882:3",@"134250:2",@"134626:3",@"135022:2",@"135205:6",@"135543:0",@"136032:6",@"136487:1",@"136887:4",@"137272:7",@"138475:4",@"138871:1",@"139038:3",@"139408:2",@"139570:6",@"139757:0",@"140172:3",@"140532:2",@"140871:4",@"141041:0",@"141369:4",@"141743:0",@"141910:3",@"142277:0",@"142653:3",@"143020:0",@"143368:5",@"143725:7",@"143906:4",@"144282:0",@"144653:3",@"144824:2",@"145170:5",@"145343:2",@"145525:5",@"145879:1",@"146217:4",@"146598:7",@"146774:3",@"147114:1",@"147489:4",@"147647:2",@"148023:6",@"148373:7",@"148724:5",@"149827:7",@"150501:5",@"151107:1",@"151297:5",@"151464:7",@"151973:5",@"152677:1",@"153357:5",@"153975:7",@"154139:6",@"154305:0",@"154832:3",@"155544:2",@"156257:6",@"156812:1",@"156974:4",@"157141:1",@"157697:4",@"158380:2",@"159093:3",@"159691:1",@"159863:6",@"160548:0",@"160948:6",@"161122:2",@"161469:5",@"161867:1",@"162242:3",@"162598:1",@"162936:6",@"166314:7",@"166668:6",@"166836:1",@"167182:4",@"167545:1",@"167915:6",@"168298:7",@"168671:4",@"171662:2",@"171993:4",@"172385:2",@"172552:6",@"172903:7",@"173322:4",@"173474:2",@"173847:5",@"174202:7",@"174604:4",@"174929:0",@"175308:3",@"175477:0",@"175823:5",@"177040:2",@"177473:3",@"177635:7",@"177815:4",@"178182:1",@"178349:5",@"178691:1",@"179108:5",@"179609:7",@"179771:3",@"179955:2",@"180382:6",@"180553:1",@"180735:3",@"181075:0",@"181256:6",@"181617:2",@"183229:4",@"184441:0",@"186141:5",@"187374:2",@"188998:4",@"189851:0",@"190247:3",@"191831:0",@"192876:3",@"194722:1",@"195947:5",@"197562:0",@"198754:4",@"200445:0",@"201362:4",@"201694:2",@"203306:5",@"204277:0",@"204578:3", nil];
    
    
        self.greenSongArray=[[NSMutableArray alloc] initWithObjects:@"10711:1",@"10881:2",@"11046:0",@"11548:3",@"12301:5",@"13004:2",@"13505:0",@"13683:2",@"13864:5",@"14411:4",@"15136:1",@"15868:2",@"16366:5",@"16546:3",@"16740:1",@"17254:4",@"17972:5",@"18689:3",@"19213:0",@"19415:2",@"19600:5",@"20150:2",@"20859:5",@"21578:4",@"22106:5",@"22496:4",@"23005:0",@"23752:2",@"24464:0",@"24983:3",@"25175:1",@"25363:3",@"25926:5",@"26591:2",@"27355:0",@"27895:4",@"28247:0",@"28768:4",@"29499:5",@"30202:3",@"30753:5",@"30953:4",@"31130:0",@"31680:3",@"32404:5",@"33126:2",@"33666:0",@"34015:3",@"34560:5",@"35279:2",@"35957:5",@"36544:3",@"36756:0",@"36918:3",@"37472:5",@"38186:4",@"38901:0",@"39431:2",@"39799:5",@"40337:3",@"41050:0",@"41784:3",@"42320:0",@"42511:2",@"42687:5",@"43220:2",@"43919:1",@"44612:2",@"45195:1",@"45550:2",@"46088:1",@"46780:2",@"47465:0",@"47649:3",@"48227:1",@"48987:3",@"49692:1",@"50389:3",@"50552:5",@"51110:2",@"51864:5",@"52546:2",@"53187:0",@"53377:4",@"53923:5",@"54716:2",@"55408:1",@"56072:2",@"56254:5",@"56778:4",@"57556:5",@"58266:4",@"58965:5",@"59133:2",@"59648:1",@"60407:4",@"61119:0",@"61798:3",@"61986:5",@"62505:2",@"63281:0",@"63919:3",@"64622:5",@"64818:2",@"65366:0",@"66115:3",@"66784:1",@"67504:2",@"67692:0",@"68215:3",@"68937:0",@"69671:3",@"70347:0",@"70874:4",@"71069:1",@"71236:3",@"71757:5",@"72461:2",@"73192:5",@"73706:4",@"73900:1",@"74070:2",@"74593:5",@"75314:2",@"76011:0",@"76554:2",@"76750:0",@"76925:4",@"77466:1",@"78161:4",@"78874:5",@"79452:3",@"79794:0",@"80329:3",@"81037:1",@"81727:4",@"82307:1",@"82485:3",@"82647:5",@"83207:3",@"83875:5",@"84592:4",@"85175:5",@"85507:2",@"86035:0",@"86739:4",@"87419:5",@"88039:4",@"88212:0",@"88379:4",@"88921:0",@"89606:2",@"90363:0",@"90900:3",@"91253:0",@"91791:2",@"92526:0",@"93237:4",@"93782:5",@"93958:4",@"94130:0",@"94679:2",@"95405:5",@"96097:3",@"96639:1",@"96998:4",@"97549:5",@"98251:2",@"98935:5",@"99487:3",@"99666:0",@"99842:3",@"100383:1",@"101033:4",@"101782:1",@"102319:4",@"102676:1",@"103239:3",@"103901:0",@"104644:3",@"104810:5",@"105387:4",@"106129:0",@"106850:4",@"107508:5",@"107701:4",@"108237:5",@"108968:3",@"109647:0",@"110348:2",@"110543:0",@"111083:3",@"111833:1",@"112533:4",@"113247:1",@"113412:2",@"113926:0",@"114712:3",@"115371:5",@"116096:4",@"116273:1",@"116842:4",@"117563:1",@"118249:3",@"118953:1",@"119137:2",@"119717:5",@"120464:3",@"121134:0",@"121854:4",@"122045:0",@"122552:3",@"123282:5",@"123974:2",@"124715:1",@"124902:4",@"125302:1",@"125479:3",@"125648:1",@"126232:2",@"138809:5",@"139513:2",@"139702:5",@"140291:2",@"140994:5",@"141156:4",@"141725:5",@"141890:2",@"142427:5",@"143110:4",@"143287:5",@"143890:2",@"144038:0",@"144563:3",@"144736:0",@"145285:2",@"145468:0",@"146002:4",@"146171:1",@"146717:4",@"146881:0",@"147431:4",@"147592:0",@"148133:2",@"148290:0",@"148859:2",@"149013:5",@"149195:3",@"149383:0",@"149579:4",@"149763:1",@"149938:2",@"150121:0",@"150291:2",@"150473:0",@"150659:3",@"150835:0",@"151011:2",@"151173:5",@"151370:2",@"151543:0",@"151730:3",@"151891:0",@"152083:4",@"152260:5",@"152443:4",@"152608:0",@"152811:2",@"152995:1",@"153166:2",@"153326:0",@"153530:2",@"153708:1",@"153890:3",@"154060:1",@"154248:3",@"154423:5",@"154594:4",@"154772:5",@"154951:2",@"155139:1",@"155304:2",@"155481:1",@"155669:2",@"155845:0",@"156019:3",@"156176:0",@"156368:2",@"156546:1",@"156726:2",@"156893:5",@"157099:3",@"157281:5",@"157468:4",@"157636:0",@"157823:4",@"157996:1",@"158175:3",@"158349:1",@"158532:2",@"158705:1",@"158882:3",@"159065:0",@"159264:4",@"159432:5",@"159619:3",@"160016:5",@"160369:3",@"161069:0",@"161809:2",@"162505:5",@"163211:4",@"163933:0",@"164630:4",@"165341:5",@"165916:4",@"166090:5",@"166781:4",@"167509:0",@"168173:4",@"168942:0",@"169107:4",@"169681:5",@"170365:4",@"171062:5",@"171800:2",@"171975:0",@"172533:4",@"173250:0",@"173938:3",@"174699:0",@"174874:4",@"175458:1",@"176145:4",@"176864:5",@"177587:4",@"177753:1",@"178317:4",@"179003:5",@"179716:3",@"180457:5",@"180626:3",@"181200:1",@"181899:4",@"182626:5",@"183356:2",@"183506:0",@"184098:4",@"184809:5",@"185520:2",@"186232:0",@"187030:3",@"187668:5",@"188381:4",@"188563:5",@"189128:4",@"189874:0",@"190532:3",@"191259:1",@"191416:3",@"191966:0",@"192704:3",@"193389:5",@"194099:3",@"194247:5",@"194799:3",@"195548:1",@"196272:4",@"196657:1",@"196990:4",@"197148:1",@"197679:3",@"198442:0",@"199146:4",@"199862:5",@"200017:2",@"200544:0",@"201314:3",@"202009:1",@"202727:2",@"202881:5",@"203413:3",@"204170:0",@"204847:4",@"205607:5",@"205800:3",@"206305:5",@"207003:3",@"207738:1",@"208408:2",@"208983:0",@"209148:2",@"209310:5",@"209844:2",@"210577:0",@"211270:4",@"211815:0",@"212710:4",@"213430:5",@"214110:2",@"214672:1",@"214854:3",@"215011:1",@"215553:2",@"216252:1",@"216944:2",@"217491:0",@"217877:3",@"218427:5",@"219168:3",@"219857:5",@"220405:4",@"220580:5",@"220745:2",@"221298:1",@"222023:2",@"222718:5",@"223281:4",@"223631:5",@"224164:3",@"224894:1",@"225555:2",@"226167:5",@"226340:2",@"226516:1",@"227057:4",@"227743:1",@"228417:4",@"228975:5",@"229166:2",@"229346:1",@"229543:3", nil];
    /* Setup your scene here */
    self.combo=1;
    self.chain=0;
    SKSpriteNode *background = [SKSpriteNode spriteNodeWithImageNamed:@"fourthBack"];
    //background.xScale=1.16;
    //background.yScale=1.16;
    background.position = CGPointMake(CGRectGetMidX(self.frame),
                                      CGRectGetMidY(self.frame));
    background.name=@"bg";
    [self addChild:background];
    
    self.rotater = [SKSpriteNode spriteNodeWithImageNamed:@"fourthBackRotater"];
    self.rotater.position = CGPointMake(CGRectGetMidX(self.frame),
                                        CGRectGetMidY(self.frame));
    self.rotater.name=@"rotater";
    [self addChild:self.rotater];
    SKAction *rotation = [SKAction rotateByAngle: M_PI/4.0 duration:5];
    [self.rotater runAction: [SKAction repeatActionForever:rotation]];
    self.spinDirection=1;
    CGPoint center = CGPointMake(185.5,
                                 335);
    //int xRand = arc4random_uniform(40)-20;
    //int yRand = arc4random_uniform(40)-20;
    NSString *songPath = [[NSBundle mainBundle] pathForResource:@"wildnothing" ofType:@"mp3"];
    NSURL *songURL = [NSURL fileURLWithPath:songPath];
    NSError *error;
    self.songPlayer = [[AVAudioPlayer alloc]
                       initWithContentsOfURL:songURL error:&error];
    [self.songPlayer prepareToPlay];
    [self.songPlayer play];
    
    self.scoreLabel = [SKLabelNode labelNodeWithFontNamed:@"DINCondensed-Bold"];
    self.scoreLabel.text = @"0";
    self.scoreLabel.fontSize = 30;
    self.scoreLabel.horizontalAlignmentMode=SKLabelHorizontalAlignmentModeRight;
    self.scoreLabel.position = CGPointMake(370,640);
    [self addChild:self.scoreLabel];
    
    self.comboLabel = [SKLabelNode labelNodeWithFontNamed:@"DINCondensed-Bold"];
    self.comboLabel.text = @"X1";
    self.comboLabel.fontSize = 30;
    self.comboLabel.horizontalAlignmentMode=SKLabelHorizontalAlignmentModeRight;
    self.comboLabel.position = CGPointMake(370,610);
    [self addChild:self.comboLabel];
    
    self.chainLabel = [SKLabelNode labelNodeWithFontNamed:@"DINCondensed-Bold"];
    self.chainLabel.text = @"0";
    self.chainLabel.fontSize = 30;
    self.chainLabel.horizontalAlignmentMode=SKLabelHorizontalAlignmentModeRight;
    self.chainLabel.position = CGPointMake(370,580);
    [self addChild:self.chainLabel];
    
    for(NSString *bubbleGen in self.songArray){
        NSArray *genArray = [bubbleGen componentsSeparatedByString:@":"];
        int timeCode = [[genArray objectAtIndex:0] intValue];
        double timeCodeSeconds = timeCode*.001;
        timeCodeSeconds=timeCodeSeconds-.5;
        int angle = [[genArray objectAtIndex:1] intValue]*45;
        
        [self performSelector:@selector(generateBubble:) withObject:[NSNumber numberWithInt:angle] afterDelay:timeCodeSeconds];
    }
    for(NSString *bubbleGen in self.greenSongArray){
        NSArray *genArray = [bubbleGen componentsSeparatedByString:@":"];
        int timeCode = [[genArray objectAtIndex:0] intValue];
        double timeCodeSeconds = timeCode*.001;
        timeCodeSeconds=timeCodeSeconds-2.25;
        int angle=0;
        if([[genArray objectAtIndex:1] intValue]==0){
            angle=0;
        }else if ([[genArray objectAtIndex:1] intValue]==1){
            angle=30;
        }else if ([[genArray objectAtIndex:1] intValue]==2){
            angle=150;
        }else if ([[genArray objectAtIndex:1] intValue]==3){
            angle=180;
        }else if ([[genArray objectAtIndex:1] intValue]==4){
            angle=210;
        }else if ([[genArray objectAtIndex:1] intValue]==5){
            angle=330;
        }
        [self performSelector:@selector(generateGreenBubble:) withObject:[NSNumber numberWithInt:angle] afterDelay:timeCodeSeconds];
    }
    
    //   for(int i =0;i<375;i++){
    //        for(int j=0; j<667; j++){
    //            CGPoint currentPoint = CGPointMake(i, j);
    //            CGFloat distance = sqrtf((currentPoint.x-center.x)*(currentPoint.x-center.x)+(currentPoint.y-center.y)*(currentPoint.y-center.y));
    //            if (distance>=275&&distance<=295){
    //                SKSpriteNode *sprite = [SKSpriteNode spriteNodeWithImageNamed:@"Spaceship"];
    //                sprite.xScale = .05;
    //                sprite.yScale = .05;
    //                sprite.alpha=.01;
    //                sprite.position=currentPoint;
    //                [self addChild:sprite];
    //
    //                NSLog(@"Putting spaceship at %i.%i",i,j);
    //
    //            }
    //        }
    //    }
    
    
    
    
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    /* Called when a touch begins */
    
    for (UITouch *touch in touches) {
        //int angleRand = arc4random_uniform(360);
        //[self generateBubble:angleRand];
        //NSLog(@"Touched point is %f %f", [touch locationInView:self.view].x,[touch locationInView:self.view].y);
        CGPoint location = [touch locationInNode:self];
        
        CGPoint center = CGPointMake(185.5,
                                     335);
        CGFloat distance = sqrtf((location.x-center.x)*(location.x-center.x)+ (location.y-center.y)*(location.y-center.y));
        if (distance>=110&&distance<=170){
            //            SKSpriteNode *sprite = [SKSpriteNode spriteNodeWithImageNamed:@"greenring"];
            //            sprite.name = @"green";
            //            sprite.xScale = .5;
            //            sprite.yScale = .5;
            //            sprite.position = location;
            //            [self addChild: sprite];
            //NSLog(@"Touched red ring");
            //SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:location];
            //NSArray *touchedNodes = [self nodesAtPoint:location];
            //for(touchedNode in touchedNodes){
            //    NSLog(@"Touched %@",[touchedNode name]);
            //    if([touchedNode.name isEqual:@"red"]){
            //        [touchedNode removeFromParent];
            //    }
            //}
            NSLog(@"Touched red ring.");
            for(SKNode *childNode in self.children){
                if([childNode.name isEqual:@"red"]){
                    double distance = hypotf(childNode.position.x - location.x, childNode.position.y - location.y);
                    if (distance < 40){
                        [childNode removeAllActions];
                        [childNode removeFromParent];
                        self.scoreLabel.text=[NSString stringWithFormat:@"%i",[self.scoreLabel.text intValue]+100*self.combo];
                        self.chain=self.chain+1;
                        self.chainLabel.text=[NSString stringWithFormat:@"%i",self.chain];
                        if(self.combo!=0){
                            self.comboLabel.text=[NSString stringWithFormat:@"X%i",self.combo];
                        }
                    }
                }
            }
        }
        if (distance>=255&&distance<=315){
            NSLog(@"Touched green ring");
            //            SKSpriteNode *touchedNode = (SKSpriteNode *)[self nodeAtPoint:location];
            //            NSArray *touchedNodes = [self nodesAtPoint:location];
            //            for(touchedNode in touchedNodes){
            //                NSLog(@"Touched %@",[touchedNode name]);
            //                if([touchedNode.name isEqual:@"green"]){
            //                    [touchedNode removeFromParent];
            //                }
            //            }
            for(SKNode *childNode in self.children){
                if([childNode.name isEqual:@"green"]){
                    double distance = hypotf(childNode.position.x - location.x, childNode.position.y - location.y);
                    if (distance < 40){
                        [childNode removeAllActions];
                        [childNode removeFromParent];
                        self.scoreLabel.text=[NSString stringWithFormat:@"%i",[self.scoreLabel.text intValue]+100*self.combo];
                        self.chain=self.chain+1;
                        self.chainLabel.text=[NSString stringWithFormat:@"%i",self.chain];
                        if(self.combo!=0){
                            self.comboLabel.text=[NSString stringWithFormat:@"X%i",self.combo];
                        }
                    }
                }
            }
        }

        //NSLog(@"Distance is %f", distance);
    }
}


-(void)generateBubble:(NSNumber*)angleNum {
    int angle = [angleNum intValue];
    //int randColor = arc4random_uniform(100);
    CGPoint location = CGPointMake(CGRectGetMidX(self.frame),
                                   CGRectGetMidY(self.frame));
    SKSpriteNode *sprite = [SKSpriteNode spriteNodeWithImageNamed:@"redring"];
    sprite.name = @"red";
    //if(randColor<50){
    //    sprite = [SKSpriteNode spriteNodeWithImageNamed:@"greenring"];
    //    sprite.name = @"green";
    //}
    sprite.xScale = .5;
    sprite.yScale = .5;
    sprite.position = location;
    double dx = 0;
    double dy=0;
    NSLog(@"%i",angle);
    if(angle==0){
        dx=0;
        dy=141;
    }else if(angle==45){
        dx=99.7;
        dy=99.7;
    }else if(angle==90){
        dx=141;
        dy=0;
    }else if(angle==135){
        dx=99.7;
        dy=-99.7;
    }else if(angle==180){
        dx=0;
        dy=-180;
    }else if(angle==225){
        dx=-99.7;
        dy=-99.7;
    }else if(angle==270){
        dx=-141;
        dy=0;
    }else if(angle==315){
        dx=-99.7;
        dy=99.7;
    }
    SKAction *action = [SKAction moveByX:dx y:dy duration:1];
    [sprite runAction:[SKAction repeatActionForever:action]];
    SKAction *grow = [SKAction scaleTo:1.5 duration:1];
    [sprite runAction:grow];
    [self addChild:sprite];
    [self performSelector:@selector(changeRedSprite:) withObject:sprite afterDelay:.8];
    [self performSelector:@selector(missedRing:) withObject:sprite afterDelay:1.2];
}
-(void)generateGreenBubble:(NSNumber*)angleNum {
    //int randColor = arc4random_uniform(100);
    int angle = [angleNum intValue];
    CGPoint location = CGPointMake(CGRectGetMidX(self.frame),
                                   CGRectGetMidY(self.frame));
    SKSpriteNode *sprite = [SKSpriteNode spriteNodeWithImageNamed:@"greenring"];
    sprite.name = @"green";
    //if(randColor<50){
    //    sprite = [SKSpriteNode spriteNodeWithImageNamed:@"greenring"];
    //    sprite.name = @"green";
    //}
    sprite.xScale = .5;
    sprite.yScale = .5;
    sprite.position = location;
    double dx = 0;
    double dy=0;
    NSLog(@"%i",angle);
    if(angle==0){
        dx=0;
        dy=141;
    }else if(angle==30){
        dx=70.5;
        dy=122.1;
    }else if(angle==150){
        dx=70.5;
        dy=-122.1;
    }else if(angle==180){
        dx=0;
        dy=-141;
    }else if(angle==210){
        dx=-70.5;
        dy=-122.1;
    }else if(angle==330){
        dx=-70.5;
        dy=122.1;
    }
    SKAction *action = [SKAction moveByX:dx y:dy duration:1];
    [sprite runAction:[SKAction repeatActionForever:action]];
    SKAction *grow = [SKAction scaleTo:1.5 duration:2];
    [sprite runAction:grow];
    [self addChild:sprite];
    [self performSelector:@selector(changeGreenSprite:) withObject:sprite afterDelay:1.8];
    [self performSelector:@selector(missedRing:) withObject:sprite afterDelay:2.2];
}
-(void)changeRedSprite:(SKSpriteNode*)sprite{
    [sprite setTexture:[SKTexture textureWithImageNamed:@"redringflash"]];
    //[self.rotater removeAllActions];
    //self.spinDirection=-self.spinDirection;
    //SKAction *rotation = [SKAction rotateByAngle: (self.spinDirection)*(M_PI/4.0) duration:5];
    //[self.rotater runAction: [SKAction repeatActionForever:rotation]];
}
-(void)changeGreenSprite:(SKSpriteNode*)sprite{
    [sprite setTexture:[SKTexture textureWithImageNamed:@"greenringflash"]];
    //[self.rotater removeAllActions];
    //self.spinDirection=-self.spinDirection;
    //SKAction *rotation = [SKAction rotateByAngle: (self.spinDirection)*(M_PI/4.0) duration:5];
    //[self.rotater runAction: [SKAction repeatActionForever:rotation]];
}
-(void)missedRing:(SKSpriteNode*)sprite{
    if([sprite hasActions]){
        [sprite removeFromParent];
        self.combo=1;
        self.comboLabel.text=@"X1";
        self.chain=0;
        self.chainLabel.text=@"0";
    }
}
-(void)update:(CFTimeInterval)currentTime {
    /* Called before each frame is rendered */
}

@end
