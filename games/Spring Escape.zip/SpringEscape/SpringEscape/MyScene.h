//
//  MyScene.h
//  SpringEscape
//

//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>
#import <AVFoundation/AVFoundation.h>

@interface MyScene : SKScene <SKPhysicsContactDelegate>
@property int mostRecentLHS;
@property SKSpriteNode *player;
@property int playerSpeed;
@property (nonatomic) AVAudioPlayer * backgroundMusicPlayer;
@property BOOL isTouching;
@property const uint32_t playerCategory;
@property const uint32_t springCategory;
@property int downSpeed;
@property int levelsCleared;
@property int score;
@property (strong,nonatomic) SKLabelNode *scoreLabel;
@property (strong,nonatomic) SKLabelNode *gameOverLabel;

@property NSMutableArray *floors;
@property NSMutableArray *springs;
@property double gap;
@property BOOL startedDescent;
@end
