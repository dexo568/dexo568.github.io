//
//  MyScene.m
//  SpringEscape
//
//  Created by Shyamolee Desai on 10/3/14.
//  Copyright (c) 2014 __MyCompanyName__. All rights reserved.
//

#import "MyScene.h"
#import <SpriteKit/SpriteKit.h>
@import AVFoundation;

@implementation MyScene

-(id)initWithSize:(CGSize)size {
    
    if (self = [super initWithSize:size]) {
        
        self.levelsCleared = 0;
        self.downSpeed=-35;
        self.playerCategory = 0x1 << 0;
        self.springCategory = 0x1 << 1;
        self.physicsWorld.contactDelegate =self;
        self.physicsWorld.gravity = CGVectorMake(0.0f, -1.0f);
        
        self.score = 0;
        [self setUpScore];
        
        self.physicsBody = [SKPhysicsBody bodyWithEdgeLoopFromRect:self.frame];

        
        [self credits];
       
        CGSize sizeOfBottom = CGSizeMake(320, 5);
        CGPoint centerOfBottom = CGPointMake(160, 2.5);
        UIColor *bottomColor = [UIColor clearColor];
        SKSpriteNode *bottom = [SKSpriteNode spriteNodeWithColor:bottomColor size:sizeOfBottom];
        bottom.position = centerOfBottom;
        bottom.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:bottom.size];
        bottom.physicsBody.dynamic = NO;
        bottom.physicsBody.node.name = @"bottom";
        [self addChild:bottom];
        
        
        CGPoint startFloorPoint = CGPointMake(CGRectGetMidX(self.frame),180);
        SKSpriteNode *startFloor = [SKSpriteNode spriteNodeWithImageNamed:@"floor"];
        startFloor.physicsBody =[SKPhysicsBody bodyWithRectangleOfSize:startFloor.size];
        startFloor.physicsBody.dynamic = NO;
        startFloor.physicsBody.node.name = @"startFloor";
        startFloor.position = startFloorPoint;
        SKAction *waitForDescend = [SKAction moveByX:0 y:0 duration:(NSTimeInterval)8];
        SKAction *startFloorDescend = [SKAction moveByX:0 y:self.downSpeed duration:(NSTimeInterval)1];
        NSMutableArray *startActions = [NSMutableArray arrayWithObjects:waitForDescend,[SKAction repeatActionForever:startFloorDescend], nil];
        [startFloor runAction:[SKAction sequence:startActions]];
        
        [self addChild:startFloor];
        
        
        SKSpriteNode *title = [SKSpriteNode spriteNodeWithImageNamed:@"title"];
        title.position = CGPointMake(0, -100);
        [startFloor addChild:title];
        
        
        self.floors = [NSMutableArray arrayWithObjects:startFloor, nil];
        self.springs = [NSMutableArray arrayWithObjects: nil];
        /* Setup your scene here */
        self.playerSpeed=40;
        self.player = [SKSpriteNode spriteNodeWithImageNamed:@"player"];
        CGPoint bottomCenter = CGPointMake(CGRectGetMidX(self.frame),200);
        self.player.position=bottomCenter;
        CGSize playerBody = CGSizeMake(20, 35);
        self.player.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:playerBody];
        self.player.physicsBody.node.name=@"player";
        self.player.physicsBody.affectedByGravity = YES;
        self.player.physicsBody.dynamic = YES;
        self.player.physicsBody.categoryBitMask = self.playerCategory;
        self.player.physicsBody.contactTestBitMask = self.springCategory;
        self.player.physicsBody.collisionBitMask = 1;
        self.player.physicsBody.mass = 50;
        self.player.physicsBody.density = 1;
        self.player.physicsBody.friction = 0;
        self.player.physicsBody.allowsRotation = NO;
        [self.player setScale:1.4];
        SKTexture *playerFrame = [SKTexture textureWithImageNamed:@"player"];
        SKTexture *playerFrame1 = [SKTexture textureWithImageNamed:@"player1"];
        NSMutableArray *playerTextures = [NSMutableArray arrayWithObjects:playerFrame, playerFrame1, nil];
        SKAction *playerAnimation = [SKAction animateWithTextures:playerTextures timePerFrame:.5];
        [self.player runAction:[SKAction repeatActionForever:playerAnimation]];

        CGVector initialVelocity = CGVectorMake(self.playerSpeed, 0);
        self.player.physicsBody.velocity = initialVelocity;
        //SKAction *move = [SKAction moveByX:self.playerSpeed y:0 duration:(NSTimeInterval)1];
      
        //[self.player runAction:[SKAction repeatActionForever:move] withKey: @"move"];
        [self addChild:self.player];
        
        self.mostRecentLHS=1000;
//        self.backgroundColor = [SKColor colorWithRed:0.15 green:0.15 blue:0.3 alpha:1.0];
        
        
        SKSpriteNode *background = [SKSpriteNode spriteNodeWithImageNamed:@"background"];
        background.position = CGPointMake(CGRectGetMidX(self.frame),CGRectGetMidY(self.frame));
        background.zPosition = -1;
        SKAction *parallax = [SKAction moveByX:0 y:-10 duration:(NSTimeInterval)1];
        [background runAction:[SKAction repeatActionForever:parallax]];
        [self addChild:background];
        [self scrollBackground];

        
        
        NSError *error;
        NSURL * backgroundMusicURL = [[NSBundle mainBundle] URLForResource:@"GameJam" withExtension:@"m4a"];
        self.backgroundMusicPlayer = [[AVAudioPlayer alloc] initWithContentsOfURL:backgroundMusicURL error:&error];
        self.backgroundMusicPlayer.numberOfLoops = -1;
        [self.backgroundMusicPlayer prepareToPlay];
        [self.backgroundMusicPlayer play];
        
        
        self.gap=4;
        [self makePlatformLevel];
        //[NSTimer scheduledTimerWithTimeInterval:self.gap //2.5
        //                                 target:self
        //                               selector:@selector(makePlatformLevel)
        //                               userInfo:nil
        //                                repeats:NO];
        
    }
    return self;
}
-(void)scrollBackground{
    SKSpriteNode *background = [SKSpriteNode spriteNodeWithImageNamed:@"background"];
    background.position = CGPointMake(CGRectGetMidX(self.frame),CGRectGetMidY(self.frame)+520);
    background.zPosition = -1;
    SKAction *parallax = [SKAction moveByX:0 y:-10 duration:(NSTimeInterval)1];
    [background runAction:[SKAction repeatActionForever:parallax]];
    [self addChild:background];
    [NSTimer scheduledTimerWithTimeInterval:52
                                      target:self
                                    selector:@selector(scrollBackground)
                                    userInfo:nil
                                     repeats:NO];
}
-(void)makePlatformLevel{
    
    bool isTooClose = true;
    int randoOriginLHS = (arc4random()%4)*40-120;
    
    while(isTooClose){
        randoOriginLHS = (arc4random()%4)*40-120;
        if(abs(randoOriginLHS-self.mostRecentLHS)>=60){
            isTooClose=false;
        }
    }
    
    
    int randoOriginRHS = randoOriginLHS + 390;
    
//    
//    NSLog(@"Left: %i", randoOriginLHS);
//    NSLog(@"Right: %i", randoOriginRHS);
    
    
    CGPoint floorRHSPoint = CGPointMake(randoOriginRHS,600);
    SKSpriteNode *floorRHS = [SKSpriteNode spriteNodeWithImageNamed:@"floor"];
    floorRHS.physicsBody =[SKPhysicsBody bodyWithRectangleOfSize:floorRHS.size];
    floorRHS.physicsBody.dynamic = NO;
    floorRHS.physicsBody.node.name = @"floor";
    floorRHS.position = floorRHSPoint;
    
    
    CGPoint floorLHSPoint = CGPointMake(randoOriginLHS,600);
    SKSpriteNode *floorLHS = [SKSpriteNode spriteNodeWithImageNamed:@"floor"];
    floorLHS.physicsBody = [SKPhysicsBody bodyWithRectangleOfSize:floorLHS.size];
    floorLHS.physicsBody.dynamic = NO;
    floorLHS.physicsBody.node.name = @"floor";
    floorLHS.position = floorLHSPoint;
    
    SKAction *floorDescend = [SKAction moveByX:0 y:self.downSpeed duration:(NSTimeInterval)1];

    [floorRHS runAction:[SKAction repeatActionForever:floorDescend]withKey:@"descend"];
    [floorLHS runAction:[SKAction repeatActionForever:floorDescend]withKey:@"descend"];
    [self addChild:floorRHS];
    [self addChild:floorLHS];
    [self.floors addObject:floorRHS];
    [self.floors addObject:floorLHS];
    if(self.levelsCleared%10==0&&self.levelsCleared!=0){
        self.downSpeed = self.downSpeed-5;
        NSLog(@"SPEEDUP!");
        
        SKAction *descendUpdate = [SKAction moveByX:0 y:self.downSpeed duration:(NSTimeInterval)1];
        for(int i=0; i<[self.springs count]; i++){
            SKSpriteNode *curSpring = [self.springs objectAtIndex:(NSUInteger)i];
            [curSpring removeActionForKey:@"descend"];
            [curSpring runAction:[SKAction repeatActionForever:descendUpdate]withKey:@"descend"];
            
        }
        for(int i=0; i<[self.floors count]; i++){
            SKSpriteNode *curFloor = [self.floors objectAtIndex:(NSUInteger)i];
            [curFloor removeActionForKey:@"descend"];
            [curFloor runAction:[SKAction repeatActionForever:descendUpdate]withKey:@"descend"];
        }
       
        self.gap=(double)140/(double)(-self.downSpeed); // gap = time, downspeed = velocity, 5 = constant. every gap seconds, enw platform spawned with downspeed v
         NSLog(@"gap: %f; downspeed: %d", self.gap, self.downSpeed);
    }
    [NSTimer scheduledTimerWithTimeInterval:self.gap //2.5
                                                               target:self
                                                             selector:@selector(makePlatformLevel)
                                                             userInfo:nil
                                                              repeats:NO];
    self.levelsCleared = self.levelsCleared+1;
    self.mostRecentLHS = randoOriginLHS;
    self.score += 10;
    self.scoreLabel.text = [NSString stringWithFormat:@"Score: %04u", self.score];
    self.scoreLabel.zPosition = 1;
}

-(void) dropSpring:(CGPoint)springLocation {
    
    SKSpriteNode *spring = [SKSpriteNode spriteNodeWithImageNamed:@"spring"];
    spring.physicsBody =[SKPhysicsBody bodyWithRectangleOfSize:spring.size];
    spring.physicsBody.dynamic = NO;
    spring.physicsBody.node.name=@"spring";
    spring.physicsBody.categoryBitMask = self.springCategory;
    spring.physicsBody.contactTestBitMask = self.playerCategory;
    spring.physicsBody.collisionBitMask = 1;
    
    
    CGPoint rayEnd = CGPointMake(springLocation.x, springLocation.y-80);
    SKPhysicsBody *nearestFloor = [self.physicsWorld bodyAlongRayStart:springLocation end:rayEnd];
    if([nearestFloor.node.name isEqual:@"floor"]){
        spring.position = CGPointMake(springLocation.x,nearestFloor.node.position.y+27);
        SKAction *springDescend = [SKAction moveByX:0 y:self.downSpeed duration:(NSTimeInterval)1];
        SKTexture *springFrame = [SKTexture textureWithImageNamed:@"spring"];
        SKTexture *springFrame1 = [SKTexture textureWithImageNamed:@"spring1"];
        NSMutableArray *springTextures = [NSMutableArray arrayWithObjects:springFrame, springFrame1, nil];
        SKAction *springAction = [SKAction animateWithTextures:springTextures timePerFrame:.1];
        [spring runAction:[SKAction repeatActionForever:springAction]];
        [spring runAction:[SKAction repeatActionForever:springDescend]withKey:@"descend"];
        [self addChild:spring];
        [self.springs addObject:spring];
    } else if ([nearestFloor.node.name isEqual:@"startFloor"]) {
        spring.position = CGPointMake(springLocation.x-160,27);
        SKTexture *springFrame = [SKTexture textureWithImageNamed:@"spring"];
        SKTexture *springFrame1 = [SKTexture textureWithImageNamed:@"spring1"];
        NSMutableArray *springTextures = [NSMutableArray arrayWithObjects:springFrame, springFrame1, nil];
        SKAction *springAction = [SKAction animateWithTextures:springTextures timePerFrame:.1];
        [spring runAction:[SKAction repeatActionForever:springAction]];
        [nearestFloor.node addChild:spring];
        
    }
}

- (void)didBeginContact:(SKPhysicsContact *)contact
{
    SKPhysicsBody *firstBody, *secondBody;
    
    if (contact.bodyA.categoryBitMask < contact.bodyB.categoryBitMask) {
        firstBody = contact.bodyA;
        secondBody = contact.bodyB;
    } else {
        firstBody = contact.bodyB;
        secondBody = contact.bodyA;
    }
    NSLog(@"Trying to log collision");
    NSLog(@"%@",firstBody.node.name);
    NSLog(@"%@",secondBody.node.name);
    if([firstBody.node.name isEqual: @"player"] && [secondBody.node.name isEqual:@"spring"]){
        [self playerJump:firstBody.node];
    }else if([secondBody.node.name isEqual: @"player"] && [firstBody.node.name isEqual:@"spring"]){
        [self playerJump:secondBody.node];
    } else if ([firstBody.node.name isEqual:@"bottom"] || [secondBody.node.name isEqual:@"bottom"]) {
        SKAction *killPlayer = [SKAction removeFromParent];
        [self.player runAction:killPlayer];
        [self killScreen];
    }
    
}

-(void)playerJump: (SKNode *) collidingPlayer {

    CGVector zeroY = CGVectorMake(self.player.physicsBody.velocity.dx,0);
    self.player.physicsBody.velocity = zeroY;
    CGVector directionVector = CGVectorMake(0, 7);
    [self.player.physicsBody applyImpulse:directionVector];
    //NSLog(@"Jump Triggered");
    self.score += 5;
    self.scoreLabel.text = [NSString stringWithFormat:@"Score: %04u", self.score];
    
}

-(void)setUpScore {
    
    self.scoreLabel = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
    self.scoreLabel.text = [NSString stringWithFormat:@"Score: %04u", 0];
    self.scoreLabel.fontSize = 14;
    self.scoreLabel.position = CGPointMake(20 + self.scoreLabel.frame.size.width/2, self.size.height - (20 + self.scoreLabel.frame.size.height/2));
    [self addChild:self.scoreLabel];
}

-(void) killScreen {
    self.gameOverLabel = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
    self.gameOverLabel.text =[NSString stringWithFormat:@"GAME OVER"];
    self.gameOverLabel.fontSize = 36;
    self.gameOverLabel.position = CGPointMake(160,230);
    [self addChild:self.gameOverLabel];
}

-(void) credits {
//    self.gameTitle = [SKLabelNode labelNodeWithFontNamed:@"Chalkduster"];
//    self.gameTitle.text = [NSString stringWithFormat:@"SPRING ESCAPE"];
//    self.gameTitle.fontSize = 36;
//    self.gameTitle.position = CGPointMake(0, -25);
//    [self.startfloor addChild: self.gameTitle];
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    /* Called when a touch begins */
    
    
    for (UITouch *touch in touches) {
        
        CGPoint location = [touch locationInNode:self];

        if ([self.player containsPoint:location]) {
            self.playerSpeed=-self.playerSpeed;
            CGVector  reverseDir = CGVectorMake(self.playerSpeed, self.player.physicsBody.velocity.dy);
            self.player.physicsBody.velocity=reverseDir;
        }else if([self.gameOverLabel containsPoint:location]){
            NSLog(@"clicked game over screen");
            CGSize window = CGSizeMake(320, 560);
            MyScene * scene = [MyScene sceneWithSize:self.view.bounds.size];
            scene.scaleMode = SKSceneScaleModeAspectFill;
            [self.view presentScene:scene];
        } else {
            [self dropSpring:location];
        }

    }
}
                            

-(void)update:(CFTimeInterval)currentTime {
    /* Called before each frame is rendered */
}

@end
