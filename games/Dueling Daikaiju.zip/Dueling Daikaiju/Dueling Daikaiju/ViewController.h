//
//  ViewController.h
//  Dueling Daikaiju
//
//  Created by Dex on 10/28/14.
//  Copyright (c) 2014 Dex. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

