//
//  DaikaijuTwoPlayer.h
//  Dueling Daikaiju
//
//  Created by Dex on 11/4/14.
//  Copyright (c) 2014 Dex. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>
@interface DaikaijuTwoPlayer : UIViewController
@property (assign) SystemSoundID daikaijuSound;
@property NSMutableArray *leftGrid;
@property NSMutableArray *rightGrid;
@property NSMutableArray *p1HitsMisses;
@property NSMutableArray *p2HitsMisses;
@property NSMutableArray *p1SunkShips;
@property NSMutableArray *p2SunkShips;
@end
