//
//  DaikaijuSinglePlayer.m
//  Dueling Daikaiju
//
//  Created by Dex on 10/28/14.
//  Copyright (c) 2014 Dex. All rights reserved.
//

#import "DaikaijuTwoPlayer.h"
@import AVFoundation;
@interface DaikaijuTwoPlayer ()
@property (weak, nonatomic) IBOutlet UIButton *lockButton;
@property (strong, nonatomic) AVAudioPlayer *monsterNoisePlayer;

//Player One Variables
@property (weak, nonatomic) IBOutlet UIImageView *fiveShip;
@property (weak, nonatomic) IBOutlet UIImageView *fourShip;
@property (weak, nonatomic) IBOutlet UIImageView *threeShipOne;
@property (weak, nonatomic) IBOutlet UIImageView *threeShipTwo;
@property (weak, nonatomic) IBOutlet UIImageView *twoShip;
@property bool fiveDragging;
@property bool fourDragging;
@property bool threeOneDragging;
@property bool threeTwoDragging;
@property bool twoDragging;
@property bool fiveOnBoard;
@property bool fourOnBoard;
@property bool threeOneOnBoard;
@property bool threeTwoOnBoard;
@property bool twoOnBoard;
@property int playerShipsRemaining;

//Player Two Variables
@property (weak, nonatomic) IBOutlet UIImageView *fiveShip2;
@property (weak, nonatomic) IBOutlet UIImageView *fourShip2;
@property (weak, nonatomic) IBOutlet UIImageView *threeShipOne2;
@property (weak, nonatomic) IBOutlet UIImageView *threeShipTwo2;
@property (weak, nonatomic) IBOutlet UIImageView *twoShip2;
@property bool fiveDragging2;
@property bool fourDragging2;
@property bool threeOneDragging2;
@property bool threeTwoDragging2;
@property bool twoDragging2;
@property bool fiveOnBoard2;
@property bool fourOnBoard2;
@property bool threeOneOnBoard2;
@property bool threeTwoOnBoard2;
@property bool twoOnBoard2;
@property int playerShipsRemaining2;


//Vestigial Computer Variables
@property bool sinkingShip;
@property bool reachedOtherEndOfShip;
@property int sinkingShipOrientation;
@property int sinkingShipIndex;
@property int computerShipsRemaining;

//Other Variables
@property (weak, nonatomic) IBOutlet UIImageView *backGround;
@property bool gameOver;
@property int turn;
@property bool shipsLockedIn;
@property (weak, nonatomic) IBOutlet UIImageView *pickScroll;
@property (weak, nonatomic) IBOutlet UIImageView *LockInScroll;
@property NSString *p1name;
@property NSString *p2name;
@end

@implementation DaikaijuTwoPlayer

- (void)viewDidLoad {
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //Game Variables/Vestigial Computer Variables
    int nameDecider = arc4random_uniform(100);
    if(nameDecider<50){
        self.p1name=@"1";
        self.p2name=@"2";
    }else{
        self.p1name=@"2";
        self.p2name=@"1";
    }
    self.lockButton.layer.zPosition=10;
    self.gameOver=false;
    self.shipsLockedIn=false;
    self.computerShipsRemaining=5;
    self.leftGrid = [[NSMutableArray alloc]init];
    self.rightGrid = [[NSMutableArray alloc]init];
    self.p1HitsMisses = [[NSMutableArray alloc]init];
    self.p2HitsMisses = [[NSMutableArray alloc]init];
    self.p1SunkShips = [[NSMutableArray alloc]init];
    self.p2SunkShips = [[NSMutableArray alloc]init];
    self.turn=1;
    self.sinkingShip=false;
    self.reachedOtherEndOfShip=false;
    self.sinkingShipOrientation=-1;
    self.sinkingShipIndex=0;
    
    //Player 1 Variables
    self.fiveDragging=false;
    self.fourDragging=false;
    self.threeOneDragging=false;
    self.threeTwoDragging=false;
    self.twoDragging=false;
    self.fiveOnBoard=false;
    self.fourOnBoard=false;
    self.threeOneOnBoard=false;
    self.threeTwoOnBoard=false;
    self.twoOnBoard=false;
    self.playerShipsRemaining=5;
    
    //Player2Variables
    self.fiveDragging2=false;
    self.fourDragging2=false;
    self.threeOneDragging2=false;
    self.threeTwoDragging2=false;
    self.twoDragging2=false;
    self.fiveOnBoard2=false;
    self.fourOnBoard2=false;
    self.threeOneOnBoard2=false;
    self.threeTwoOnBoard2=false;
    self.twoOnBoard2=false;
    self.playerShipsRemaining2=5;
    
    //setup the insane z-inversion paradigm
    self.fiveShip.layer.zPosition = 1;
    self.fourShip.layer.zPosition = 1;
    self.threeShipOne.layer.zPosition = 1;
    self.threeShipTwo.layer.zPosition = 1;
    self.twoShip.layer.zPosition=1;
    self.fiveShip2.layer.zPosition = -1;
    self.fourShip2.layer.zPosition = -1;
    self.threeShipOne2.layer.zPosition = -1;
    self.threeShipTwo2.layer.zPosition = -1;
    self.twoShip2.layer.zPosition= -1;
    
    for(int setup=0;setup<100;setup++){
        [self.leftGrid insertObject:[NSNumber numberWithInteger:0] atIndex:setup];
        [self.rightGrid insertObject:[NSNumber numberWithInteger:0] atIndex:setup];
    }
    int i = 0;
    for(int y = 184; y<584; y+=40){
        for(int x = 568; x<968; x+=40){
            UIButton *gridCellButton = [UIButton buttonWithType:UIButtonTypeRoundedRect];
            gridCellButton.frame = CGRectMake(x, y, 40, 40);
            gridCellButton.tag = i;
            [gridCellButton setTitle:@"" forState:UIControlStateNormal];
            [gridCellButton addTarget:self action:@selector(gridClicked:) forControlEvents:UIControlEventTouchUpInside];
            [self.view addSubview:gridCellButton];
            i++;
        }
    }
}
- (IBAction)debugZSwap:(id)sender {
    [self changeTurn];
}

-(void)swapZPositions
{
    self.fiveShip.layer.zPosition = -self.fiveShip.layer.zPosition;
    self.fourShip.layer.zPosition = -self.fourShip.layer.zPosition;
    self.threeShipOne.layer.zPosition = -self.threeShipOne.layer.zPosition;
    self.threeShipTwo.layer.zPosition = -self.threeShipTwo.layer.zPosition;
    self.twoShip.layer.zPosition=-self.twoShip.layer.zPosition;
    self.fiveShip2.layer.zPosition = -self.fiveShip2.layer.zPosition;
    self.fourShip2.layer.zPosition = -self.fourShip2.layer.zPosition;
    self.threeShipOne2.layer.zPosition = -self.threeShipOne2.layer.zPosition;
    self.threeShipTwo2.layer.zPosition = -self.threeShipTwo2.layer.zPosition;
    self.twoShip2.layer.zPosition= -self.twoShip2.layer.zPosition;
    if(self.turn==1){
        for(UIImageView *ships in self.p1SunkShips){
            [ships setHidden:true];
        }
        for(UIImageView *ships in self.p2SunkShips){
            [ships setHidden:false];
        }
        for(UIImageView *hitMiss in self.p1HitsMisses){
            
            [hitMiss setTranslatesAutoresizingMaskIntoConstraints:YES];
            hitMiss.center = CGPointMake(hitMiss.center.x+512, hitMiss.center.y);
        }
        for(UIImageView *hitMiss in self.p2HitsMisses){
            [hitMiss setTranslatesAutoresizingMaskIntoConstraints:YES];
            hitMiss.center = CGPointMake(hitMiss.center.x-512, hitMiss.center.y);
        }
    }else{
        for(UIImageView *ships in self.p1SunkShips){
            [ships setHidden:false];
        }
        for(UIImageView *ships in self.p2SunkShips){
            [ships setHidden:true];
        }
        for(UIImageView *hitMiss in self.p1HitsMisses){
            [hitMiss setTranslatesAutoresizingMaskIntoConstraints:YES];
            hitMiss.center = CGPointMake(hitMiss.center.x-512, hitMiss.center.y);
        }
        for(UIImageView *hitMiss in self.p2HitsMisses){
            [hitMiss setTranslatesAutoresizingMaskIntoConstraints:YES];
            hitMiss.center = CGPointMake(hitMiss.center.x+512, hitMiss.center.y);
        }
    }
    
}
-(void)changeTurn{
    NSString *player1Alert=@"It's Player ";
    player1Alert=[player1Alert stringByAppendingString:self.p1name];
    player1Alert=[player1Alert stringByAppendingString:@"'s Turn!"];
    NSString *player2Alert=@"It's Player ";
    player2Alert=[player2Alert stringByAppendingString:self.p2name];
    player2Alert=[player2Alert stringByAppendingString:@"'s Turn!"];
    if(self.turn==1){
        UIAlertController * alert=   [UIAlertController
                                      alertControllerWithTitle:player2Alert
                                      message:@"Please press OK and pass the iPad to that Player."
                                      preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction
                             actionWithTitle:@"OK"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [alert dismissViewControllerAnimated:YES completion:nil];
                                 [self firstAlert];
                                 
                             }];
        [alert addAction:ok];
        
        [self presentViewController:alert animated:YES completion:nil];
        self.turn=2;
    }else{
        UIAlertController * alert=   [UIAlertController
                                      alertControllerWithTitle:player1Alert
                                      message:@"Please press OK and pass the iPad to that Player."
                                      preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction
                             actionWithTitle:@"OK"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [alert dismissViewControllerAnimated:YES completion:nil];
                                 [self firstAlert];
                                 
                             }];
        [alert addAction:ok];
        
        [self presentViewController:alert animated:YES completion:nil];
        self.turn=1;
    }
}
-(void)firstAlert{
    self.backGround.layer.zPosition=5;
    UIAlertController * alert2=   [UIAlertController
                                   alertControllerWithTitle:@"It's Your Turn!"
                                   message:@"Press OK to take your turn."
                                   preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* ok2 = [UIAlertAction
                          actionWithTitle:@"OK"
                          style:UIAlertActionStyleDefault
                          handler:^(UIAlertAction * action)
                          {
                              [alert2 dismissViewControllerAnimated:YES completion:nil];
                              [self secondAlert];
                          }];
    [alert2 addAction:ok2];
    [self presentViewController:alert2 animated:YES completion:nil];
}
-(void)secondAlert{
    self.backGround.layer.zPosition=0;
    [self swapZPositions];
}
- (IBAction)lockInClicked:(id)sender {
    if(self.turn==1){
        if(self.fiveOnBoard&&self.fourOnBoard&&self.threeOneOnBoard&&self.threeTwoOnBoard&&self.twoOnBoard){
            [self changeTurn];
        }
    }else{
        if(self.fiveOnBoard2&&self.fourOnBoard2&&self.threeOneOnBoard2&&self.threeTwoOnBoard2&&self.twoOnBoard2){
            self.shipsLockedIn=true;
            [self.pickScroll setHidden:true];
            [self.LockInScroll setHidden:true];
            [self.lockButton setHidden:true];
            [self changeTurn];
        }
    }
}
-(void)setupComputerGrid
{
    //self.rightGrid = [self.leftGrid copy];
    //for(int i =0; i<100; i++){
    
    //    [self.rightGrid replaceObjectAtIndex:i withObject:[self.leftGrid objectAtIndex:i]];
    //}
    for(int i = 2; i<=5;i++){
        bool notPlaced=true;
        while(notPlaced){
            int randStart = arc4random_uniform(100);
            NSLog(@"%i,%i",i,randStart);
            int direction = arc4random_uniform(2);
            if(direction==0){
                if((randStart%10)+i-1<10){
                    bool blocked = false;
                    for(int j = randStart; j<randStart+i; j++){
                        NSLog(@"%i,%i,%i",randStart,i,-1);
                        if(!([[self.rightGrid objectAtIndex:j] intValue] == 0)){
                            blocked=true;
                        }
                    }
                    if(!blocked){
                        for(int k = randStart; k<randStart+i; k++){
                            if(i==3){
                                [self.rightGrid replaceObjectAtIndex:k withObject:[NSNumber numberWithInt:31]];
                            }else{
                                [self.rightGrid replaceObjectAtIndex:k withObject:[NSNumber numberWithInt:i]];
                            }
                        }
                        notPlaced=false;
                    }
                }
            }else{
                if(randStart+((i-1)*10)<100){
                    bool blocked = false;
                    for(int j = randStart; j<randStart+((i)*10); j+=10){
                        if(!([[self.rightGrid objectAtIndex:j] intValue] == 0)){
                            blocked=true;
                        }
                    }
                    if(!blocked){
                        for(int k = randStart; k<randStart+((i)*10); k+=10){
                            if(i==3){
                                [self.rightGrid replaceObjectAtIndex:k withObject:[NSNumber numberWithInt:31]];
                            }else{
                                [self.rightGrid replaceObjectAtIndex:k withObject:[NSNumber numberWithInt:i]];
                            }
                        }
                        notPlaced=false;
                    }
                }
            }
        }
        
    }
    int i=3;
    bool notPlaced=true;
    while(notPlaced){
        int randStart = arc4random_uniform(100);
        NSLog(@"%i,%i",i,randStart);
        int direction = arc4random_uniform(2);
        if(direction==0){
            if((randStart%10)+i-1<10){
                bool blocked = false;
                for(int j = randStart; j<randStart+i; j++){
                    NSLog(@"%i,%i,%i",randStart,i,-1);
                    if(!([[self.rightGrid objectAtIndex:j] intValue] == 0)){
                        blocked=true;
                    }
                }
                if(!blocked){
                    for(int k = randStart; k<randStart+i; k++){
                        [self.rightGrid replaceObjectAtIndex:k withObject:[NSNumber numberWithInt:32]];
                    }
                    notPlaced=false;
                }
            }
        }else{
            if(randStart+((i-1)*10)<100){
                bool blocked = false;
                for(int j = randStart; j<randStart+((i)*10); j+=10){
                    if(!([[self.rightGrid objectAtIndex:j] intValue] == 0)){
                        blocked=true;
                    }
                }
                if(!blocked){
                    for(int k = randStart; k<randStart+((i)*10); k+=10){
                        [self.rightGrid replaceObjectAtIndex:k withObject:[NSNumber numberWithInt:32]];
                        
                    }
                    notPlaced=false;
                }
            }
        }
    }
    
}
- (IBAction)gridClicked:(UIButton*)sender
{
    if(self.turn==1){
        if(self.shipsLockedIn){
        int gridX = [self computeRightXCoord:(int)sender.tag];
        int gridY = [self computeRightYCoord:(int)sender.tag];
        int targetHit = [[self.rightGrid objectAtIndex:sender.tag] intValue];
        if(targetHit==0){
            UIImageView *miss =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
            miss.image=[UIImage imageNamed:@"miss.png"];
            miss.layer.zPosition=2;
            [self.view addSubview:miss];
            [self.p1HitsMisses addObject:miss];
            [self.rightGrid replaceObjectAtIndex:sender.tag withObject:[NSNumber numberWithInteger:1]];
            [self changeTurn];
        }else if(targetHit==5){
            UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
            hit.image=[UIImage imageNamed:@"hit.png"];
            hit.layer.zPosition=2;
            [self.view addSubview:hit];
            [self.p1HitsMisses addObject:hit];
            [self.rightGrid replaceObjectAtIndex:sender.tag withObject:[NSNumber numberWithInteger:59]];
            if(![self.rightGrid containsObject:[NSNumber numberWithInt:5]]){ //fiveShip is now dead
                NSLog(@"Computer Five Ship Down!");
                [self playDaikajiuSound];
                int startIndex=-1;
                int directionIndex=-1;
                for(int i = 0; directionIndex==-1; i++){
                    if([[self.rightGrid objectAtIndex:i] intValue]==59){
                        if(startIndex==-1){
                            startIndex=i;
                        }else{
                            directionIndex=i;
                        }
                    }
                }
                CGPoint shipOrigin = CGPointMake([self computeRightXCoord:startIndex], [self computeRightYCoord:startIndex]);
                if(directionIndex-startIndex<10){ //ship was horizontal
                    UIImageView *fiveSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x,shipOrigin.y,200,40)];
                    fiveSunk.image=[UIImage imageNamed:@"five.gif"];
                    fiveSunk.alpha = 0.0f;
                    [self.view addSubview:fiveSunk];
                    [self.p2SunkShips addObject:fiveSunk];
                    [UIView animateWithDuration:0.5f
                                          delay:0.0f
                                        options:UIViewAnimationOptionAutoreverse
                                     animations:^ {
                                         [UIView setAnimationRepeatCount:8.0f/2.0f];
                                         fiveSunk.alpha = 1.0f;
                                     } completion:^(BOOL finished) {}];
                }else{
                    UIImageView *fiveSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x-80,shipOrigin.y+80,200,40)];
                    fiveSunk.image=[UIImage imageNamed:@"five.gif"];
                    fiveSunk.transform = CGAffineTransformMakeRotation(M_PI_2);
                    fiveSunk.alpha = 0.0f;
                    [self.view addSubview:fiveSunk];
                    [self.p2SunkShips addObject:fiveSunk];
                    [UIView animateWithDuration:0.5f
                                          delay:0.0f
                                        options:UIViewAnimationOptionAutoreverse
                                     animations:^ {
                                         [UIView setAnimationRepeatCount:8.0f/2.0f];
                                         fiveSunk.alpha = 1.0f;
                                     } completion:^(BOOL finished) {}];
                }
                self.playerShipsRemaining--;
                if(self.playerShipsRemaining==0){
                    [self playerWins];
                }
            }
            [self changeTurn];
        }else if(targetHit==4){
            UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
            hit.image=[UIImage imageNamed:@"hit.png"];
            hit.layer.zPosition=2;
            [self.view addSubview:hit];
            [self.p1HitsMisses addObject:hit];
            [self.rightGrid replaceObjectAtIndex:sender.tag withObject:[NSNumber numberWithInteger:49]];
            if(![self.rightGrid containsObject:[NSNumber numberWithInt:4]]){ //fourShip is now dead
                NSLog(@"Computer Four Ship Down!");
                [self playDaikajiuSound];
                int startIndex=-1;
                int directionIndex=-1;
                for(int i = 0; directionIndex==-1; i++){
                    if([[self.rightGrid objectAtIndex:i] intValue]==49){
                        if(startIndex==-1){
                            startIndex=i;
                        }else{
                            directionIndex=i;
                        }
                    }
                }
                CGPoint shipOrigin = CGPointMake([self computeRightXCoord:startIndex], [self computeRightYCoord:startIndex]);
                if(directionIndex-startIndex<10){ //ship was horizontal
                    UIImageView *fourSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x,shipOrigin.y,160,40)];
                    fourSunk.image=[UIImage imageNamed:@"four.gif"];
                    
                    NSLog(@"Adding subview fourSunk");
                    fourSunk.alpha = 0.0f;
                    [self.view addSubview:fourSunk];
                    [self.p2SunkShips addObject:fourSunk];
                    [UIView animateWithDuration:0.5f
                                          delay:0.0f
                                        options:UIViewAnimationOptionAutoreverse
                                     animations:^ {
                                         [UIView setAnimationRepeatCount:8.0f/2.0f];
                                         fourSunk.alpha = 1.0f;
                                     } completion:^(BOOL finished) {}];
                }else{
                    UIImageView *fourSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x-60,shipOrigin.y+60,160,40)];
                    fourSunk.image=[UIImage imageNamed:@"four.gif"];
                    fourSunk.transform = CGAffineTransformMakeRotation(M_PI_2);
                    fourSunk.alpha = 0.0f;
                    [self.view addSubview:fourSunk];
                    [self.p2SunkShips addObject:fourSunk];
                    [UIView animateWithDuration:0.5f
                                          delay:0.0f
                                        options:UIViewAnimationOptionAutoreverse
                                     animations:^ {
                                         [UIView setAnimationRepeatCount:8.0f/2.0f];
                                         fourSunk.alpha = 1.0f;
                                     } completion:^(BOOL finished) {}];
                }
                self.playerShipsRemaining--;
                if(self.playerShipsRemaining==0){
                    [self playerWins];
                }
                
            }
            [self changeTurn];
        }else if(targetHit==31){
            UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
            hit.image=[UIImage imageNamed:@"hit.png"];
            hit.layer.zPosition=2;
            [self.view addSubview:hit];
            [self.p1HitsMisses addObject:hit];
            [self.rightGrid replaceObjectAtIndex:sender.tag withObject:[NSNumber numberWithInteger:319]];
            if(![self.rightGrid containsObject:[NSNumber numberWithInt:31]]){ //threeShipOne is now dead
                NSLog(@"Computer Three Ship One Down!");
                [self playDaikajiuSound];
                int startIndex=-1;
                int directionIndex=-1;
                for(int i = 0; directionIndex==-1; i++){
                    if([[self.rightGrid objectAtIndex:i] intValue]==319){
                        if(startIndex==-1){
                            startIndex=i;
                        }else{
                            directionIndex=i;
                        }
                    }
                }
                CGPoint shipOrigin = CGPointMake([self computeRightXCoord:startIndex], [self computeRightYCoord:startIndex]);
                if(directionIndex-startIndex<10){ //ship was horizontal
                    UIImageView *threeOneSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x,shipOrigin.y,120,40)];
                    threeOneSunk.image=[UIImage imageNamed:@"threeOne.gif"];
                    threeOneSunk.alpha = 0.0f;
                    [self.view addSubview:threeOneSunk];
                    [self.p2SunkShips addObject:threeOneSunk];
                    [UIView animateWithDuration:0.5f
                                          delay:0.0f
                                        options:UIViewAnimationOptionAutoreverse
                                     animations:^ {
                                         [UIView setAnimationRepeatCount:8.0f/2.0f];
                                         threeOneSunk.alpha = 1.0f;
                                     } completion:^(BOOL finished) {}];
                }else{
                    UIImageView *threeOneSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x-40,shipOrigin.y+40,120,40)];
                    threeOneSunk.image=[UIImage imageNamed:@"threeOne.gif"];
                    threeOneSunk.transform = CGAffineTransformMakeRotation(M_PI_2);
                    threeOneSunk.alpha = 0.0f;
                    [self.view addSubview:threeOneSunk];
                    [self.p2SunkShips addObject:threeOneSunk];
                    [UIView animateWithDuration:0.5f
                                          delay:0.0f
                                        options:UIViewAnimationOptionAutoreverse
                                     animations:^ {
                                         [UIView setAnimationRepeatCount:8.0f/2.0f];
                                         threeOneSunk.alpha = 1.0f;
                                     } completion:^(BOOL finished) {}];
                }
                self.playerShipsRemaining--;
                if(self.playerShipsRemaining==0){
                    [self playerWins];
                }
                
            }
            [self changeTurn];
        }else if(targetHit==32){
            UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
            hit.image=[UIImage imageNamed:@"hit.png"];
            hit.layer.zPosition=2;
            [self.view addSubview:hit];
            [self.p1HitsMisses addObject:hit];
            [self.rightGrid replaceObjectAtIndex:sender.tag withObject:[NSNumber numberWithInteger:329]];
            if(![self.rightGrid containsObject:[NSNumber numberWithInt:32]]){ //threeShipTwo is now dead
                NSLog(@"Computer Three Ship Two Down!");
                [self playDaikajiuSound];
                int startIndex=-1;
                int directionIndex=-1;
                for(int i = 0; directionIndex==-1; i++){
                    if([[self.rightGrid objectAtIndex:i] intValue]==329){
                        if(startIndex==-1){
                            startIndex=i;
                        }else{
                            directionIndex=i;
                        }
                    }
                }
                CGPoint shipOrigin = CGPointMake([self computeRightXCoord:startIndex], [self computeRightYCoord:startIndex]);
                if(directionIndex-startIndex<10){ //ship was horizontal
                    UIImageView *threeTwoSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x,shipOrigin.y,120,40)];
                    threeTwoSunk.image=[UIImage imageNamed:@"threeTwo.gif"];
                    threeTwoSunk.alpha = 0.0f;
                    [self.view addSubview:threeTwoSunk];
                    [self.p2SunkShips addObject:threeTwoSunk];
                    [UIView animateWithDuration:0.5f
                                          delay:0.0f
                                        options:UIViewAnimationOptionAutoreverse
                                     animations:^ {
                                         [UIView setAnimationRepeatCount:8.0f/2.0f];
                                         threeTwoSunk.alpha = 1.0f;
                                     } completion:^(BOOL finished) {}];
                }else{
                    UIImageView *threeTwoSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x-40,shipOrigin.y+40,120,40)];
                    threeTwoSunk.image=[UIImage imageNamed:@"threeTwo.gif"];
                    threeTwoSunk.transform = CGAffineTransformMakeRotation(M_PI_2);
                    threeTwoSunk.alpha = 0.0f;
                    [self.view addSubview:threeTwoSunk];
                    [self.p2SunkShips addObject:threeTwoSunk];
                    [UIView animateWithDuration:0.5f
                                          delay:0.0f
                                        options:UIViewAnimationOptionAutoreverse
                                     animations:^ {
                                         [UIView setAnimationRepeatCount:8.0f/2.0f];
                                         threeTwoSunk.alpha = 1.0f;
                                     } completion:^(BOOL finished) {}];
                }
                self.playerShipsRemaining--;
                if(self.playerShipsRemaining==0){
                    [self playerWins];
                }
                
            }
            [self changeTurn];
        }else if(targetHit==2){
            UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
            hit.image=[UIImage imageNamed:@"hit.png"];
            hit.layer.zPosition=2;
            [self.view addSubview:hit];
            [self.p1HitsMisses addObject:hit];
            [self.rightGrid replaceObjectAtIndex:sender.tag withObject:[NSNumber numberWithInteger:29]];
            if(![self.rightGrid containsObject:[NSNumber numberWithInt:2]]){ //twoShip is now dead
                NSLog(@"Computer Two Ship Down!");
                [self playDaikajiuSound];
                int startIndex=-1;
                int directionIndex=-1;
                for(int i = 0; directionIndex==-1; i++){
                    if([[self.rightGrid objectAtIndex:i] intValue]==29){
                        if(startIndex==-1){
                            startIndex=i;
                        }else{
                            directionIndex=i;
                        }
                    }
                }
                CGPoint shipOrigin = CGPointMake([self computeRightXCoord:startIndex], [self computeRightYCoord:startIndex]);
                if(directionIndex-startIndex<10){ //ship was horizontal
                    UIImageView *twoSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x,shipOrigin.y,80,40)];
                    twoSunk.image=[UIImage imageNamed:@"two.gif"];
                    twoSunk.alpha = 0.0f;
                    [self.view addSubview:twoSunk];
                    [self.p2SunkShips addObject:twoSunk];
                    [UIView animateWithDuration:0.5f
                                          delay:0.0f
                                        options:UIViewAnimationOptionAutoreverse
                                     animations:^ {
                                         [UIView setAnimationRepeatCount:8.0f/2.0f];
                                         twoSunk.alpha = 1.0f;
                                     } completion:^(BOOL finished) {}];
                }else{
                    UIImageView *twoSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x-20,shipOrigin.y+20,80,40)];
                    twoSunk.image=[UIImage imageNamed:@"two.gif"];
                    twoSunk.transform = CGAffineTransformMakeRotation(M_PI_2);
                    twoSunk.alpha = 0.0f;
                    [self.view addSubview:twoSunk];
                    [self.p2SunkShips addObject:twoSunk];
                    NSLog(@"Adding subview twoSunk");
                    [UIView animateWithDuration:0.5f
                                          delay:0.0f
                                        options:UIViewAnimationOptionAutoreverse
                                     animations:^ {
                                         [UIView setAnimationRepeatCount:8.0f/2.0f];
                                         twoSunk.alpha = 1.0f;
                                     } completion:^(BOOL finished) {}];
                }
                self.playerShipsRemaining--;
                if(self.playerShipsRemaining==0){
                    [self playerWins];
                }
                
            }
            [self changeTurn];
        }
    }
    }else{
        
        if(self.shipsLockedIn){
            int gridX = [self computeRightXCoord:(int)sender.tag];
            int gridY = [self computeRightYCoord:(int)sender.tag];
            int targetHit = [[self.leftGrid objectAtIndex:sender.tag] intValue];
            if(targetHit==0){
                UIImageView *miss =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
                miss.image=[UIImage imageNamed:@"miss.png"];
                miss.layer.zPosition=2;
                [self.view addSubview:miss];
                [self.p2HitsMisses addObject:miss];
                [self.leftGrid replaceObjectAtIndex:sender.tag withObject:[NSNumber numberWithInteger:1]];
                [self changeTurn];
            }else if(targetHit==5){
                UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
                hit.image=[UIImage imageNamed:@"hit.png"];
                hit.layer.zPosition=2;
                [self.view addSubview:hit];
                [self.p2HitsMisses addObject:hit];
                [self.leftGrid replaceObjectAtIndex:sender.tag withObject:[NSNumber numberWithInteger:59]];
                if(![self.leftGrid containsObject:[NSNumber numberWithInt:5]]){ //fiveShip is now dead
                    NSLog(@"Computer Five Ship Down!");
                    [self playDaikajiuSound];
                    int startIndex=-1;
                    int directionIndex=-1;
                    for(int i = 0; directionIndex==-1; i++){
                        if([[self.leftGrid objectAtIndex:i] intValue]==59){
                            if(startIndex==-1){
                                startIndex=i;
                            }else{
                                directionIndex=i;
                            }
                        }
                    }
                    CGPoint shipOrigin = CGPointMake([self computeRightXCoord:startIndex], [self computeRightYCoord:startIndex]);
                    if(directionIndex-startIndex<10){ //ship was horizontal
                        UIImageView *fiveSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x,shipOrigin.y,200,40)];
                        fiveSunk.image=[UIImage imageNamed:@"five.gif"];
                        fiveSunk.alpha = 0.0f;
                        [self.view addSubview:fiveSunk];
                        [self.p1SunkShips addObject:fiveSunk];
                        [UIView animateWithDuration:0.5f
                                              delay:0.0f
                                            options:UIViewAnimationOptionAutoreverse
                                         animations:^ {
                                             [UIView setAnimationRepeatCount:8.0f/2.0f];
                                             fiveSunk.alpha = 1.0f;
                                         } completion:^(BOOL finished) {}];
                    }else{
                        UIImageView *fiveSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x-80,shipOrigin.y+80,200,40)];
                        fiveSunk.image=[UIImage imageNamed:@"five.gif"];
                        fiveSunk.transform = CGAffineTransformMakeRotation(M_PI_2);
                        fiveSunk.alpha = 0.0f;
                        [self.view addSubview:fiveSunk];
                        [self.p1SunkShips addObject:fiveSunk];
                        [UIView animateWithDuration:0.5f
                                              delay:0.0f
                                            options:UIViewAnimationOptionAutoreverse
                                         animations:^ {
                                             [UIView setAnimationRepeatCount:8.0f/2.0f];
                                             fiveSunk.alpha = 1.0f;
                                         } completion:^(BOOL finished) {}];
                    }
                    self.playerShipsRemaining2--;
                    if(self.playerShipsRemaining2==0){
                        [self playerWins];
                    }
                }
                [self changeTurn];
            }else if(targetHit==4){
                UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
                hit.image=[UIImage imageNamed:@"hit.png"];
                hit.layer.zPosition=2;
                [self.view addSubview:hit];
                [self.p2HitsMisses addObject:hit];
                [self.leftGrid replaceObjectAtIndex:sender.tag withObject:[NSNumber numberWithInteger:49]];
                if(![self.leftGrid containsObject:[NSNumber numberWithInt:4]]){ //fourShip is now dead
                    NSLog(@"Computer Four Ship Down!");
                    [self playDaikajiuSound];
                    int startIndex=-1;
                    int directionIndex=-1;
                    for(int i = 0; directionIndex==-1; i++){
                        if([[self.leftGrid objectAtIndex:i] intValue]==49){
                            if(startIndex==-1){
                                startIndex=i;
                            }else{
                                directionIndex=i;
                            }
                        }
                    }
                    CGPoint shipOrigin = CGPointMake([self computeRightXCoord:startIndex], [self computeRightYCoord:startIndex]);
                    if(directionIndex-startIndex<10){ //ship was horizontal
                        UIImageView *fourSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x,shipOrigin.y,160,40)];
                        fourSunk.image=[UIImage imageNamed:@"four.gif"];
                        
                        NSLog(@"Adding subview fourSunk");
                        fourSunk.alpha = 0.0f;
                        [self.view addSubview:fourSunk];
                        [self.p1SunkShips addObject:fourSunk];
                        [UIView animateWithDuration:0.5f
                                              delay:0.0f
                                            options:UIViewAnimationOptionAutoreverse
                                         animations:^ {
                                             [UIView setAnimationRepeatCount:8.0f/2.0f];
                                             fourSunk.alpha = 1.0f;
                                         } completion:^(BOOL finished) {}];
                    }else{
                        UIImageView *fourSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x-60,shipOrigin.y+60,160,40)];
                        fourSunk.image=[UIImage imageNamed:@"four.gif"];
                        fourSunk.transform = CGAffineTransformMakeRotation(M_PI_2);
                        fourSunk.alpha = 0.0f;
                        [self.view addSubview:fourSunk];
                        [self.p1SunkShips addObject:fourSunk];
                        [UIView animateWithDuration:0.5f
                                              delay:0.0f
                                            options:UIViewAnimationOptionAutoreverse
                                         animations:^ {
                                             [UIView setAnimationRepeatCount:8.0f/2.0f];
                                             fourSunk.alpha = 1.0f;
                                         } completion:^(BOOL finished) {}];
                    }
                    self.playerShipsRemaining2--;
                    if(self.playerShipsRemaining2==0){
                        [self playerWins];
                    }
                    
                }
                [self changeTurn];
            }else if(targetHit==31){
                UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
                hit.image=[UIImage imageNamed:@"hit.png"];
                hit.layer.zPosition=2;
                [self.view addSubview:hit];
                [self.p2HitsMisses addObject:hit];
                [self.leftGrid replaceObjectAtIndex:sender.tag withObject:[NSNumber numberWithInteger:319]];
                if(![self.leftGrid containsObject:[NSNumber numberWithInt:31]]){ //threeShipOne is now dead
                    NSLog(@"Computer Three Ship One Down!");
                    [self playDaikajiuSound];
                    int startIndex=-1;
                    int directionIndex=-1;
                    for(int i = 0; directionIndex==-1; i++){
                        if([[self.leftGrid objectAtIndex:i] intValue]==319){
                            if(startIndex==-1){
                                startIndex=i;
                            }else{
                                directionIndex=i;
                            }
                        }
                    }
                    CGPoint shipOrigin = CGPointMake([self computeRightXCoord:startIndex], [self computeRightYCoord:startIndex]);
                    if(directionIndex-startIndex<10){ //ship was horizontal
                        UIImageView *threeOneSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x,shipOrigin.y,120,40)];
                        threeOneSunk.image=[UIImage imageNamed:@"threeOne.gif"];
                        threeOneSunk.alpha = 0.0f;
                        [self.view addSubview:threeOneSunk];
                        [self.p1SunkShips addObject:threeOneSunk];
                        [UIView animateWithDuration:0.5f
                                              delay:0.0f
                                            options:UIViewAnimationOptionAutoreverse
                                         animations:^ {
                                             [UIView setAnimationRepeatCount:8.0f/2.0f];
                                             threeOneSunk.alpha = 1.0f;
                                         } completion:^(BOOL finished) {}];
                    }else{
                        UIImageView *threeOneSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x-40,shipOrigin.y+40,120,40)];
                        threeOneSunk.image=[UIImage imageNamed:@"threeOne.gif"];
                        threeOneSunk.transform = CGAffineTransformMakeRotation(M_PI_2);
                        threeOneSunk.alpha = 0.0f;
                        [self.view addSubview:threeOneSunk];
                        [self.p1SunkShips addObject:threeOneSunk];
                        [UIView animateWithDuration:0.5f
                                              delay:0.0f
                                            options:UIViewAnimationOptionAutoreverse
                                         animations:^ {
                                             [UIView setAnimationRepeatCount:8.0f/2.0f];
                                             threeOneSunk.alpha = 1.0f;
                                         } completion:^(BOOL finished) {}];
                    }
                    self.playerShipsRemaining2--;
                    if(self.playerShipsRemaining2==0){
                        [self playerWins];
                    }
                    
                }
                [self changeTurn];
            }else if(targetHit==32){
                UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
                hit.image=[UIImage imageNamed:@"hit.png"];
                hit.layer.zPosition=2;
                [self.view addSubview:hit];
                [self.p2HitsMisses addObject:hit];
                [self.leftGrid replaceObjectAtIndex:sender.tag withObject:[NSNumber numberWithInteger:329]];
                if(![self.leftGrid containsObject:[NSNumber numberWithInt:32]]){ //threeShipTwo is now dead
                    NSLog(@"Computer Three Ship Two Down!");
                    [self playDaikajiuSound];
                    int startIndex=-1;
                    int directionIndex=-1;
                    for(int i = 0; directionIndex==-1; i++){
                        if([[self.leftGrid objectAtIndex:i] intValue]==329){
                            if(startIndex==-1){
                                startIndex=i;
                            }else{
                                directionIndex=i;
                            }
                        }
                    }
                    CGPoint shipOrigin = CGPointMake([self computeRightXCoord:startIndex], [self computeRightYCoord:startIndex]);
                    if(directionIndex-startIndex<10){ //ship was horizontal
                        UIImageView *threeTwoSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x,shipOrigin.y,120,40)];
                        threeTwoSunk.image=[UIImage imageNamed:@"threeTwo.gif"];
                        threeTwoSunk.alpha = 0.0f;
                        [self.view addSubview:threeTwoSunk];
                        [self.p1SunkShips addObject:threeTwoSunk];
                        [UIView animateWithDuration:0.5f
                                              delay:0.0f
                                            options:UIViewAnimationOptionAutoreverse
                                         animations:^ {
                                             [UIView setAnimationRepeatCount:8.0f/2.0f];
                                             threeTwoSunk.alpha = 1.0f;
                                         } completion:^(BOOL finished) {}];
                    }else{
                        UIImageView *threeTwoSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x-40,shipOrigin.y+40,120,40)];
                        threeTwoSunk.image=[UIImage imageNamed:@"threeTwo.gif"];
                        threeTwoSunk.transform = CGAffineTransformMakeRotation(M_PI_2);
                        threeTwoSunk.alpha = 0.0f;
                        [self.view addSubview:threeTwoSunk];
                        [self.p1SunkShips addObject:threeTwoSunk];
                        [UIView animateWithDuration:0.5f
                                              delay:0.0f
                                            options:UIViewAnimationOptionAutoreverse
                                         animations:^ {
                                             [UIView setAnimationRepeatCount:8.0f/2.0f];
                                             threeTwoSunk.alpha = 1.0f;
                                         } completion:^(BOOL finished) {}];
                    }
                    self.playerShipsRemaining2--;
                    if(self.playerShipsRemaining2==0){
                        [self playerWins];
                    }
                    
                }
                [self changeTurn];
            }else if(targetHit==2){
                UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
                hit.image=[UIImage imageNamed:@"hit.png"];
                hit.layer.zPosition=2;
                [self.view addSubview:hit];
                [self.p2HitsMisses addObject:hit];
                [self.leftGrid replaceObjectAtIndex:sender.tag withObject:[NSNumber numberWithInteger:29]];
                if(![self.leftGrid containsObject:[NSNumber numberWithInt:2]]){ //twoShip is now dead
                    NSLog(@"Computer Two Ship Down!");
                    [self playDaikajiuSound];
                    int startIndex=-1;
                    int directionIndex=-1;
                    for(int i = 0; directionIndex==-1; i++){
                        if([[self.leftGrid objectAtIndex:i] intValue]==29){
                            if(startIndex==-1){
                                startIndex=i;
                            }else{
                                directionIndex=i;
                            }
                        }
                    }
                    CGPoint shipOrigin = CGPointMake([self computeRightXCoord:startIndex], [self computeRightYCoord:startIndex]);
                    if(directionIndex-startIndex<10){ //ship was horizontal
                        UIImageView *twoSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x,shipOrigin.y,80,40)];
                        twoSunk.image=[UIImage imageNamed:@"two.gif"];
                        twoSunk.alpha = 0.0f;
                        [self.view addSubview:twoSunk];
                        [self.p1SunkShips addObject:twoSunk];
                        [UIView animateWithDuration:0.5f
                                              delay:0.0f
                                            options:UIViewAnimationOptionAutoreverse
                                         animations:^ {
                                             [UIView setAnimationRepeatCount:8.0f/2.0f];
                                             twoSunk.alpha = 1.0f;
                                         } completion:^(BOOL finished) {}];
                    }else{
                        UIImageView *twoSunk =[[UIImageView alloc] initWithFrame:CGRectMake(shipOrigin.x-20,shipOrigin.y+20,80,40)];
                        twoSunk.image=[UIImage imageNamed:@"two.gif"];
                        twoSunk.transform = CGAffineTransformMakeRotation(M_PI_2);
                        twoSunk.alpha = 0.0f;
                        [self.view addSubview:twoSunk];
                        [self.p1SunkShips addObject:twoSunk];
                        NSLog(@"Adding subview twoSunk");
                        [UIView animateWithDuration:0.5f
                                              delay:0.0f
                                            options:UIViewAnimationOptionAutoreverse
                                         animations:^ {
                                             [UIView setAnimationRepeatCount:8.0f/2.0f];
                                             twoSunk.alpha = 1.0f;
                                         } completion:^(BOOL finished) {}];
                    }
                    self.playerShipsRemaining2--;
                    if(self.playerShipsRemaining2==0){
                        [self playerWins];
                    }
                    
                }
                [self changeTurn];
            }
        }
        
    }
    
}
-(void)playerWins
{
    self.gameOver=true;
    if(self.playerShipsRemaining==0){
        NSLog(@"Player Wins!");
        NSLog(@"Trying to play victory sound");
        NSString *victoryPath = [[NSBundle mainBundle] pathForResource:@"victoryjingle" ofType:@"wav"];
        NSURL *victoryURL = [NSURL fileURLWithPath:victoryPath];
        NSError *error;
        self.monsterNoisePlayer = [[AVAudioPlayer alloc]
                                   initWithContentsOfURL:victoryURL error:&error];
        [self.monsterNoisePlayer prepareToPlay];
        [self.monsterNoisePlayer play];
        NSString *player1Alert=@"Player ";
        player1Alert=[player1Alert stringByAppendingString:self.p1name];
        player1Alert=[player1Alert stringByAppendingString:@" Wins!"];
        NSString *player1Text=@"You have sunk all of Player ";
        player1Text=[player1Text stringByAppendingString:self.p2name];
        player1Text=[player1Text stringByAppendingString:@"'s ships."];
        UIAlertController * alert=   [UIAlertController
                                      alertControllerWithTitle:player1Alert
                                      message:player1Text
                                      preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction
                             actionWithTitle:@"OK"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [alert dismissViewControllerAnimated:YES completion:nil];
                                 [self presentViewController:[self.storyboard instantiateInitialViewController] animated:YES completion:nil];
                                 
                             }];
        [alert addAction:ok];
        
        [self presentViewController:alert animated:YES completion:nil];
    }else if(self.playerShipsRemaining2==0){
        NSLog(@"Player Wins!");
        NSLog(@"Trying to play victory sound");
        NSString *victoryPath = [[NSBundle mainBundle] pathForResource:@"victoryjingle" ofType:@"wav"];
        NSURL *victoryURL = [NSURL fileURLWithPath:victoryPath];
        NSError *error;
        self.monsterNoisePlayer = [[AVAudioPlayer alloc]
                                   initWithContentsOfURL:victoryURL error:&error];
        [self.monsterNoisePlayer prepareToPlay];
        [self.monsterNoisePlayer play];
        NSString *player2Alert=@"Player ";
        player2Alert=[player2Alert stringByAppendingString:self.p2name];
        player2Alert=[player2Alert stringByAppendingString:@" Wins!"];
        NSString *player2Text=@"You have sunk all of Player ";
        player2Text=[player2Text stringByAppendingString:self.p1name];
        player2Text=[player2Text stringByAppendingString:@"'s ships."];
        UIAlertController * alert=   [UIAlertController
                                      alertControllerWithTitle:player2Alert
                                      message:player2Text
                                      preferredStyle:UIAlertControllerStyleAlert];
        
        UIAlertAction* ok = [UIAlertAction
                             actionWithTitle:@"OK"
                             style:UIAlertActionStyleDefault
                             handler:^(UIAlertAction * action)
                             {
                                 [alert dismissViewControllerAnimated:YES completion:nil];
                                 [self presentViewController:[self.storyboard instantiateInitialViewController] animated:YES completion:nil];
                                 
                             }];
        [alert addAction:ok];
        
        [self presentViewController:alert animated:YES completion:nil];
    }
    
}
-(void)computerTurn
{
    if(self.gameOver){
        return;
    }
    int volleyIndex = arc4random_uniform(100);
    if(self.sinkingShip){
        NSLog(@"entering shipSink loop with random value %i and orientation %i", volleyIndex, self.sinkingShipOrientation);
        bool volleySpotNotFound=true;
        if(self.sinkingShipOrientation==-1){ //orientation unknown
            volleySpotNotFound=true;
            NSLog(@"Orientation Unknown");
            if(self.sinkingShipIndex%10!=0&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex-1] intValue]%10!=9&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex-1] intValue]!=1){
                NSLog(@"Trying the left position");
                
                volleyIndex=self.sinkingShipIndex-1;
                if([[self.leftGrid objectAtIndex:self.sinkingShipIndex-1] intValue]!=0){
                    self.sinkingShipOrientation=1;
                }
                
            }else if(self.sinkingShipIndex%10!=9&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex+1] intValue]%10!=9&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex+1] intValue]!=1){
                NSLog(@"Trying the right position");
                volleyIndex=self.sinkingShipIndex+1;
                if([[self.leftGrid objectAtIndex:self.sinkingShipIndex+1] intValue]!=0){
                    self.sinkingShipOrientation=0;
                }
            }else if(self.sinkingShipIndex-10>=0&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex-10] intValue]%10!=9&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex-10] intValue]!=1){
                NSLog(@"Trying the up position");
                volleyIndex=self.sinkingShipIndex-10;
                if([[self.leftGrid objectAtIndex:self.sinkingShipIndex-10] intValue]!=0){
                    self.sinkingShipOrientation=3;
                }
            }else if(self.sinkingShipIndex+10<100&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex+10] intValue]%10!=9&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex+10] intValue]!=1){
                NSLog(@"Trying the down position");
                volleyIndex=self.sinkingShipIndex+10;
                if([[self.leftGrid objectAtIndex:self.sinkingShipIndex+10] intValue]!=0){
                    self.sinkingShipOrientation=2;
                }
            }
        }
        else if(self.sinkingShipOrientation==0){ //orientation horizontal, going right
            for(int i=self.sinkingShipIndex; volleySpotNotFound; i++){
                NSLog(@"Going right and checking spot %i",i);
                if([[self.leftGrid objectAtIndex:i] intValue]%10!=9){
                    volleyIndex=i;
                    volleySpotNotFound=false;
                    if([[self.leftGrid objectAtIndex:i] intValue]==0||i%10==9||[[self.leftGrid objectAtIndex:i] intValue]==1){
                        self.sinkingShipOrientation=1;
                        if(!self.reachedOtherEndOfShip){
                            self.reachedOtherEndOfShip=true;
                        }else{
                            self.sinkingShip=false;
                            self.reachedOtherEndOfShip=false;
                            self.sinkingShipOrientation=-1;
                        }
                    }
                }
            }
        }
        else if(self.sinkingShipOrientation==1){ //orientation horizontal, going left
            for(int i=self.sinkingShipIndex; volleySpotNotFound; i--){
                NSLog(@"Going left and checking spot %i",i);
                if([[self.leftGrid objectAtIndex:i] intValue]%10!=9){
                    volleyIndex=i;
                    volleySpotNotFound=false;
                    NSLog(@"Volleying at spot %i which contains value %i",i, [[self.leftGrid objectAtIndex:i] intValue]);
                    if([[self.leftGrid objectAtIndex:i] intValue]==0||i%10==0||[[self.leftGrid objectAtIndex:i] intValue]==1){
                        self.sinkingShipOrientation=0;
                        if(!self.reachedOtherEndOfShip){
                            self.reachedOtherEndOfShip=true;
                        }else{
                            self.sinkingShip=false;
                            self.reachedOtherEndOfShip=false;
                            self.sinkingShipOrientation=-1;
                        }
                    }
                }
            }
        }
        else if(self.sinkingShipOrientation==2){ //orientation vertical, going down
            for(int i=self.sinkingShipIndex; volleySpotNotFound; i+=10){
                NSLog(@"Going down and checking spot %i",i);
                if([[self.leftGrid objectAtIndex:i] intValue]%10!=9){
                    volleyIndex=i;
                    volleySpotNotFound=false;
                    if([[self.leftGrid objectAtIndex:i] intValue]==0||i>=90||[[self.leftGrid objectAtIndex:i] intValue]==1){
                        self.sinkingShipOrientation=3;
                        if(!self.reachedOtherEndOfShip){
                            self.reachedOtherEndOfShip=true;
                        }else{
                            self.sinkingShip=false;
                            self.reachedOtherEndOfShip=false;
                            self.sinkingShipOrientation=-1;
                        }
                    }
                }
            }
        }
        else{ //orientation vertical, going up
            for(int i=self.sinkingShipIndex; volleySpotNotFound; i-=10){
                NSLog(@"Going up and checking spot %i",i);
                if([[self.leftGrid objectAtIndex:i] intValue]%10!=9){
                    volleyIndex=i;
                    volleySpotNotFound=false;
                    if([[self.leftGrid objectAtIndex:i] intValue]==0||i<10||[[self.leftGrid objectAtIndex:i] intValue]==1){
                        self.sinkingShipOrientation=2;
                        if(!self.reachedOtherEndOfShip){
                            self.reachedOtherEndOfShip=true;
                        }else{
                            self.sinkingShip=false;
                            self.reachedOtherEndOfShip=false;
                            self.sinkingShipOrientation=-1;
                        }
                    }
                }
            }
            
        }
        NSLog(@"exiting shipSink loop with value %i and orientation %i", volleyIndex, self.sinkingShipOrientation);
    }
    int targetHit = [[self.leftGrid objectAtIndex:volleyIndex] intValue];
    while(!(targetHit==5||targetHit==4||targetHit==31||targetHit==32||targetHit==2||targetHit==0)){
        volleyIndex = arc4random_uniform(100);
        if(self.sinkingShip){
            NSLog(@"entering shipSink loop with random value %i and orientation %i", volleyIndex, self.sinkingShipOrientation);
            bool volleySpotNotFound=true;
            if(self.sinkingShipOrientation==-1){ //orientation unknown
                volleySpotNotFound=true;
                NSLog(@"Orientation Unknown");
                if(self.sinkingShipIndex%10!=0&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex-1] intValue]%10!=9&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex-1] intValue]!=1){
                    NSLog(@"Trying the left position");
                    
                    volleyIndex=self.sinkingShipIndex-1;
                    if([[self.leftGrid objectAtIndex:self.sinkingShipIndex-1] intValue]!=0){
                        self.sinkingShipOrientation=1;
                    }
                    
                }else if(self.sinkingShipIndex%10!=9&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex+1] intValue]%10!=9&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex+1] intValue]!=1){
                    NSLog(@"Trying the right position");
                    volleyIndex=self.sinkingShipIndex+1;
                    if([[self.leftGrid objectAtIndex:self.sinkingShipIndex+1] intValue]!=0){
                        self.sinkingShipOrientation=0;
                    }
                }else if(self.sinkingShipIndex-10>=0&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex-10] intValue]%10!=9&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex-10] intValue]!=1){
                    NSLog(@"Trying the up position");
                    volleyIndex=self.sinkingShipIndex-10;
                    if([[self.leftGrid objectAtIndex:self.sinkingShipIndex-10] intValue]!=0){
                        self.sinkingShipOrientation=3;
                    }
                }else if(self.sinkingShipIndex+10<100&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex+10] intValue]%10!=9&&[[self.leftGrid objectAtIndex:self.sinkingShipIndex+10] intValue]!=1){
                    NSLog(@"Trying the down position");
                    volleyIndex=self.sinkingShipIndex+10;
                    if([[self.leftGrid objectAtIndex:self.sinkingShipIndex+10] intValue]!=0){
                        self.sinkingShipOrientation=2;
                    }
                }
            }
            else if(self.sinkingShipOrientation==0){ //orientation horizontal, going right
                for(int i=self.sinkingShipIndex; volleySpotNotFound; i++){
                    NSLog(@"Going right and checking spot %i",i);
                    if([[self.leftGrid objectAtIndex:i] intValue]%10!=9){
                        volleyIndex=i;
                        volleySpotNotFound=false;
                        if([[self.leftGrid objectAtIndex:i] intValue]==0||i%10==9||[[self.leftGrid objectAtIndex:i] intValue]==1){
                            self.sinkingShipOrientation=1;
                            if(!self.reachedOtherEndOfShip){
                                self.reachedOtherEndOfShip=true;
                            }else{
                                self.sinkingShip=false;
                                self.reachedOtherEndOfShip=false;
                                self.sinkingShipOrientation=-1;
                            }
                        }
                    }
                }
            }
            else if(self.sinkingShipOrientation==1){ //orientation horizontal, going left
                for(int i=self.sinkingShipIndex; volleySpotNotFound; i--){
                    NSLog(@"Going left and checking spot %i",i);
                    if([[self.leftGrid objectAtIndex:i] intValue]%10!=9){
                        volleyIndex=i;
                        volleySpotNotFound=false;
                        NSLog(@"Volleying at spot %i which contains value %i",i, [[self.leftGrid objectAtIndex:i] intValue]);
                        if([[self.leftGrid objectAtIndex:i] intValue]==0||i%10==0||[[self.leftGrid objectAtIndex:i] intValue]==1){
                            self.sinkingShipOrientation=0;
                            if(!self.reachedOtherEndOfShip){
                                self.reachedOtherEndOfShip=true;
                            }else{
                                self.sinkingShip=false;
                                self.reachedOtherEndOfShip=false;
                                self.sinkingShipOrientation=-1;
                            }
                        }
                    }
                }
            }
            else if(self.sinkingShipOrientation==2){ //orientation vertical, going down
                for(int i=self.sinkingShipIndex; volleySpotNotFound; i+=10){
                    NSLog(@"Going down and checking spot %i",i);
                    if([[self.leftGrid objectAtIndex:i] intValue]%10!=9){
                        volleyIndex=i;
                        volleySpotNotFound=false;
                        if([[self.leftGrid objectAtIndex:i] intValue]==0||i>=90||[[self.leftGrid objectAtIndex:i] intValue]==1){
                            self.sinkingShipOrientation=3;
                            if(!self.reachedOtherEndOfShip){
                                self.reachedOtherEndOfShip=true;
                            }else{
                                self.sinkingShip=false;
                                self.reachedOtherEndOfShip=false;
                                self.sinkingShipOrientation=-1;
                            }
                        }
                    }
                }
            }
            else{ //orientation vertical, going up
                for(int i=self.sinkingShipIndex; volleySpotNotFound; i-=10){
                    NSLog(@"Going up and checking spot %i",i);
                    if([[self.leftGrid objectAtIndex:i] intValue]%10!=9){
                        volleyIndex=i;
                        volleySpotNotFound=false;
                        if([[self.leftGrid objectAtIndex:i] intValue]==0||i<10||[[self.leftGrid objectAtIndex:i] intValue]==1){
                            self.sinkingShipOrientation=2;
                            if(!self.reachedOtherEndOfShip){
                                self.reachedOtherEndOfShip=true;
                            }else{
                                self.sinkingShip=false;
                                self.reachedOtherEndOfShip=false;
                                self.sinkingShipOrientation=-1;
                            }
                        }
                    }
                }
                
            }
            NSLog(@"exiting shipSink loop with value %i and orientation %i", volleyIndex, self.sinkingShipOrientation);
        }
        targetHit = [[self.leftGrid objectAtIndex:volleyIndex] intValue];
    }
    int gridX = [self computeLeftXCoord:volleyIndex];
    int gridY = [self computeLeftYCoord:volleyIndex];
    if(targetHit==0){
        UIImageView *miss =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
        miss.image=[UIImage imageNamed:@"miss.png"];
        [self.view addSubview:miss];
        [self.leftGrid replaceObjectAtIndex:volleyIndex withObject:[NSNumber numberWithInteger:1]];
    }else if(targetHit==5){
        if(!self.sinkingShip){
            self.sinkingShip=true;
            self.sinkingShipIndex=volleyIndex;
        }
        UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
        hit.image=[UIImage imageNamed:@"hit.png"];
        [self.view addSubview:hit];
        [self.leftGrid replaceObjectAtIndex:volleyIndex withObject:[NSNumber numberWithInteger:59]];
        if(![self.leftGrid containsObject:[NSNumber numberWithInt:5]]){ //fiveShip is now dead
            NSLog(@"Player Five Ship Down!");
            [self playDaikajiuSound];
            self.fiveShip.alpha = 0.0f;
            [UIView animateWithDuration:0.5f
                                  delay:0.0f
                                options:UIViewAnimationOptionAutoreverse
                             animations:^ {
                                 [UIView setAnimationRepeatCount:8.0f/2.0f];
                                 self.fiveShip.alpha = 1.0f;
                             } completion:^(BOOL finished) {}];
            self.sinkingShip=false;
            self.reachedOtherEndOfShip=false;
            self.sinkingShipOrientation=-1;
            self.playerShipsRemaining--;
            if(self.playerShipsRemaining==0){
                [self computerWins];
            }
        }
    }else if(targetHit==4){
        if(!self.sinkingShip){
            self.sinkingShip=true;
            self.sinkingShipIndex=volleyIndex;
        }
        UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
        hit.image=[UIImage imageNamed:@"hit.png"];
        [self.view addSubview:hit];
        [self.leftGrid replaceObjectAtIndex:volleyIndex withObject:[NSNumber numberWithInteger:49]];
        if(![self.leftGrid containsObject:[NSNumber numberWithInt:4]]){ //fourShip is now dead
            NSLog(@"Player Four Ship Down!");
            [self playDaikajiuSound];
            self.fourShip.alpha = 0.0f;
            [UIView animateWithDuration:0.5f
                                  delay:0.0f
                                options:UIViewAnimationOptionAutoreverse
                             animations:^ {
                                 [UIView setAnimationRepeatCount:8.0f/2.0f];
                                 self.fourShip.alpha = 1.0f;
                             } completion:^(BOOL finished) {}];
            
            self.sinkingShip=false;
            self.reachedOtherEndOfShip=false;
            self.sinkingShipOrientation=-1;
            self.playerShipsRemaining--;
            if(self.playerShipsRemaining==0){
                [self computerWins];
            }
        }
    }else if(targetHit==31){
        if(!self.sinkingShip){
            self.sinkingShip=true;
            self.sinkingShipIndex=volleyIndex;
        }
        UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
        hit.image=[UIImage imageNamed:@"hit.png"];
        [self.view addSubview:hit];
        [self.leftGrid replaceObjectAtIndex:volleyIndex withObject:[NSNumber numberWithInteger:319]];
        if(![self.leftGrid containsObject:[NSNumber numberWithInt:31]]){ //threeShipOne is now dead
            NSLog(@"Player Three Ship One Down!");
            [self playDaikajiuSound];
            self.threeShipOne.alpha = 0.0f;
            [UIView animateWithDuration:0.5f
                                  delay:0.0f
                                options:UIViewAnimationOptionAutoreverse
                             animations:^ {
                                 [UIView setAnimationRepeatCount:8.0f/2.0f];
                                 self.threeShipOne.alpha = 1.0f;
                             } completion:^(BOOL finished) {}];
            
            self.sinkingShip=false;
            self.reachedOtherEndOfShip=false;
            self.sinkingShipOrientation=-1;
            self.playerShipsRemaining--;
            if(self.playerShipsRemaining==0){
                [self computerWins];
            }
        }
    }else if(targetHit==32){
        if(!self.sinkingShip){
            self.sinkingShip=true;
            self.sinkingShipIndex=volleyIndex;
        }
        UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
        hit.image=[UIImage imageNamed:@"hit.png"];
        [self.view addSubview:hit];
        [self.leftGrid replaceObjectAtIndex:volleyIndex withObject:[NSNumber numberWithInteger:329]];
        if(![self.leftGrid containsObject:[NSNumber numberWithInt:32]]){ //threeShipTwo is now dead
            NSLog(@"Player Three Ship Two Down!");
            [self playDaikajiuSound];
            self.threeShipTwo.alpha = 0.0f;
            [UIView animateWithDuration:0.5f
                                  delay:0.0f
                                options:UIViewAnimationOptionAutoreverse
                             animations:^ {
                                 [UIView setAnimationRepeatCount:8.0f/2.0f];
                                 self.threeShipTwo.alpha = 1.0f;
                             } completion:^(BOOL finished) {}];
            self.sinkingShip=false;
            self.reachedOtherEndOfShip=false;
            self.sinkingShipOrientation=-1;
            self.playerShipsRemaining--;
            if(self.playerShipsRemaining==0){
                [self computerWins];
            }
        }
    }else if(targetHit==2){
        if(!self.sinkingShip){
            self.sinkingShip=true;
            self.sinkingShipIndex=volleyIndex;
        }
        UIImageView *hit =[[UIImageView alloc] initWithFrame:CGRectMake(gridX,gridY,40,40)];
        hit.image=[UIImage imageNamed:@"hit.png"];
        [self.view addSubview:hit];
        [self.leftGrid replaceObjectAtIndex:volleyIndex withObject:[NSNumber numberWithInteger:21]];
        if(![self.leftGrid containsObject:[NSNumber numberWithInt:2]]){ //twoShip is now dead
            NSLog(@"Player Two Ship Down!");
            [self playDaikajiuSound];
            self.twoShip.alpha = 0.0f;
            [UIView animateWithDuration:0.5f
                                  delay:0.0f
                                options:UIViewAnimationOptionAutoreverse
                             animations:^ {
                                 [UIView setAnimationRepeatCount:8.0f/2.0f];
                                 self.twoShip.alpha = 1.0f;
                             } completion:^(BOOL finished) {}];
            self.sinkingShip=false;
            self.reachedOtherEndOfShip=false;
            self.sinkingShipOrientation=-1;
            self.playerShipsRemaining--;
            if(self.playerShipsRemaining==0){
                [self computerWins];
            }
        }
    }
    
}
-(void)computerWins
{
    self.gameOver=true;
    NSLog(@"Computer Wins!");
    NSLog(@"Trying to play victory sound");
    NSString *victoryPath = [[NSBundle mainBundle] pathForResource:@"victoryjingle" ofType:@"wav"];
    NSURL *victoryURL = [NSURL fileURLWithPath:victoryPath];
    NSError *error;
    self.monsterNoisePlayer = [[AVAudioPlayer alloc]
                               initWithContentsOfURL:victoryURL error:&error];
    [self.monsterNoisePlayer prepareToPlay];
    [self.monsterNoisePlayer play];
    UIAlertController * alert=   [UIAlertController
                                  alertControllerWithTitle:@"Computer Wins!"
                                  message:@"All your ships have been sunk."
                                  preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction* ok = [UIAlertAction
                         actionWithTitle:@"OK"
                         style:UIAlertActionStyleDefault
                         handler:^(UIAlertAction * action)
                         {
                             [alert dismissViewControllerAnimated:YES completion:nil];
                             [self presentViewController:[self.storyboard instantiateInitialViewController] animated:YES completion:nil];
                             
                         }];
    [alert addAction:ok];
    
    [self presentViewController:alert animated:YES completion:nil];
}
-(int)computeLeftXCoord:(int)tag
{
    int x = 56+40*(tag%10);
    return x;
}
-(int)computeLeftYCoord:(int)tag
{
    int y = 184+40*((tag-(tag%10))/10);
    return y;
}
-(int)computeRightXCoord:(int)tag
{
    int x = 568+40*(tag%10);
    return x;
}
-(int)computeRightYCoord:(int)tag
{
    int y = 184+40*((tag-(tag%10))/10);
    return y;
}
-(int)computeLeftArrayIndex:(CGPoint)topLeft
{
    int arrayXIndex = (topLeft.x-56)/40;
    int arrayYIndex = (topLeft.y-184)/40;
    int arrayIndex = (arrayYIndex)*10+arrayXIndex;
    return arrayIndex;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:self.view];
    
    
    if(self.turn==1){ //Player 1 Logic
        if(!self.shipsLockedIn){
        if ([touch tapCount]==1){
            if (CGRectContainsPoint([self.fiveShip frame], [touch locationInView:self.view])){
                self.fiveDragging=true;
                if(self.fiveOnBoard){
                    [self removeTempBarrier:self.fiveShip.frame];
                }
            }else if (CGRectContainsPoint([self.fourShip frame], [touch locationInView:self.view])){
                self.fourDragging=true;
                if(self.fourOnBoard){
                    [self removeTempBarrier:self.fourShip.frame];
                }
            }else if (CGRectContainsPoint([self.threeShipOne frame], [touch locationInView:self.view])){
                self.threeOneDragging=true;
                if(self.threeOneOnBoard){
                    [self removeTempBarrier:self.threeShipOne.frame];
                }
            }else if (CGRectContainsPoint([self.threeShipTwo frame], [touch locationInView:self.view])){
                self.threeTwoDragging=true;
                if(self.threeTwoOnBoard){
                    [self removeTempBarrier:self.threeShipTwo.frame];
                }
            }else if (CGRectContainsPoint([self.twoShip frame], [touch locationInView:self.view])){
                self.twoDragging=true;
                if(self.twoOnBoard){
                    [self removeTempBarrier:self.twoShip.frame];
                }
            }
        }else if([touch tapCount]==2){
            if (CGRectContainsPoint([self.fiveShip frame], [touch locationInView:self.view])){
                self.fiveDragging=true;
                if(self.fiveOnBoard){
                    [self removeTempBarrier:self.fiveShip.frame];
                }
                if(self.fiveShip.frame.size.height==40){
                    self.fiveShip.transform = CGAffineTransformMakeRotation(M_PI_2);
                }else{
                    self.fiveShip.transform = CGAffineTransformMakeRotation(0);
                }
                self.fiveShip.center = [self gridSnapWithCenter:location andFrame:self.fiveShip.frame];
            }else if (CGRectContainsPoint([self.fourShip frame], [touch locationInView:self.view])){
                self.fourDragging=true;
                if(self.fourOnBoard){
                    [self removeTempBarrier:self.fourShip.frame];
                }
                if(self.fourShip.frame.size.height==40){
                    self.fourShip.transform = CGAffineTransformMakeRotation(M_PI_2);
                }else{
                    self.fourShip.transform = CGAffineTransformMakeRotation(0);
                }
                self.fourShip.center = [self gridSnapWithCenter:location andFrame:self.fourShip.frame];
            }else if (CGRectContainsPoint([self.threeShipOne frame], [touch locationInView:self.view])){
                self.threeOneDragging=true;
                if(self.threeOneOnBoard){
                    [self removeTempBarrier:self.threeShipOne.frame];
                }
                if(self.threeShipOne.frame.size.height==40){
                    self.threeShipOne.transform = CGAffineTransformMakeRotation(M_PI_2);
                }else{
                    self.threeShipOne.transform = CGAffineTransformMakeRotation(0);
                }
                self.threeShipOne.center = [self gridSnapWithCenter:location andFrame:self.threeShipOne.frame];
            }else if (CGRectContainsPoint([self.threeShipTwo frame], [touch locationInView:self.view])){
                self.threeTwoDragging=true;
                if(self.threeTwoOnBoard){
                    [self removeTempBarrier:self.threeShipTwo.frame];
                }
                if(self.threeShipTwo.frame.size.height==40){
                    self.threeShipTwo.transform = CGAffineTransformMakeRotation(M_PI_2);
                }else{
                    self.threeShipTwo.transform = CGAffineTransformMakeRotation(0);
                }
                self.threeShipTwo.center = [self gridSnapWithCenter:location andFrame:self.threeShipTwo.frame];
            }else if (CGRectContainsPoint([self.twoShip frame], [touch locationInView:self.view])){
                self.twoDragging=true;
                if(self.twoOnBoard){
                    [self removeTempBarrier:self.twoShip.frame];
                }
                if(self.twoShip.frame.size.height==40){
                    self.twoShip.transform = CGAffineTransformMakeRotation(M_PI_2);
                }else{
                    self.twoShip.transform = CGAffineTransformMakeRotation(0);
                }
                self.twoShip.center = [self gridSnapWithCenter:location andFrame:self.twoShip.frame];
            }
        }
    }
        
    }else{ //Player 2 Logic
        if(!self.shipsLockedIn){
            if ([touch tapCount]==1){
                if (CGRectContainsPoint([self.fiveShip2 frame], [touch locationInView:self.view])){
                    self.fiveDragging2=true;
                    if(self.fiveOnBoard2){
                        [self removeTempBarrier:self.fiveShip2.frame];
                    }
                }else if (CGRectContainsPoint([self.fourShip2 frame], [touch locationInView:self.view])){
                    self.fourDragging2=true;
                    NSLog(@"We are dragging four around.");
                    if(self.fourOnBoard2){
                        [self removeTempBarrier:self.fourShip2.frame];
                    }
                }else if (CGRectContainsPoint([self.threeShipOne2 frame], [touch locationInView:self.view])){
                    self.threeOneDragging2=true;
                    if(self.threeOneOnBoard2){
                        [self removeTempBarrier:self.threeShipOne2.frame];
                    }
                }else if (CGRectContainsPoint([self.threeShipTwo2 frame], [touch locationInView:self.view])){
                    self.threeTwoDragging2=true;
                    if(self.threeTwoOnBoard2){
                        [self removeTempBarrier:self.threeShipTwo2.frame];
                    }
                }else if (CGRectContainsPoint([self.twoShip2 frame], [touch locationInView:self.view])){
                    self.twoDragging2=true;
                    NSLog(@"We are dragging two around.");
                    if(self.twoOnBoard2){
                        [self removeTempBarrier:self.twoShip2.frame];
                    }
                }
            }else if([touch tapCount]==2){
                if (CGRectContainsPoint([self.fiveShip2 frame], [touch locationInView:self.view])){
                    self.fiveDragging2=true;
                    if(self.fiveOnBoard2){
                        [self removeTempBarrier:self.fiveShip2.frame];
                    }
                    if(self.fiveShip2.frame.size.height==40){
                        self.fiveShip2.transform = CGAffineTransformMakeRotation(M_PI_2);
                    }else{
                        self.fiveShip2.transform = CGAffineTransformMakeRotation(0);
                    }
                    self.fiveShip2.center = [self gridSnapWithCenter:location andFrame:self.fiveShip2.frame];
                }else if (CGRectContainsPoint([self.fourShip2 frame], [touch locationInView:self.view])){
                    self.fourDragging2=true;
                    if(self.fourOnBoard2){
                        [self removeTempBarrier:self.fourShip2.frame];
                    }
                    if(self.fourShip2.frame.size.height==40){
                        self.fourShip2.transform = CGAffineTransformMakeRotation(M_PI_2);
                    }else{
                        self.fourShip2.transform = CGAffineTransformMakeRotation(0);
                    }
                    self.fourShip2.center = [self gridSnapWithCenter:location andFrame:self.fourShip2.frame];
                }else if (CGRectContainsPoint([self.threeShipOne2 frame], [touch locationInView:self.view])){
                    self.threeOneDragging2=true;
                    if(self.threeOneOnBoard2){
                        [self removeTempBarrier:self.threeShipOne2.frame];
                    }
                    if(self.threeShipOne2.frame.size.height==40){
                        self.threeShipOne2.transform = CGAffineTransformMakeRotation(M_PI_2);
                    }else{
                        self.threeShipOne2.transform = CGAffineTransformMakeRotation(0);
                    }
                    self.threeShipOne2.center = [self gridSnapWithCenter:location andFrame:self.threeShipOne2.frame];
                }else if (CGRectContainsPoint([self.threeShipTwo2 frame], [touch locationInView:self.view])){
                    self.threeTwoDragging2=true;
                    if(self.threeTwoOnBoard2){
                        [self removeTempBarrier:self.threeShipTwo2.frame];
                    }
                    if(self.threeShipTwo2.frame.size.height==40){
                        self.threeShipTwo2.transform = CGAffineTransformMakeRotation(M_PI_2);
                    }else{
                        self.threeShipTwo2.transform = CGAffineTransformMakeRotation(0);
                    }
                    self.threeShipTwo2.center = [self gridSnapWithCenter:location andFrame:self.threeShipTwo2.frame];
                }else if (CGRectContainsPoint([self.twoShip2 frame], [touch locationInView:self.view])){
                    self.twoDragging2=true;
                    if(self.twoOnBoard2){
                        [self removeTempBarrier:self.twoShip2.frame];
                    }
                    if(self.twoShip2.frame.size.height==40){
                        self.twoShip2.transform = CGAffineTransformMakeRotation(M_PI_2);
                    }else{
                        self.twoShip2.transform = CGAffineTransformMakeRotation(0);
                    }
                    self.twoShip2.center = [self gridSnapWithCenter:location andFrame:self.twoShip2.frame];
                }
            }
        }
    }
}


-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:self.view];
    if(self.turn==1){
        if(!self.shipsLockedIn){
            if(self.fiveDragging){
                [self.fiveShip setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.fiveShip.center = [self gridSnapWithCenter:location andFrame:self.fiveShip.frame];
            }else if(self.fourDragging){
                [self.fourShip setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.fourShip.center = [self gridSnapWithCenter:location andFrame:self.fourShip.frame];
            }else if(self.threeOneDragging){
                [self.threeShipOne setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.threeShipOne.center = [self gridSnapWithCenter:location andFrame:self.threeShipOne.frame];
            }else if(self.threeTwoDragging){
                [self.threeShipTwo setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.threeShipTwo.center = [self gridSnapWithCenter:location andFrame:self.threeShipTwo.frame];
            }else if(self.twoDragging){
                [self.twoShip setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.twoShip.center = [self gridSnapWithCenter:location andFrame:self.twoShip.frame];
            }
        }
    }else{
        if(!self.shipsLockedIn){
            if(self.fiveDragging2){
                [self.fiveShip2 setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.fiveShip2.center = [self gridSnapWithCenter:location andFrame:self.fiveShip2.frame];
            }else if(self.fourDragging2){
                [self.fourShip2 setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.fourShip2.center = [self gridSnapWithCenter:location andFrame:self.fourShip2.frame];
            }else if(self.threeOneDragging2){
                [self.threeShipOne2 setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.threeShipOne2.center = [self gridSnapWithCenter:location andFrame:self.threeShipOne2.frame];
            }else if(self.threeTwoDragging2){
                [self.threeShipTwo2 setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.threeShipTwo2.center = [self gridSnapWithCenter:location andFrame:self.threeShipTwo2.frame];
            }else if(self.twoDragging2){
                [self.twoShip2 setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.twoShip2.center = [self gridSnapWithCenter:location andFrame:self.twoShip2.frame];
            }
        }
    }
}
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event{
    UITouch *touch = [touches anyObject];
    CGPoint location = [touch locationInView:self.view];
    if(self.turn==1){
        if(!self.shipsLockedIn){
            if(self.fiveDragging){
                [self.fiveShip setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.fiveShip.center = [self gridSnapWithCenter:location andFrame:self.fiveShip.frame];
                [self tempInstall:self.fiveShip.frame withID:5];
                self.fiveOnBoard=true;
            }else if(self.fourDragging){
                [self.fourShip setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.fourShip.center = [self gridSnapWithCenter:location andFrame:self.fourShip.frame];
                [self tempInstall:self.fourShip.frame withID:4];
                self.fourOnBoard=true;
            }else if(self.threeOneDragging){
                [self.threeShipOne setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.threeShipOne.center = [self gridSnapWithCenter:location andFrame:self.threeShipOne.frame];
                [self tempInstall:self.threeShipOne.frame withID:31];
                self.threeOneOnBoard=true;
            }else if(self.threeTwoDragging){[self.threeShipTwo setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.threeShipTwo.center = [self gridSnapWithCenter:location andFrame:self.threeShipTwo.frame];
                [self tempInstall:self.threeShipTwo.frame withID:32];
                self.threeTwoOnBoard=true;
            }else if(self.twoDragging){
                [self.twoShip setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.twoShip.center = [self gridSnapWithCenter:location andFrame:self.twoShip.frame];
                [self tempInstall:self.twoShip.frame withID:2];
                self.twoOnBoard=true;
            }
        }
    }else{
        if(!self.shipsLockedIn){
            if(self.fiveDragging2){
                [self.fiveShip2 setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.fiveShip2.center = [self gridSnapWithCenter:location andFrame:self.fiveShip2.frame];
                [self tempInstall:self.fiveShip2.frame withID:5];
                self.fiveOnBoard2=true;
            }else if(self.fourDragging2){
                [self.fourShip2 setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.fourShip2.center = [self gridSnapWithCenter:location andFrame:self.fourShip2.frame];
                [self tempInstall:self.fourShip2.frame withID:4];
                self.fourOnBoard2=true;
            }else if(self.threeOneDragging2){
                [self.threeShipOne2 setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.threeShipOne2.center = [self gridSnapWithCenter:location andFrame:self.threeShipOne2.frame];
                [self tempInstall:self.threeShipOne2.frame withID:31];
                self.threeOneOnBoard2=true;
            }else if(self.threeTwoDragging2){[self.threeShipTwo2 setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.threeShipTwo2.center = [self gridSnapWithCenter:location andFrame:self.threeShipTwo2.frame];
                [self tempInstall:self.threeShipTwo2.frame withID:32];
                self.threeTwoOnBoard2=true;
            }else if(self.twoDragging2){
                [self.twoShip2 setTranslatesAutoresizingMaskIntoConstraints:YES];
                self.twoShip2.center = [self gridSnapWithCenter:location andFrame:self.twoShip2.frame];
                [self tempInstall:self.twoShip2.frame withID:2];
                self.twoOnBoard2=true;
            }
        }
    }
    self.fiveDragging=false;
    self.fourDragging=false;
    self.threeOneDragging=false;
    self.threeTwoDragging=false;
    self.twoDragging=false;
    self.fiveDragging2=false;
    self.fourDragging2=false;
    self.threeOneDragging2=false;
    self.threeTwoDragging2=false;
    self.twoDragging2=false;
}
-(void)removeTempBarrier:(CGRect)shipFrame
{
    if(self.turn==1){
        if(shipFrame.size.height==40){ //Ship is horizontal
            for(int arrayUpdateX = shipFrame.origin.x; arrayUpdateX < shipFrame.origin.x + shipFrame.size.width; arrayUpdateX += 40){
                [self.leftGrid replaceObjectAtIndex:[self computeLeftArrayIndex:CGPointMake(arrayUpdateX, shipFrame.origin.y)] withObject:[NSNumber numberWithInteger:0]];
            }
        }else{ //Ship is vertical
            for(int arrayUpdateY = shipFrame.origin.y; arrayUpdateY < shipFrame.origin.y + shipFrame.size.height; arrayUpdateY += 40){
                [self.leftGrid replaceObjectAtIndex:[self computeLeftArrayIndex:CGPointMake(shipFrame.origin.x, arrayUpdateY)] withObject:[NSNumber numberWithInteger:0]];
            }
        }
    }else{
        if(shipFrame.size.height==40){ //Ship is horizontal
            for(int arrayUpdateX = shipFrame.origin.x; arrayUpdateX < shipFrame.origin.x + shipFrame.size.width; arrayUpdateX += 40){
                [self.rightGrid replaceObjectAtIndex:[self computeLeftArrayIndex:CGPointMake(arrayUpdateX, shipFrame.origin.y)] withObject:[NSNumber numberWithInteger:0]];
            }
        }else{ //Ship is vertical
            for(int arrayUpdateY = shipFrame.origin.y; arrayUpdateY < shipFrame.origin.y + shipFrame.size.height; arrayUpdateY += 40){
                [self.rightGrid replaceObjectAtIndex:[self computeLeftArrayIndex:CGPointMake(shipFrame.origin.x, arrayUpdateY)] withObject:[NSNumber numberWithInteger:0]];
            }
        }
    }
}
-(void)tempInstall:(CGRect)shipFrame withID:(int)shipNum
{
    if(self.turn==1){
        if(shipFrame.size.height==40){ //Ship is horizontal
            for(int arrayUpdateX = shipFrame.origin.x; arrayUpdateX < shipFrame.origin.x + shipFrame.size.width; arrayUpdateX += 40){
                [self.leftGrid replaceObjectAtIndex:[self computeLeftArrayIndex:CGPointMake(arrayUpdateX, shipFrame.origin.y)] withObject:[NSNumber numberWithInteger:shipNum]];
                NSLog(@"Changed index %i to a %i because we think the ship is horizontal.",[self computeLeftArrayIndex:CGPointMake(arrayUpdateX, shipFrame.origin.y)],shipNum);
            }
        }else{ //Ship is vertical
            for(int arrayUpdateY = shipFrame.origin.y; arrayUpdateY < shipFrame.origin.y + shipFrame.size.height; arrayUpdateY += 40){
                [self.leftGrid replaceObjectAtIndex:[self computeLeftArrayIndex:CGPointMake(shipFrame.origin.x, arrayUpdateY)] withObject:[NSNumber numberWithInteger:shipNum]];
                NSLog(@"Changed index %i to a %i because we think the ship is vertical.",[self computeLeftArrayIndex:CGPointMake(arrayUpdateY, shipFrame.origin.y)],shipNum);
            }
        }
    }else{
        if(shipFrame.size.height==40){ //Ship is horizontal
            for(int arrayUpdateX = shipFrame.origin.x; arrayUpdateX < shipFrame.origin.x + shipFrame.size.width; arrayUpdateX += 40){
                [self.rightGrid replaceObjectAtIndex:[self computeLeftArrayIndex:CGPointMake(arrayUpdateX, shipFrame.origin.y)] withObject:[NSNumber numberWithInteger:shipNum]];
                NSLog(@"Changed index %i to a %i because we think the ship is horizontal.",[self computeLeftArrayIndex:CGPointMake(arrayUpdateX, shipFrame.origin.y)],shipNum);
            }
        }else{ //Ship is vertical
            for(int arrayUpdateY = shipFrame.origin.y; arrayUpdateY < shipFrame.origin.y + shipFrame.size.height; arrayUpdateY += 40){
                [self.rightGrid replaceObjectAtIndex:[self computeLeftArrayIndex:CGPointMake(shipFrame.origin.x, arrayUpdateY)] withObject:[NSNumber numberWithInteger:shipNum]];
                NSLog(@"Changed index %i to a %i because we think the ship is vertical.",[self computeLeftArrayIndex:CGPointMake(arrayUpdateY, shipFrame.origin.y)],shipNum);
            }
        }
    }
}
-(CGPoint)gridSnapWithCenter:(CGPoint)center andFrame:(CGRect)frame
{
    CGPoint hoverOrigin = CGPointMake(center.x - (frame.size.width/2), center.y - (frame.size.height/2));
    double bestDist=1024;
    int bestX = 0;
    int bestY = 0;
    if(self.turn==1){
    for(int y = 184; y<584; y+=40){
        for(int x = 56; x<456; x+=40){
            double dist = sqrt(pow(hoverOrigin.x-x,2)+pow(hoverOrigin.y-y,2));
            if(dist < bestDist&&x+frame.size.width<=456&&y+frame.size.height<=584){
                bool collides=false;
                if(frame.size.height==40){ //Ship is horizontal
                    //NSLog(@"Trying to do a horizontal grid snap because frame.size.height = %f",frame.size.height);
                    for(int arrayCheckX = x; arrayCheckX < x + frame.size.width; arrayCheckX += 40){
                        int gridCheckX = [[self.leftGrid objectAtIndex:[self computeLeftArrayIndex:CGPointMake(arrayCheckX, y)]] intValue];
                        if(gridCheckX!=0){
                            collides=true;
                        }
                        
                    }
                }else{ //Ship is vertical
                    //NSLog(@"Trying to do a vertical grid snap because frame.size.height = %f",frame.size.height);
                    for(int arrayCheckY = y; arrayCheckY < y + frame.size.height; arrayCheckY += 40){
                        int gridCheckY = [[self.leftGrid objectAtIndex:[self computeLeftArrayIndex:CGPointMake(x, arrayCheckY)]] intValue];
                        if(gridCheckY!=0){
                            collides=true;
                        }
                        
                    }
                }
                
                if(!collides){
                    bestDist=dist;
                    bestX=x;
                    bestY=y;
                }
            }
        }
    }
    }else{
        for(int y = 184; y<584; y+=40){
            for(int x = 56; x<456; x+=40){
                double dist = sqrt(pow(hoverOrigin.x-x,2)+pow(hoverOrigin.y-y,2));
                if(dist < bestDist&&x+frame.size.width<=456&&y+frame.size.height<=584){
                    bool collides=false;
                    if(frame.size.height==40){ //Ship is horizontal
                        //NSLog(@"Trying to do a horizontal grid snap because frame.size.height = %f",frame.size.height);
                        for(int arrayCheckX = x; arrayCheckX < x + frame.size.width; arrayCheckX += 40){
                            int gridCheckX = [[self.rightGrid objectAtIndex:[self computeLeftArrayIndex:CGPointMake(arrayCheckX, y)]] intValue];
                            if(gridCheckX!=0){
                                collides=true;
                            }
                            
                        }
                    }else{ //Ship is vertical
                        //NSLog(@"Trying to do a vertical grid snap because frame.size.height = %f",frame.size.height);
                        for(int arrayCheckY = y; arrayCheckY < y + frame.size.height; arrayCheckY += 40){
                            int gridCheckY = [[self.rightGrid objectAtIndex:[self computeLeftArrayIndex:CGPointMake(x, arrayCheckY)]] intValue];
                            if(gridCheckY!=0){
                                collides=true;
                            }
                            
                        }
                    }
                    
                    if(!collides){
                        bestDist=dist;
                        bestX=x;
                        bestY=y;
                    }
                }
            }
        }
    }
    CGPoint bestCenter=CGPointMake(bestX + (frame.size.width/2), bestY + (frame.size.height/2));
    return bestCenter;
}
-(void)playDaikajiuSound
{
    NSLog(@"Trying to play monster sound");
    NSString *daikaijuPath = [[NSBundle mainBundle] pathForResource:@"seamonster" ofType:@"wav"];
    NSURL *daikaijuURL = [NSURL fileURLWithPath:daikaijuPath];
    NSError *error;
    self.monsterNoisePlayer = [[AVAudioPlayer alloc]
                               initWithContentsOfURL:daikaijuURL error:&error];
    [self.monsterNoisePlayer prepareToPlay];
    [self.monsterNoisePlayer play];
    
    
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
