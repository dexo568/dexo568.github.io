//
//  TwoPlayerViewController.m
//  McKelveyHembree-Lab3
//
//  Created by Labuser on 9/28/14.
//  Copyright (c) 2014 WUSTL CSE. All rights reserved.
//

#import "TwoPlayerViewController.h"

@interface TwoPlayerViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *square1;
@property (weak, nonatomic) IBOutlet UIImageView *square2;
@property (weak, nonatomic) IBOutlet UIImageView *square3;
@property (weak, nonatomic) IBOutlet UIImageView *square4;
@property (weak, nonatomic) IBOutlet UIImageView *square5;
@property (weak, nonatomic) IBOutlet UIImageView *square6;
@property (weak, nonatomic) IBOutlet UIImageView *square7;
@property (weak, nonatomic) IBOutlet UIImageView *square8;
@property (weak, nonatomic) IBOutlet UIImageView *square9;
@property (weak, nonatomic) IBOutlet UILabel *turnLabel;
@property (weak, nonatomic) IBOutlet UIButton *button1;
@property (weak, nonatomic) IBOutlet UIButton *button2;
@property (weak, nonatomic) IBOutlet UIButton *button3;
@property (weak, nonatomic) IBOutlet UIButton *button4;
@property (weak, nonatomic) IBOutlet UIButton *button5;
@property (weak, nonatomic) IBOutlet UIButton *button6;
@property (weak, nonatomic) IBOutlet UIButton *button7;
@property (weak, nonatomic) IBOutlet UIButton *button8;
@property (weak, nonatomic) IBOutlet UIButton *button9;
@property (weak, nonatomic) IBOutlet UIImageView *playerNumView;
@property int playerTurn;
@property int turn;

@end

@implementation TwoPlayerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.boardArray = [[NSMutableArray alloc] initWithObjects:@"e",@"e",@"e",@"e",@"e",@"e",@"e",@"e",@"e", nil];
    [self updateBoardVisual];
    UIAlertView *gameStart = [[UIAlertView alloc] initWithTitle:@"Who should move first?"
                                                      message:nil
                                                     delegate:self
                                            cancelButtonTitle:@"Random"
                                              otherButtonTitles:@"Player 1",@"Player 2",nil];
    [gameStart show];
    self.turn = arc4random() % 2;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if([alertView.title isEqual:@"Who should move first?"]){
        NSString *choice = [alertView buttonTitleAtIndex:buttonIndex];
        UIImage *one = [UIImage imageNamed: @"one.gif"];
        UIImage *two = [UIImage imageNamed: @"two.gif"];
        if([choice isEqual:@"Player 1"]){
            self.playerTurn=1;
            [self.playerNumView setImage:one];
        }else if([choice isEqual:@"Player 2"]){
            self.playerTurn=2;
            [self.playerNumView setImage:one];
        }else{
            self.playerTurn = (arc4random() % 2) + 1;
            if(self.playerTurn==1){
                [self.playerNumView setImage:one];
            }else if(self.playerTurn==2){
                
                [self.playerNumView setImage:two];
            }
        }
        [self updateBoardVisual];
    }else if([alertView.title isEqual:@"Player 1 Wins!"]||[alertView.title isEqual:@"Player 2 Wins!"]||[alertView.title isEqual:@"Cat's Game!"]){
        NSString *choice = [alertView buttonTitleAtIndex:buttonIndex];
        if([choice isEqual:@"Yes"]){
            [self viewDidLoad];
        }else{
            [self performSegueWithIdentifier:@"mainMenu" sender:self];
        }
    }
}

- (void)updateBoardVisual
{
    UIImage *one = [UIImage imageNamed: @"one.gif"];
    UIImage *two = [UIImage imageNamed: @"two.gif"];
    if(self.playerTurn==1){
        [self.playerNumView setImage:one];
        self.playerTurn=2;
    }else if(self.playerTurn==2){
        [self.playerNumView setImage:two];
        self.playerTurn=1;
    }
    UIImage *emptySpace = [UIImage imageNamed: @"empty.gif"];
    UIImage *x = [UIImage imageNamed: @"x.gif"];
    UIImage *o = [UIImage imageNamed: @"o.gif"];
    if([[self.boardArray objectAtIndex:0] isEqual:@"x"]){
        [self.square1 setImage:x];
    }else if([[self.boardArray objectAtIndex:0] isEqual:@"o"]){
        [self.square1 setImage:o];
    }else{
        [self.square1 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:1] isEqual:@"x"]){
        [self.square2 setImage:x];
    }else if([[self.boardArray objectAtIndex:1] isEqual:@"o"]){
        [self.square2 setImage:o];
    }else{
        [self.square2 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:2] isEqual:@"x"]){
        [self.square3 setImage:x];
    }else if([[self.boardArray objectAtIndex:2] isEqual:@"o"]){
        [self.square3 setImage:o];
    }else{
        [self.square3 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:3] isEqual:@"x"]){
        [self.square4 setImage:x];
    }else if([[self.boardArray objectAtIndex:3] isEqual:@"o"]){
        [self.square4 setImage:o];
    }else{
        [self.square4 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:4] isEqual:@"x"]){
        [self.square5 setImage:x];
    }else if([[self.boardArray objectAtIndex:4] isEqual:@"o"]){
        [self.square5 setImage:o];
    }else{
        [self.square5 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:5] isEqual:@"x"]){
        [self.square6 setImage:x];
    }else if([[self.boardArray objectAtIndex:5] isEqual:@"o"]){
        [self.square6 setImage:o];
    }else{
        [self.square6 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:6] isEqual:@"x"]){
        [self.square7 setImage:x];
    }else if([[self.boardArray objectAtIndex:6] isEqual:@"o"]){
        [self.square7 setImage:o];
    }else{
        [self.square7 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:7] isEqual:@"x"]){
        [self.square8 setImage:x];
    }else if([[self.boardArray objectAtIndex:7] isEqual:@"o"]){
        [self.square8 setImage:o];
    }else{
        [self.square8 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:8] isEqual:@"x"]){
        [self.square9 setImage:x];
    }else if([[self.boardArray objectAtIndex:8] isEqual:@"o"]){
        [self.square9 setImage:o];
    }else{
        [self.square9 setImage:emptySpace];
    }
    [self checkForVictory];
}
- (IBAction)button1Touched:(id)sender {
    if([[self.boardArray objectAtIndex:0] isEqual:@"e"]){
        if(self.turn==0){
            [self.boardArray setObject:@"x" atIndexedSubscript:0];
            self.turn=1;
        }else{
            [self.boardArray setObject:@"o" atIndexedSubscript:0];
            self.turn=0;
        }
        [self updateBoardVisual];
    }
}
- (IBAction)button2Touched:(id)sender {
    if([[self.boardArray objectAtIndex:1] isEqual:@"e"]){
        if(self.turn==0){
            [self.boardArray setObject:@"x" atIndexedSubscript:1];
            self.turn=1;
        }else{
            [self.boardArray setObject:@"o" atIndexedSubscript:1];
            self.turn=0;
        }
        [self updateBoardVisual];
    }
}
- (IBAction)button3Touched:(id)sender {
    if([[self.boardArray objectAtIndex:2] isEqual:@"e"]){
        if(self.turn==0){
            [self.boardArray setObject:@"x" atIndexedSubscript:2];
            self.turn=1;
        }else{
            [self.boardArray setObject:@"o" atIndexedSubscript:2];
            self.turn=0;
        }
        [self updateBoardVisual];
    }
}
- (IBAction)button4Touched:(id)sender {
    if([[self.boardArray objectAtIndex:3] isEqual:@"e"]){
        if(self.turn==0){
            [self.boardArray setObject:@"x" atIndexedSubscript:3];
            self.turn=1;
        }else{
            [self.boardArray setObject:@"o" atIndexedSubscript:3];
            self.turn=0;
        }
        [self updateBoardVisual];
    }
}
- (IBAction)button5Touched:(id)sender {
    if([[self.boardArray objectAtIndex:4] isEqual:@"e"]){
        if(self.turn==0){
            [self.boardArray setObject:@"x" atIndexedSubscript:4];
            self.turn=1;
        }else{
            [self.boardArray setObject:@"o" atIndexedSubscript:4];
            self.turn=0;
        }
        [self updateBoardVisual];
    }
}
- (IBAction)button6Touched:(id)sender {
    if([[self.boardArray objectAtIndex:5] isEqual:@"e"]){
        if(self.turn==0){
            [self.boardArray setObject:@"x" atIndexedSubscript:5];
            self.turn=1;
        }else{
            [self.boardArray setObject:@"o" atIndexedSubscript:5];
            self.turn=0;
        }
        [self updateBoardVisual];
    }
}
- (IBAction)button7Touched:(id)sender {
    if([[self.boardArray objectAtIndex:6] isEqual:@"e"]){
        if(self.turn==0){
            [self.boardArray setObject:@"x" atIndexedSubscript:6];
            self.turn=1;
        }else{
            [self.boardArray setObject:@"o" atIndexedSubscript:6];
            self.turn=0;
        }
        [self updateBoardVisual];
    }
}
- (IBAction)button8Touched:(id)sender {
    if([[self.boardArray objectAtIndex:7] isEqual:@"e"]){
        if(self.turn==0){
            [self.boardArray setObject:@"x" atIndexedSubscript:7];
            self.turn=1;
        }else{
            [self.boardArray setObject:@"o" atIndexedSubscript:7];
            self.turn=0;
        }
        [self updateBoardVisual];
    }
}
- (IBAction)button9Touched:(id)sender {
    if([[self.boardArray objectAtIndex:8] isEqual:@"e"]){
        if(self.turn==0){
            [self.boardArray setObject:@"x" atIndexedSubscript:8];
            self.turn=1;
        }else{
            [self.boardArray setObject:@"o" atIndexedSubscript:8];
            self.turn=0;
        }
        [self updateBoardVisual];
    }
}
-(void) checkForVictory{
    for(int i=0; i<=6; i=i+3){
        //if i&&i+1&&i+2
        if([[self.boardArray objectAtIndex:i] isEqual:@"x"]&&[[self.boardArray objectAtIndex:i+1] isEqual:@"x"]&&[[self.boardArray objectAtIndex:i+2] isEqual:@"x"]){
            [self victoryPopup];
            return;
        }
        if([[self.boardArray objectAtIndex:i] isEqual:@"o"]&&[[self.boardArray objectAtIndex:i+1] isEqual:@"o"]&&[[self.boardArray objectAtIndex:i+2] isEqual:@"o"]){
            [self victoryPopup];
            return;
        }
    }
    for(int i=0; i<=2; i++){
        //if i&&i+3&&i+6
        if([[self.boardArray objectAtIndex:i] isEqual:@"x"]&&[[self.boardArray objectAtIndex:i+3] isEqual:@"x"]&&[[self.boardArray objectAtIndex:i+6] isEqual:@"x"]){
            [self victoryPopup];
            return;
        }
        if([[self.boardArray objectAtIndex:i] isEqual:@"o"]&&[[self.boardArray objectAtIndex:i+3] isEqual:@"o"]&&[[self.boardArray objectAtIndex:i+6] isEqual:@"o"]){
            [self victoryPopup];
            return;
        }
    }
    //if 0&&4&&8
    if([[self.boardArray objectAtIndex:0] isEqual:@"x"]&&[[self.boardArray objectAtIndex:4] isEqual:@"x"]&&[[self.boardArray objectAtIndex:8] isEqual:@"x"]){
        [self victoryPopup];
        return;
    }
    if([[self.boardArray objectAtIndex:0] isEqual:@"o"]&&[[self.boardArray objectAtIndex:4] isEqual:@"o"]&&[[self.boardArray objectAtIndex:8] isEqual:@"o"]){
        [self victoryPopup];
        return;
    }
    //if 2&&4&&6
    if([[self.boardArray objectAtIndex:2] isEqual:@"x"]&&[[self.boardArray objectAtIndex:4] isEqual:@"x"]&&[[self.boardArray objectAtIndex:6] isEqual:@"x"]){
        [self victoryPopup];
        return;
    }
    if([[self.boardArray objectAtIndex:2] isEqual:@"o"]&&[[self.boardArray objectAtIndex:4] isEqual:@"o"]&&[[self.boardArray objectAtIndex:6] isEqual:@"o"]){
        [self victoryPopup];
        return;
    }
    bool noE = true;
    for(int i=0; i<=8; i++){
        if([[self.boardArray objectAtIndex:i] isEqual:@"e"]){
            noE=false;
        }
    }
    if(noE){
        UIAlertView *gameEnd = [[UIAlertView alloc] initWithTitle:@"Cat's Game!"
                                                          message:@"Would you like to play a new game?"
                                                         delegate:self
                                                cancelButtonTitle:@"No"
                                                otherButtonTitles:@"Yes",nil];
        [gameEnd show];
    }

}

-(void)victoryPopup{
    if(self.playerTurn==2){
    UIAlertView *gameEnd = [[UIAlertView alloc] initWithTitle:@"Player 2 Wins!"
                                                        message:@"Would you like to play a new game?"
                                                       delegate:self
                                              cancelButtonTitle:@"No"
                                              otherButtonTitles:@"Yes",nil];
        [gameEnd show];
    }else if(self.playerTurn==1){
        UIAlertView *gameEnd = [[UIAlertView alloc] initWithTitle:@"Player 1 Wins!"
                                                          message:@"Would you like to play a new game?"
                                                         delegate:self
                                                cancelButtonTitle:@"No"
                                                otherButtonTitles:@"Yes",nil];
        [gameEnd show];
    }
}




/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
