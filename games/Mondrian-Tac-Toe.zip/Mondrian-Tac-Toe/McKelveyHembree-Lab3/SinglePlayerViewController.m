//
//  SinglePlayerViewController.m
//  McKelveyHembree-Lab3
//
//  Created by Labuser on 9/29/14.
//  Copyright (c) 2014 WUSTL CSE. All rights reserved.
//

#import "SinglePlayerViewController.h"

@interface SinglePlayerViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *square1;
@property (weak, nonatomic) IBOutlet UIImageView *square2;
@property (weak, nonatomic) IBOutlet UIImageView *square3;
@property (weak, nonatomic) IBOutlet UIImageView *square4;
@property (weak, nonatomic) IBOutlet UIImageView *square5;
@property (weak, nonatomic) IBOutlet UIImageView *square6;
@property (weak, nonatomic) IBOutlet UIImageView *square7;
@property (weak, nonatomic) IBOutlet UIImageView *square8;
@property (weak, nonatomic) IBOutlet UIImageView *square9;
@property (weak, nonatomic) IBOutlet UIButton *button1;
@property (weak, nonatomic) IBOutlet UIButton *button2;
@property (weak, nonatomic) IBOutlet UIButton *button3;
@property (weak, nonatomic) IBOutlet UIButton *button4;
@property (weak, nonatomic) IBOutlet UIButton *button5;
@property (weak, nonatomic) IBOutlet UIButton *button6;
@property (weak, nonatomic) IBOutlet UIButton *button7;
@property (weak, nonatomic) IBOutlet UIButton *button8;
@property (weak, nonatomic) IBOutlet UIButton *button9;
@property NSString *playerSymbol;
@property NSString *computerSymbol;
@property int turn;
@end

@implementation SinglePlayerViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.boardArray = [[NSMutableArray alloc] initWithObjects:@"e",@"e",@"e",@"e",@"e",@"e",@"e",@"e",@"e", nil];
    [self updateBoardVisual];
    UIAlertView *gameStart = [[UIAlertView alloc] initWithTitle:@"Who should move first?"
                                                        message:nil
                                                       delegate:self
                                              cancelButtonTitle:@"Random"
                                              otherButtonTitles:@"Player",@"Computer",nil];
    [gameStart show];
    int playerX = (arc4random() % 2);
    if(playerX==0){
        self.playerSymbol=@"x";
        self.computerSymbol=@"o";
    }else{
        
        self.playerSymbol=@"o";
        self.computerSymbol=@"x";
    }
    [self updateBoardVisual];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if([alertView.title isEqual:@"Who should move first?"]){
        NSString *choice = [alertView buttonTitleAtIndex:buttonIndex];
        if([choice isEqual:@"Player"]){
            //self.playerTurn=1;
            
        }else if([choice isEqual:@"Computer"]){
            //self.playerTurn=2;
            [self computerTurn];
        }else{
            int playerStarts = (arc4random() % 2);
            if(playerStarts==1){
                [self computerTurn];
            }
        }
        [self updateBoardVisual];
    }
    else if([alertView.title isEqual:@"Player Wins!"]||[alertView.title isEqual:@"Computer Wins!"]||[alertView.title isEqual:@"Cat's Game!"]){
        NSString *choice = [alertView buttonTitleAtIndex:buttonIndex];
        if([choice isEqual:@"Yes"]){
            [self viewDidLoad];
        }else{
            [self performSegueWithIdentifier:@"mainMenu1" sender:self];
        }
    }
}

- (void)updateBoardVisual
{
//    if(self.playerTurn==1){
//        self.turnLabel.text=@"Turn: Player 1";
//        self.playerTurn=2;
//    }else if(self.playerTurn==2){
//        self.turnLabel.text=@"Turn: Player 2";
//        self.playerTurn=1;
//    }
    UIImage *emptySpace = [UIImage imageNamed: @"empty.gif"];
    UIImage *x = [UIImage imageNamed: @"x.gif"];
    UIImage *o = [UIImage imageNamed: @"o.gif"];
    if([[self.boardArray objectAtIndex:0] isEqual:@"x"]){
        [self.square1 setImage:x];
    }else if([[self.boardArray objectAtIndex:0] isEqual:@"o"]){
        [self.square1 setImage:o];
    }else{
        [self.square1 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:1] isEqual:@"x"]){
        [self.square2 setImage:x];
    }else if([[self.boardArray objectAtIndex:1] isEqual:@"o"]){
        [self.square2 setImage:o];
    }else{
        [self.square2 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:2] isEqual:@"x"]){
        [self.square3 setImage:x];
    }else if([[self.boardArray objectAtIndex:2] isEqual:@"o"]){
        [self.square3 setImage:o];
    }else{
        [self.square3 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:3] isEqual:@"x"]){
        [self.square4 setImage:x];
    }else if([[self.boardArray objectAtIndex:3] isEqual:@"o"]){
        [self.square4 setImage:o];
    }else{
        [self.square4 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:4] isEqual:@"x"]){
        [self.square5 setImage:x];
    }else if([[self.boardArray objectAtIndex:4] isEqual:@"o"]){
        [self.square5 setImage:o];
    }else{
        [self.square5 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:5] isEqual:@"x"]){
        [self.square6 setImage:x];
    }else if([[self.boardArray objectAtIndex:5] isEqual:@"o"]){
        [self.square6 setImage:o];
    }else{
        [self.square6 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:6] isEqual:@"x"]){
        [self.square7 setImage:x];
    }else if([[self.boardArray objectAtIndex:6] isEqual:@"o"]){
        [self.square7 setImage:o];
    }else{
        [self.square7 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:7] isEqual:@"x"]){
        [self.square8 setImage:x];
    }else if([[self.boardArray objectAtIndex:7] isEqual:@"o"]){
        [self.square8 setImage:o];
    }else{
        [self.square8 setImage:emptySpace];
    }
    
    if([[self.boardArray objectAtIndex:8] isEqual:@"x"]){
        [self.square9 setImage:x];
    }else if([[self.boardArray objectAtIndex:8] isEqual:@"o"]){
        [self.square9 setImage:o];
    }else{
        [self.square9 setImage:emptySpace];
    }
    [self checkForVictory];
}

-(void) checkForVictory{
    for(int i=0; i<=6; i=i+3){
        //if i&&i+1&&i+2
        if([[self.boardArray objectAtIndex:i] isEqual:self.playerSymbol]&&[[self.boardArray objectAtIndex:i+1] isEqual:self.playerSymbol]&&[[self.boardArray objectAtIndex:i+2] isEqual:self.playerSymbol]){
            UIAlertView *gameEnd = [[UIAlertView alloc] initWithTitle:@"Player Wins!"
                                                              message:@"Would you like to play a new game?"
                                                             delegate:self
                                                    cancelButtonTitle:@"No"
                                                    otherButtonTitles:@"Yes",nil];
            [gameEnd show];
            return;
        }
        if([[self.boardArray objectAtIndex:i] isEqual:self.computerSymbol]&&[[self.boardArray objectAtIndex:i+1] isEqual:self.computerSymbol]&&[[self.boardArray objectAtIndex:i+2] isEqual:self.computerSymbol]){
            UIAlertView *gameEnd = [[UIAlertView alloc] initWithTitle:@"Computer Wins!"
                                                              message:@"Would you like to play a new game?"
                                                             delegate:self
                                                    cancelButtonTitle:@"No"
                                                    otherButtonTitles:@"Yes",nil];
            [gameEnd show];
            return;
        }
    }
    for(int i=0; i<=2; i++){
        //if i&&i+3&&i+6
        if([[self.boardArray objectAtIndex:i] isEqual:self.playerSymbol]&&[[self.boardArray objectAtIndex:i+3] isEqual:self.playerSymbol]&&[[self.boardArray objectAtIndex:i+6] isEqual:self.playerSymbol]){
            UIAlertView *gameEnd = [[UIAlertView alloc] initWithTitle:@"Player Wins!"
                                                              message:@"Would you like to play a new game?"
                                                             delegate:self
                                                    cancelButtonTitle:@"No"
                                                    otherButtonTitles:@"Yes",nil];
            [gameEnd show];
            return;
        }
        if([[self.boardArray objectAtIndex:i] isEqual:self.computerSymbol]&&[[self.boardArray objectAtIndex:i+3] isEqual:self.computerSymbol]&&[[self.boardArray objectAtIndex:i+6] isEqual:self.computerSymbol]){
            UIAlertView *gameEnd = [[UIAlertView alloc] initWithTitle:@"Computer Wins!"
                                                              message:@"Would you like to play a new game?"
                                                             delegate:self
                                                    cancelButtonTitle:@"No"
                                                    otherButtonTitles:@"Yes",nil];
            [gameEnd show];
            return;
        }
    }
    //if 0&&4&&8
    if([[self.boardArray objectAtIndex:0] isEqual:self.playerSymbol]&&[[self.boardArray objectAtIndex:4] isEqual:self.playerSymbol]&&[[self.boardArray objectAtIndex:8] isEqual:self.playerSymbol]){
        UIAlertView *gameEnd = [[UIAlertView alloc] initWithTitle:@"Player Wins!"
                                                          message:@"Would you like to play a new game?"
                                                         delegate:self
                                                cancelButtonTitle:@"No"
                                                otherButtonTitles:@"Yes",nil];
        [gameEnd show];
        return;
    }
    if([[self.boardArray objectAtIndex:0] isEqual:self.computerSymbol]&&[[self.boardArray objectAtIndex:4] isEqual:self.computerSymbol]&&[[self.boardArray objectAtIndex:8] isEqual:self.computerSymbol]){
        UIAlertView *gameEnd = [[UIAlertView alloc] initWithTitle:@"Computer Wins!"
                                                          message:@"Would you like to play a new game?"
                                                         delegate:self
                                                cancelButtonTitle:@"No"
                                                otherButtonTitles:@"Yes",nil];
        [gameEnd show];
        return;
    }
    //if 2&&4&&6
    if([[self.boardArray objectAtIndex:2] isEqual:self.playerSymbol]&&[[self.boardArray objectAtIndex:4] isEqual:self.playerSymbol]&&[[self.boardArray objectAtIndex:6] isEqual:self.playerSymbol]){
        UIAlertView *gameEnd = [[UIAlertView alloc] initWithTitle:@"Player Wins!"
                                                          message:@"Would you like to play a new game?"
                                                         delegate:self
                                                cancelButtonTitle:@"No"
                                                otherButtonTitles:@"Yes",nil];
        [gameEnd show];
        return;
    }
    if([[self.boardArray objectAtIndex:2] isEqual:self.computerSymbol]&&[[self.boardArray objectAtIndex:4] isEqual:self.computerSymbol]&&[[self.boardArray objectAtIndex:6] isEqual:self.computerSymbol]){
        UIAlertView *gameEnd = [[UIAlertView alloc] initWithTitle:@"Computer Wins!"
                                                          message:@"Would you like to play a new game?"
                                                         delegate:self
                                                cancelButtonTitle:@"No"
                                                otherButtonTitles:@"Yes",nil];
        [gameEnd show];
        return;
    }
    //check for cat's game
    bool noE = true;
    for(int i=0; i<=8; i++){
        if([[self.boardArray objectAtIndex:i] isEqual:@"e"]){
            noE=false;
        }
    }
    if(noE){
        UIAlertView *gameEnd = [[UIAlertView alloc] initWithTitle:@"Cat's Game!"
                                                          message:@"Would you like to play a new game?"
                                                         delegate:self
                                                cancelButtonTitle:@"No"
                                                otherButtonTitles:@"Yes",nil];
        [gameEnd show];
    }
}
- (IBAction)button1Touched:(id)sender {
    if([[self.boardArray objectAtIndex:0] isEqual:@"e"]){
        [self.boardArray setObject:self.playerSymbol atIndexedSubscript:0];
        [self updateBoardVisual];
        [self computerTurn];
    }
}
- (IBAction)button2Touched:(id)sender {
    if([[self.boardArray objectAtIndex:1] isEqual:@"e"]){
        [self.boardArray setObject:self.playerSymbol atIndexedSubscript:1];
        [self updateBoardVisual];
        [self computerTurn];
    }
}
- (IBAction)button3Touched:(id)sender {
    if([[self.boardArray objectAtIndex:2] isEqual:@"e"]){
        [self.boardArray setObject:self.playerSymbol atIndexedSubscript:2];
        [self updateBoardVisual];
        [self computerTurn];
    }}
- (IBAction)button4Touched:(id)sender {
    if([[self.boardArray objectAtIndex:3] isEqual:@"e"]){
        [self.boardArray setObject:self.playerSymbol atIndexedSubscript:3];
        [self updateBoardVisual];
        [self computerTurn];
    }
}
- (IBAction)button5Touched:(id)sender {
    if([[self.boardArray objectAtIndex:4] isEqual:@"e"]){
        [self.boardArray setObject:self.playerSymbol atIndexedSubscript:4];
        [self updateBoardVisual];
        [self computerTurn];
    }
}
- (IBAction)button6Touched:(id)sender {
    if([[self.boardArray objectAtIndex:5] isEqual:@"e"]){
        [self.boardArray setObject:self.playerSymbol atIndexedSubscript:5];
        [self updateBoardVisual];
        [self computerTurn];
    }
}
- (IBAction)button7Touched:(id)sender {
    if([[self.boardArray objectAtIndex:6] isEqual:@"e"]){
        [self.boardArray setObject:self.playerSymbol atIndexedSubscript:6];
        [self updateBoardVisual];
        [self computerTurn];
    }
}
- (IBAction)button8Touched:(id)sender {
    if([[self.boardArray objectAtIndex:7] isEqual:@"e"]){
        [self.boardArray setObject:self.playerSymbol atIndexedSubscript:7];
        [self updateBoardVisual];
        [self computerTurn];
    }
}
- (IBAction)button9Touched:(id)sender {
    if([[self.boardArray objectAtIndex:8] isEqual:@"e"]){
        [self.boardArray setObject:self.playerSymbol atIndexedSubscript:8];
        [self updateBoardVisual];
        [self computerTurn];
    }
}
-(void)computerTurn{
    //Can it win? if so, play there
    for(int i=0; i<=8; i++){
        if([[self.boardArray objectAtIndex:i] isEqual:@"e"]){
            NSMutableArray *testWinArray = [NSMutableArray arrayWithArray:self.boardArray];
            [testWinArray setObject:self.computerSymbol atIndexedSubscript:i];
            if([self computerWinTest:testWinArray forSymbol:self.computerSymbol]){
                [self.boardArray setObject:self.computerSymbol atIndexedSubscript:i];
                [self updateBoardVisual];
                return;
            }
        }
    }
    //Can the opponent win? If so, play there
    for(int i=0; i<=8; i++){
        if([[self.boardArray objectAtIndex:i] isEqual:@"e"]){
            NSMutableArray *testWinArray = [NSMutableArray arrayWithArray:self.boardArray];
            [testWinArray setObject:self.playerSymbol atIndexedSubscript:i];
            if([self computerWinTest:testWinArray forSymbol:self.playerSymbol]){
                [self.boardArray setObject:self.computerSymbol atIndexedSubscript:i];
                [self updateBoardVisual];
                return;
            }
        }
    }
    //Simplistic Tic Tac Toe AI - If none of the above condition happens,
    //prefer the center, then corners, then edges
    
    //prefer center
    if([[self.boardArray objectAtIndex:4] isEqual:@"e"]){
        [self.boardArray setObject:self.computerSymbol atIndexedSubscript:4];
        [self updateBoardVisual];
        return;
    }
    
    //then the corners
    for(int i=0; i<=8;i=i+2){
        if([[self.boardArray objectAtIndex:i] isEqual:@"e"]){
            [self.boardArray setObject:self.computerSymbol atIndexedSubscript:i];
            [self updateBoardVisual];
            return;

        }
    }
    //then the edges
    for(int i=1; i<=7;i=i+2){
        if([[self.boardArray objectAtIndex:i] isEqual:@"e"]){
            [self.boardArray setObject:self.computerSymbol atIndexedSubscript:i];
            [self updateBoardVisual];
            return;
            
        }
    }
}

-(bool)computerWinTest:(NSMutableArray*)testArray forSymbol:(NSString*)sym{
    for(int i=0; i<=6; i=i+3){
        //if i&&i+1&&i+2
        if([[testArray objectAtIndex:i] isEqual:sym]&&[[testArray objectAtIndex:i+1] isEqual:sym]&&[[testArray objectAtIndex:i+2] isEqual:sym]){
            return true;
        }
    }
    for(int i=0; i<=2; i++){
        //if i&&i+3&&i+6
        if([[testArray objectAtIndex:i] isEqual:sym]&&[[testArray objectAtIndex:i+3] isEqual:sym]&&[[testArray objectAtIndex:i+6] isEqual:sym]){
            return true;
        }
    }
    //if 0&&4&&8
    if([[testArray objectAtIndex:0] isEqual:sym]&&[[testArray objectAtIndex:4] isEqual:sym]&&[[testArray objectAtIndex:8] isEqual:sym]){
        return true;
    }
    //if 2&&4&&6
    if([[testArray objectAtIndex:2] isEqual:sym]&&[[testArray objectAtIndex:4] isEqual:sym]&&[[testArray objectAtIndex:6] isEqual:sym]){
        return true;
    }
    return false;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
