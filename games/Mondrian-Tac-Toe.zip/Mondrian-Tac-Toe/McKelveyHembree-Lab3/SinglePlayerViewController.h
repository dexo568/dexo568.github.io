//
//  SinglePlayerViewController.h
//  McKelveyHembree-Lab3
//
//  Created by Labuser on 9/29/14.
//  Copyright (c) 2014 WUSTL CSE. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SinglePlayerViewController : UIViewController <UIAlertViewDelegate>
@property NSMutableArray *boardArray;
@end
